// Réglages personnels synchronisés avec le compte VéloVerse : FTP, poids, son et son spatial.
// Ils restaient auparavant dans le navigateur seulement ; ils suivent désormais le compte sur tous les appareils.
// - Au chargement (connecté) : les valeurs du compte remplacent celles de l'appareil.
// - Reprise des anciennes valeurs de l'appareil : envoyées avec « ifMissing », elles ne complètent que les réglages
//   encore absents du compte et n'écrasent jamais une valeur déjà synchronisée depuis un autre appareil.
// - Une modification est enregistrée sur l'appareil tout de suite, puis envoyée au compte (nouvel essai si le réseau manque).
(function () {
  'use strict';
  const LOCAL = { ftp: ['vsht_ftp', 'json'], kg: ['vsht_kg', 'json'], sound: ['vv_sound', 'onoff'], spatial: ['vv_sound_spatial', 'onoff'] };
  const VALID = { ftp: v => Number.isInteger(v) && v >= 80 && v <= 600, kg: v => typeof v === 'number' && v >= 35 && v <= 160, sound: v => typeof v === 'boolean', spatial: v => typeof v === 'boolean' };
  const readLocal = k => { try { const [key, t] = LOCAL[k], v = localStorage.getItem(key); if (v === null) return undefined; return t === 'json' ? JSON.parse(v) : v !== 'off'; } catch (e) { return undefined; } };
  const writeLocal = (k, v) => { try { const [key, t] = LOCAL[k]; localStorage.setItem(key, t === 'json' ? JSON.stringify(v) : (v ? 'on' : 'off')); } catch (e) { /* stockage indisponible */ } };
  const send = body => fetch('/api/me/prefs', { method: 'PATCH', credentials: 'same-origin', headers: { 'content-type': 'application/json', 'x-veloverse': '1' }, body: JSON.stringify(body) })
    .then(r => r.ok ? r.json() : Promise.reject(new Error('HTTP ' + r.status)));
  let logged = false, timer = null;
  const pending = {};
  function flush() {
    const set = { ...pending }; if (!Object.keys(set).length) return;
    for (const k of Object.keys(set)) delete pending[k];
    send({ set }).catch(() => { for (const [k, v] of Object.entries(set)) if (!(k in pending)) pending[k] = v; clearTimeout(timer); timer = setTimeout(flush, 15000); });
  }
  addEventListener('online', () => { if (logged) flush(); });
  window.VVPrefs = {
    sync(user) {
      if (!user) return {};
      logged = true;
      const server = user.prefs || {}, out = {}, missing = {};
      for (const k of Object.keys(LOCAL)) {
        if (server[k] && VALID[k](server[k].v)) { out[k] = server[k].v; writeLocal(k, server[k].v); }
        else if (server[k] && server[k].v === null) { try { localStorage.removeItem(LOCAL[k][0]); } catch (e) { /* stockage indisponible */ } } // effacé dans le profil : l'appareil oublie aussi l'ancienne valeur
        else { const v = readLocal(k); if (v !== undefined && VALID[k](v)) missing[k] = v; }
      }
      if (Object.keys(missing).length) send({ set: missing, ifMissing: true }).catch(() => {});
      return out;
    },
    set(k, v) {
      if (!LOCAL[k] || !VALID[k](v)) return;
      writeLocal(k, v);
      if (!logged) return;
      pending[k] = v; clearTimeout(timer); timer = setTimeout(flush, 600);
    },
  };
})();
