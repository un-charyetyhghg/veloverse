// VéloVerse — signalement automatique des incidents d'une carte 3D.
// Chargé en premier dans la page de sortie : il voit les erreurs réellement constatées dans le navigateur
// (erreurs JavaScript de nos scripts, ressources introuvables, promesses rejetées) et celles que la page lui confie
// (rendu 3D indisponible, terrain ou données de parcours invalides, audio). Chaque erreur n'est envoyée qu'une fois
// par page, au serveur de VéloVerse uniquement (journal des incidents du panneau d'administration).
// Expose window.VVTelemetry = { setRoute(id), report(kind, message, detail, severity), loaded(ms) }.
(function () {
  'use strict';
  const sent = new Set(), queue = [];
  let route = null;
  const post = (path, body) => { try { fetch('/api' + path, { method: 'POST', credentials: 'same-origin', keepalive: true, headers: { 'content-type': 'application/json', 'x-veloverse': '1' }, body: JSON.stringify(body) }).catch(() => {}); } catch (e) { /* réseau indisponible */ } };
  const strip = u => String(u || '').replace(location.origin, '');
  function report(kind, message, detail, severity) {
    if (!route) { if (queue.length < 20) queue.push([kind, message, detail, severity]); return; }
    const key = kind + '|' + message;
    if (sent.has(key) || sent.size >= 20) return; // une fois par page, et jamais plus de 20 envois
    sent.add(key);
    post('/routes/' + encodeURIComponent(route) + '/report', { kind, message: String(message).slice(0, 300), detail: detail || {}, severity });
  }
  // nos propres scripts seulement (une extension du navigateur ne doit pas créer d'incident)
  const own = f => !f || f.startsWith(location.origin) || f.startsWith('/');
  addEventListener('error', e => {
    const t = e.target;
    if (t && t !== window && /^(SCRIPT|IMG|LINK|AUDIO|VIDEO)$/.test(t.tagName || '')) {
      const url = t.src || t.href || '';
      if (!own(url)) return;
      report('resource', 'Ressource introuvable : ' + strip(url), { url: strip(url), tag: t.tagName.toLowerCase() }, t.tagName === 'SCRIPT' || t.tagName === 'LINK' ? 'error' : 'warning');
      return;
    }
    if (!e.message || !own(e.filename)) return;
    report('js', e.message, { file: strip(e.filename), line: e.lineno || 0, col: e.colno || 0, stack: e.error && e.error.stack ? String(e.error.stack) : '' });
  }, true);
  addEventListener('unhandledrejection', e => {
    const r = e.reason, stack = r && r.stack ? String(r.stack) : '';
    if (stack && !stack.includes(location.origin) && !stack.includes('/world/')) return;
    report('js', 'Promesse rejetée : ' + (r && r.message ? r.message : String(r)), { stack });
  });
  window.VVTelemetry = {
    setRoute(id) { route = id; queue.splice(0).forEach(a => report(...a)); },
    report,
    // chargement réussi : au plus une fois par jour, par parcours et par navigateur
    loaded(ms) {
      if (!route) return;
      try { const k = 'vv_loaded_' + route, d = new Date().toISOString().slice(0, 10); if (localStorage.getItem(k) === d) return; localStorage.setItem(k, d); } catch (e) { /* stockage indisponible */ }
      post('/routes/' + encodeURIComponent(route) + '/loaded', { ms: Math.round(ms) });
    },
  };
})();
