// VéloVerse — ambiance sonore des parcours, synthétisée avec Web Audio (aucun fichier audio).
// Vent qui suit la vitesse, chants d'oiseaux, vagues (littoral), ruisseau (forêt), grillons (campagne), rumeur de ville.
// Son spatial : des sources placées dans le décor (vagues, mouettes, moutons, abeilles, oiseaux, cloches…) dont le volume
// dépend de la distance au cycliste, avec des transitions lissées. Réglage « Spatial » activable / désactivable.
// Expose window.VVAmbience.create(theme, { bed }) → { start(), setSpeed(mps), setOn(bool), setSpatial(bool), listen(listener, sources), on, spatial, state }
// et VVAmbience.distanceGain(d) (courbe d'atténuation).
(function () {
  'use strict';
  // Cap Horizon (littoral) : profil d'origine, inchangé — aucune des options ajoutées ci-dessous ne le concerne.
  // Options des autres décors :
  //   seamless : boucles de bruit de 8 s raccordées en fondu (aucun clic, répétition inaudible), partagées entre les voix ;
  //   typeMax  : nombre maximal de voix spatiales d'un même type jouées ensemble (pas d'empilement de sons identiques) ;
  //   altitude : vent plus fort et oiseaux plus rares en altitude ; lake / leaves / sand / wheat : nappes de fond.
  const TYPE_MAX = { water: 2, lake: 2, harbor: 2, cascade: 2, oasis: 1, stream: 2, songbird: 3, crickets: 2, bell: 2, churchbell: 1, cow: 2, rooster: 1, marmot: 2, woodpecker: 1, hawk: 1, bees: 2, camel: 2 };
  const PROFILE = {
    littoral: { birds: 0.5, gulls: true, waves: true, wind: 1.1 },
    montagne: { birds: 0.45, wind: 1.4, altitude: true, seamless: true, typeMax: TYPE_MAX },
    canyon: { birds: 0.15, hawk: true, wind: 1.2, sand: true, seamless: true, typeMax: TYPE_MAX },
    foret: { birds: 1, lake: true, leaves: true, wind: 0.7, seamless: true, typeMax: TYPE_MAX },
    ville: { birds: 0.2, city: true, wind: 0.6, seamless: true, typeMax: TYPE_MAX },
    campagne: { birds: 0.85, crickets: true, wheat: true, wind: 0.9, seamless: true, typeMax: TYPE_MAX },
  };
  const KEY = 'vv_sound', SKEY = 'vv_sound_spatial';
  const readPref = k => { try { return localStorage.getItem(k) !== 'off'; } catch (e) { return true; } };
  const writePref = (k, on) => { try { localStorage.setItem(k, on ? 'on' : 'off'); } catch (e) { /* stockage indisponible */ } };
  const pref = () => readPref(KEY), savePref = on => writePref(KEY, on);

  /* ---------- Atténuation selon la distance ----------
     Plein volume jusqu'à REF mètres, puis décroissance inverse (naturelle à l'oreille), jamais sous FLOOR :
     au-delà de MAX_D le son reste très faible mais audible. Au-delà de CULL, la source est retirée en fondu. */
  const REF = 6, ROLL = 1, MAX_D = 220, FLOOR = 0.03, CULL = 320, VOICES = 8;
  function distanceGain(d) {
    if (!(d >= 0)) return FLOOR;
    if (d <= REF) return 1;
    return Math.max(FLOOR, REF / (REF + ROLL * (Math.min(d, MAX_D) - REF)));
  }
  // Volume propre à chaque type de source (avant atténuation).
  const LEVEL = { camel: 0.5, water: 0.55, stream: 0.35, fountain: 0.28, bees: 0.9, sheep: 0.5, gulls: 0.6, songbird: 0.55, bell: 0.35, horn: 0.5, hawk: 0.45, crickets: 0.5,
    lake: 0.6, harbor: 0.9, cascade: 0.75, oasis: 0.7, churchbell: 0.6, cow: 0.55, rooster: 0.4, marmot: 0.45, woodpecker: 0.5 };

  function create(theme, opts = {}) {
    const P = PROFILE[theme] || PROFILE.campagne, withBed = opts.bed !== false;
    const A = { on: pref(), spatial: readPref(SKEY), ctx: null, speed: 0, alt: 0, altK: 1, birdK: 1, wx: { rain: 0, cloud: 0, night: 0, glow: 0 }, wxK: 1, dayK: 1 };
    let master, windGain, windFilter, timers = [], spatialBus;
    const voices = new Map();

    function noiseBuffer(ctx, sec = 3, brown = false) {
      const b = ctx.createBuffer(1, ctx.sampleRate * sec, ctx.sampleRate), d = b.getChannelData(0); let last = 0;
      for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; if (brown) { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w; }
      return b;
    }
    // Boucle de 8 s dont la fin est fondue dans le début : la jonction est inaudible (aucun clic). Une seule par type de bruit,
    // partagée par toutes les voix (chacune démarre à un endroit différent : pas de répétition en phase).
    const SEAM = {};
    function seamlessBuffer(ctx, brown) {
      const key = brown ? 'b' : 'w'; if (SEAM[key]) return SEAM[key];
      const sec = 8, X = 0.4, n = Math.floor(ctx.sampleRate * sec), m = Math.floor(ctx.sampleRate * X), raw = new Float32Array(n + m); let last = 0;
      for (let i = 0; i < n + m; i++) { const w = Math.random() * 2 - 1; if (brown) { last = (last + 0.02 * w) / 1.02; raw[i] = last * 3.5; } else raw[i] = w; }
      const b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = raw[i + m];
      for (let i = 0; i < m; i++) { const t = i / m; d[n - m + i] = raw[n + i] * Math.cos(t * Math.PI / 2) + raw[i] * Math.sin(t * Math.PI / 2); } // fondu à puissance constante vers le début
      return (SEAM[key] = b);
    }
    function loopNoise(ctx, brown) {
      const s = ctx.createBufferSource();
      if (P.seamless) { s.buffer = seamlessBuffer(ctx, brown); s.loop = true; s.start(0, Math.random() * 7.5); return s; }
      s.buffer = noiseBuffer(ctx, 3, brown); s.loop = true; s.start(); return s;
    }
    function lfo(ctx, freq, depth, target, base) { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = freq; g.gain.value = depth; o.connect(g); g.connect(target); target.value = base; o.start(); return o; }
    const pan = (ctx, x) => { if (ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = x; return p; } return ctx.createGain(); };

    function build() {
      const ctx = A.ctx;
      master = ctx.createGain(); master.gain.value = 0;
      // compresseur doux en sortie : pas de pic soudain, le volume de l'appareil reste la référence
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -20; comp.knee.value = 12; comp.ratio.value = 4; comp.attack.value = 0.01; comp.release.value = 0.3;
      master.connect(comp); comp.connect(ctx.destination);
      spatialBus = ctx.createGain(); spatialBus.gain.value = A.spatial ? 1 : 0; spatialBus.connect(master);
      if (!withBed) { return; }
      // vent : bruit filtré, plus fort quand on va vite
      windFilter = ctx.createBiquadFilter(); windFilter.type = 'bandpass'; windFilter.frequency.value = 500; windFilter.Q.value = 0.6;
      windGain = ctx.createGain(); windGain.gain.value = 0.02;
      loopNoise(ctx).connect(windFilter); windFilter.connect(windGain); windGain.connect(master);
      lfo(ctx, 0.13, 180, windFilter.frequency, 500);
      if (P.waves) { // ressac : bruit grave qui monte et redescend
        const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 700; const g = ctx.createGain();
        loopNoise(ctx).connect(f); f.connect(g); g.connect(master); lfo(ctx, 0.11, 0.05, g.gain, 0.06);
      }
      if (P.lake) { // lac : clapotis doux sur la rive (côté gauche), plus discret quand les vagues du lac sont spatialisées
        const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = 0.7; const g = ctx.createGain(); A.lakeBed = g;
        const p = pan(ctx, -0.45); loopNoise(ctx).connect(f); f.connect(g); g.connect(p); p.connect(master); lfo(ctx, 0.23, 0.006, g.gain, 0.012);
      }
      if (P.leaves) { // vent dans les sapins : souffle aigu qui enfle et retombe lentement
        const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 2200; const g = ctx.createGain();
        loopNoise(ctx).connect(f); f.connect(g); g.connect(master); lfo(ctx, 0.07, 0.007, g.gain, 0.01); A.leaves = g;
      }
      if (P.sand) { // vent du désert : rafales graves et sable qui crépite (aigus), en vagues lentes et irrégulières
        const fl = ctx.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 320; const gl = ctx.createGain();
        loopNoise(ctx, true).connect(fl); fl.connect(gl); gl.connect(master); lfo(ctx, 0.05, 0.03, gl.gain, 0.05);
        const fh = ctx.createBiquadFilter(); fh.type = 'highpass'; fh.frequency.value = 5200; const gh = ctx.createGain();
        loopNoise(ctx).connect(fh); fh.connect(gh); gh.connect(master); lfo(ctx, 0.083, 0.004, gh.gain, 0.005);
      }
      if (P.wheat) { // blés et hautes herbes qui bruissent au vent
        const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 3400; f.Q.value = 0.5; const g = ctx.createGain();
        loopNoise(ctx).connect(f); f.connect(g); g.connect(master); lfo(ctx, 0.09, 0.005, g.gain, 0.008);
      }
      if (P.stream) { // ruisseau : bruit aigu qui scintille
        const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 2600; f.Q.value = 0.8; const g = ctx.createGain();
        const p = pan(ctx, -0.5); loopNoise(ctx).connect(f); f.connect(g); g.connect(p); p.connect(master); lfo(ctx, 7, 0.006, g.gain, 0.018);
      }
      if (P.city) { // rumeur de ville : grondement grave et lointain
        const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 260; const g = ctx.createGain(); g.gain.value = 0.09;
        loopNoise(ctx, true).connect(f); f.connect(g); g.connect(master);
      }
      if (P.crickets) { // grillons : son aigu haché, par vagues
        const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 4300;
        const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 4300; f.Q.value = 8;
        const chop = ctx.createGain(); chop.gain.value = 0; const g = ctx.createGain(); g.gain.value = 0.0;
        o.connect(f); f.connect(chop); chop.connect(g); g.connect(master); o.start();
        lfo(ctx, 28, 0.5, chop.gain, 0.5); lfo(ctx, 0.07, 0.012, g.gain, 0.012);
      }
      scheduleBirds();
    }

    // Pluie (crépitement + gouttes sur la route), grillons nocturnes, chouette : créés au premier besoin, puis réglés en
    // fondu (constantes de temps de plusieurs secondes : pas de saut de volume quand la météo change).
    const WX = {};
    const NIGHT_BED = { foret: 1, campagne: 1, montagne: 0.6, canyon: 0.7, littoral: 0.5, ville: 0.3 };
    const OWL = { foret: 1, campagne: 0.8, montagne: 0.5 };
    function wxBuild() {
      const ctx = A.ctx; if (WX.rain || !ctx) return;
      // pluie : souffle aigu (gouttes) + bande médium (impacts)
      const fh = ctx.createBiquadFilter(); fh.type = 'highpass'; fh.frequency.value = 1800; const gh = ctx.createGain(); gh.gain.value = 0;
      loopNoise(ctx).connect(fh); fh.connect(gh); gh.connect(master);
      const fm = ctx.createBiquadFilter(); fm.type = 'bandpass'; fm.frequency.value = 650; fm.Q.value = 0.5; const gm = ctx.createGain(); gm.gain.value = 0;
      loopNoise(ctx, true).connect(fm); fm.connect(gm); gm.connect(master);
      WX.rain = { gh, gm };
      // grillons de nuit (fond) : même principe que les grillons de la campagne, plus grave et plus lent
      const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 3700;
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 3700; f.Q.value = 9;
      const chop = ctx.createGain(); chop.gain.value = 0; const g = ctx.createGain(); g.gain.value = 0;
      o.connect(f); f.connect(chop); chop.connect(g); g.connect(master); o.start(); lfo(ctx, 22, 0.5, chop.gain, 0.5);
      WX.crick = g;
      // chouette hulotte, de loin en loin, la nuit seulement (forêt, campagne, montagne)
      if (OWL[theme]) {
        const hoot = () => { const id = setTimeout(() => {
          if (A.on && A.ctx.state === 'running' && A.wx.night > 0.6 && A.wx.rain < 0.4) {
            const t = ctx.currentTime + 0.05, p = pan(ctx, Math.random() * 1.4 - 0.7); p.connect(master);
            [[0, 0.35, 0.05], [0.65, 0.18, 0.03], [0.95, 0.9, 0.045]].forEach(([dt, d, v]) => { const oo = ctx.createOscillator(), gg = ctx.createGain(), tt = t + dt;
              oo.frequency.setValueAtTime(420, tt); oo.frequency.linearRampToValueAtTime(380, tt + d); gg.gain.setValueAtTime(0.0001, tt); gg.gain.exponentialRampToValueAtTime(v * OWL[theme], tt + 0.06); gg.gain.exponentialRampToValueAtTime(0.0001, tt + d);
              oo.connect(gg); gg.connect(p); oo.start(tt); oo.stop(tt + d + 0.05); });
          }
          hoot(); }, 14000 + Math.random() * 26000); timers.push(id); if (timers.length > 20) timers.shift(); };
        hoot();
      }
    }
    function wxApply() {
      if (!A.ctx || !withBed) return;
      const w = A.wx;
      if (!WX.rain && w.rain < 0.02 && w.night < 0.05) return; // beau temps de jour : aucune couche ajoutée
      wxBuild();
      const t = A.ctx.currentTime, r = w.rain;
      WX.rain.gh.gain.setTargetAtTime(r * 0.05, t, 3); WX.rain.gm.gain.setTargetAtTime(r * 0.07, t, 3);
      WX.crick.gain.setTargetAtTime(w.night * (1 - r * 0.85) * 0.009 * (NIGHT_BED[theme] || 0.5), t, 4);
    }

    // Chants d'oiseaux : quelques motifs (sifflements, trilles, glissandos) à des moments et places aléatoires.
    function chirp(t, f0, f1, dur, vol, p) {
      const ctx = A.ctx, o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.02, dur / 3)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(p); o.start(t); o.stop(t + dur + 0.02);
    }
    function song() {
      const ctx = A.ctx, t = ctx.currentTime + 0.05, p = pan(ctx, Math.random() * 1.6 - 0.8); p.connect(master);
      const v = 0.02 + Math.random() * 0.03, kind = Math.random();
      if (P.gulls && kind < 0.35) { for (let k = 0; k < 3; k++) chirp(t + k * 0.32, 1500, 950, 0.26, v * 0.8, p); return; }
      if (P.hawk && kind < 0.3) { chirp(t, 2400, 1500, 0.9, v * 0.7, p); return; }
      if (kind < 0.4) { const n = 3 + Math.floor(Math.random() * 5), base = 2800 + Math.random() * 1500; for (let k = 0; k < n; k++) chirp(t + k * 0.11, base, base * 1.35, 0.07, v, p); }
      else if (kind < 0.7) { const a = 1900 + Math.random() * 900; chirp(t, a, a * 1.02, 0.22, v, p); chirp(t + 0.3, a * 0.82, a * 0.8, 0.28, v, p); }
      else { const base = 4000 + Math.random() * 1200; for (let k = 0; k < 12; k++) chirp(t + k * 0.045, base, base * 0.9, 0.035, v * 0.7, p); }
    }
    function scheduleBirds() {
      if (!P.birds) return;
      // avec le son spatial, une partie des oiseaux est placée dans les arbres : le fond en joue moins
      const next = () => { const id = setTimeout(() => { if (A.on && A.ctx && A.ctx.state === 'running' && (A.dayK >= 1 || Math.random() < A.dayK)) song(); next(); }, (700 + Math.random() * 3500) / P.birds * (A.spatial ? 1.8 : 1) / A.birdK); timers.push(id); if (timers.length > 20) timers.shift(); };
      next();
    }

    /* ---------- Voix spatiales ---------- */
    // Chaque type fabrique son son et le branche sur « input » ; renvoie une fonction d'arrêt.
    function every(min, max, fn) { let id = null, alive = true; const loop = () => { id = setTimeout(() => { if (!alive) return; if (A.on && A.spatial && A.ctx.state === 'running') fn(A.ctx.currentTime + 0.03); loop(); }, min + Math.random() * (max - min)); }; id = setTimeout(loop, Math.random() * min); return () => { alive = false; clearTimeout(id); }; }
    const GEN = {
      water(ctx, input) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 650; const g = ctx.createGain(); const n = loopNoise(ctx); n.connect(f); f.connect(g); g.connect(input); const o = lfo(ctx, 0.1 + Math.random() * 0.05, 0.35, g.gain, 0.5); return () => { n.stop(); o.stop(); }; },
      stream(ctx, input) { const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 2400; f.Q.value = 0.9; const g = ctx.createGain(); const n = loopNoise(ctx); n.connect(f); f.connect(g); g.connect(input); const o = lfo(ctx, 6, 0.15, g.gain, 0.7); return () => { n.stop(); o.stop(); }; },
      fountain(ctx, input) { const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 2500; const n = loopNoise(ctx); n.connect(f); f.connect(input); return () => n.stop(); },
      crickets(ctx, input) { const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 4200 + Math.random() * 400; const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = o.frequency.value; f.Q.value = 8; const chop = ctx.createGain(); chop.gain.value = 0; o.connect(f); f.connect(chop); chop.connect(input); o.start(); const l = lfo(ctx, 26 + Math.random() * 6, 0.5, chop.gain, 0.5); return () => { o.stop(); l.stop(); }; },
      bees(ctx, input) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 800; const g = ctx.createGain(); g.gain.value = 0.05; const os = [190, 204, 223].map(fr => { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = fr + Math.random() * 8; o.connect(f); o.start(); return o; }); f.connect(g); g.connect(input); const l = lfo(ctx, 4.5, 0.02, g.gain, 0.05); return () => { os.forEach(o => o.stop()); l.stop(); }; },
      sheep(ctx, input) { return every(4000, 11000, t => { const o = ctx.createOscillator(), v = ctx.createOscillator(), vg = ctx.createGain(), f = ctx.createBiquadFilter(), g = ctx.createGain(); o.type = 'sawtooth'; o.frequency.value = 300 + Math.random() * 90; v.frequency.value = 7; vg.gain.value = 14; v.connect(vg); vg.connect(o.frequency); f.type = 'bandpass'; f.frequency.value = 1000; f.Q.value = 2; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + 0.08); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.75); o.connect(f); f.connect(g); g.connect(input); o.start(t); v.start(t); o.stop(t + 0.8); v.stop(t + 0.8); }); },
      gulls(ctx, input) { return every(2500, 7000, t => { const n = 2 + Math.floor(Math.random() * 3); for (let k = 0; k < n; k++) chirp(t + k * 0.3, 1500, 950, 0.25, 0.25, input); }); },
      hawk(ctx, input) { return every(7000, 15000, t => chirp(t, 2400, 1500, 0.9, 0.22, input)); },
      songbird(ctx, input) { return every(1500, 5000, t => { const kind = Math.random(); if (kind < 0.4) { const n = 3 + Math.floor(Math.random() * 5), b = 2800 + Math.random() * 1500; for (let k = 0; k < n; k++) chirp(t + k * 0.11, b, b * 1.35, 0.07, 0.25, input); } else if (kind < 0.7) { const a = 1900 + Math.random() * 900; chirp(t, a, a * 1.02, 0.22, 0.25, input); chirp(t + 0.3, a * 0.82, a * 0.8, 0.28, 0.25, input); } else { const b = 4000 + Math.random() * 1200; for (let k = 0; k < 12; k++) chirp(t + k * 0.045, b, b * 0.9, 0.035, 0.18, input); } }); },
      bell(ctx, input) { return every(1500, 4500, t => { for (const [fr, v, d] of [[880, 0.2, 1.4], [2350, 0.08, 0.7]]) { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = fr * (0.97 + Math.random() * 0.06); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(g); g.connect(input); o.start(t); o.stop(t + d + 0.05); } }); },
      camel(ctx, input) { return every(6000, 14000, t => { const o = ctx.createOscillator(), v = ctx.createOscillator(), vg = ctx.createGain(), f = ctx.createBiquadFilter(), g = ctx.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(95 + Math.random() * 20, t); o.frequency.linearRampToValueAtTime(70, t + 1.1); v.frequency.value = 11; vg.gain.value = 9; v.connect(vg); vg.connect(o.frequency); f.type = 'lowpass'; f.frequency.value = 520; f.Q.value = 3; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.35, t + 0.15); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.2); o.connect(f); f.connect(g); g.connect(input); o.start(t); v.start(t); o.stop(t + 1.25); v.stop(t + 1.25); }); },
      // eau calme (lac, port, oasis) : clapotis — petites vaguelettes irrégulières, sans le grondement du ressac
      lake(ctx, input) { const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 850; f.Q.value = 0.6; const g = ctx.createGain(); g.gain.value = 0; const n = loopNoise(ctx); n.connect(f); f.connect(g); g.connect(input);
        const o1 = lfo(ctx, 0.31 + Math.random() * 0.1, 0.22, g.gain, 0.4), o2 = lfo(ctx, 0.83 + Math.random() * 0.2, 0.12, g.gain, 0.4); return () => { n.stop(); o1.stop(); o2.stop(); }; },
      harbor(ctx, input) { return GEN.lake(ctx, input); },
      // cascade : chute d'eau continue — grondement + éclaboussures aiguës
      cascade(ctx, input) { const fl = ctx.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 1400; const fh = ctx.createBiquadFilter(); fh.type = 'highpass'; fh.frequency.value = 3000; const gh = ctx.createGain(); gh.gain.value = 0.35;
        const a = loopNoise(ctx), b = loopNoise(ctx); a.connect(fl); fl.connect(input); b.connect(fh); fh.connect(gh); gh.connect(input); const o = lfo(ctx, 0.4, 0.05, gh.gain, 0.35); return () => { a.stop(); b.stop(); o.stop(); }; },
      // oasis : clapotis du bassin et, de temps en temps, des grenouilles
      oasis(ctx, input) { const stopW = GEN.lake(ctx, input); const stopF = every(5000, 12000, t => { const n = 2 + Math.floor(Math.random() * 3); for (let k = 0; k < n; k++) { const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter(); o.type = 'square'; o.frequency.value = 180 + Math.random() * 40; f.type = 'bandpass'; f.frequency.value = 650; f.Q.value = 3; const tt = t + k * 0.32; g.gain.setValueAtTime(0.0001, tt); g.gain.exponentialRampToValueAtTime(0.18, tt + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, tt + 0.16); o.connect(f); f.connect(g); g.connect(input); o.start(tt); o.stop(tt + 0.2); } }); return () => { stopW(); stopF(); }; },
      // cloche d'église : volée de quelques coups graves, de loin en loin
      churchbell(ctx, input) { return every(25000, 50000, t => { const n = 3 + Math.floor(Math.random() * 4); for (let k = 0; k < n; k++) for (const [fr, v, d] of [[392, 0.3, 3.2], [784, 0.12, 2], [1176, 0.06, 1.2]]) { const o = ctx.createOscillator(), g = ctx.createGain(), tt = t + k * 1.6; o.frequency.value = fr; g.gain.setValueAtTime(0.0001, tt); g.gain.exponentialRampToValueAtTime(v, tt + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, tt + d); o.connect(g); g.connect(input); o.start(tt); o.stop(tt + d + 0.05); } }); },
      // vache : meuglement grave et long
      cow(ctx, input) { return every(9000, 22000, t => { const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(), d = 1.3 + Math.random() * 0.6; o.type = 'sawtooth'; o.frequency.setValueAtTime(130 + Math.random() * 20, t); o.frequency.linearRampToValueAtTime(155, t + d * 0.4); o.frequency.linearRampToValueAtTime(110, t + d); f.type = 'lowpass'; f.frequency.value = 650; f.Q.value = 4; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.3, t + 0.25); g.gain.setValueAtTime(0.3, t + d * 0.7); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(f); f.connect(g); g.connect(input); o.start(t); o.stop(t + d + 0.05); }); },
      // coq : cocorico, rarement
      rooster(ctx, input) { return every(30000, 70000, t => { [[0, 0.12, 700, 900], [0.16, 0.12, 900, 950], [0.33, 0.55, 1000, 700]].forEach(([dt, d, f0, f1]) => { const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(), tt = t + dt; o.type = 'sawtooth'; o.frequency.setValueAtTime(f0, tt); o.frequency.linearRampToValueAtTime(f1, tt + d); f.type = 'bandpass'; f.frequency.value = 1500; f.Q.value = 1.5; g.gain.setValueAtTime(0.0001, tt); g.gain.exponentialRampToValueAtTime(0.25, tt + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, tt + d); o.connect(f); f.connect(g); g.connect(input); o.start(tt); o.stop(tt + d + 0.05); }); }); },
      // marmotte : sifflement d'alerte bref et aigu
      marmot(ctx, input) { return every(6000, 16000, t => { const n = 1 + Math.floor(Math.random() * 2); for (let k = 0; k < n; k++) chirp(t + k * 0.6, 2700, 2500, 0.32, 0.3, input); }); },
      // pic : tambourinage rapide sur un tronc
      woodpecker(ctx, input) { return every(9000, 20000, t => { const n = 12 + Math.floor(Math.random() * 8); for (let k = 0; k < n; k++) { const o = ctx.createOscillator(), g = ctx.createGain(), tt = t + k * 0.055; o.type = 'triangle'; o.frequency.value = 520 + Math.random() * 40; g.gain.setValueAtTime(0.0001, tt); g.gain.exponentialRampToValueAtTime(0.3 * (1 - k / (n + 4)), tt + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, tt + 0.04); o.connect(g); g.connect(input); o.start(tt); o.stop(tt + 0.05); } }); },
      horn(ctx, input) { return every(16000, 28000, t => { const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(); o.type = 'sawtooth'; o.frequency.value = 110; f.type = 'lowpass'; f.frequency.value = 380; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.4, t + 0.4); g.gain.setValueAtTime(0.4, t + 1.8); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.6); o.connect(f); f.connect(g); g.connect(input); o.start(t); o.stop(t + 2.7); }); },
    };
    // Météo et nuit (réglées par setWeather) : les animaux du jour se taisent peu à peu la nuit et sous la pluie, les
    // grillons chantent plus fort la nuit. En plein jour par temps sec, tous les facteurs valent 1 : rien ne change.
    const DAY_TYPES = { songbird: 1, gulls: 1, hawk: 1, rooster: 1, woodpecker: 1, marmot: 1, bees: 1, sheep: 0.6, cow: 0.6, camel: 0.5 };
    function typeK(ty) {
      const w = A.wx, d = DAY_TYPES[ty];
      if (d) return Math.max(0.05, 1 - d * Math.max(w.night * 0.92, w.rain * 0.7));
      if (ty === 'crickets') return (1 + w.night * 0.8) * (1 - w.rain * 0.8);
      return 1;
    }
    const FADE = 0.5, SMOOTH = 0.15; // constantes de temps (s) : disparition, et lissage entre deux mises à jour
    const STEP_DB = 3;               // variation maximale par mise à jour (≈ 30 dB/s) : jamais de saut brusque
    const toDb = g => 20 * Math.log10(Math.max(1e-4, g)), fromDb = d => Math.pow(10, d / 20);
    function spawn(src) {
      const ctx = A.ctx, input = ctx.createGain(), air = ctx.createBiquadFilter(), gain = ctx.createGain(), pn = pan(ctx, 0);
      input.gain.value = LEVEL[src.type] || 0.3; air.type = 'lowpass'; air.frequency.value = 16000; gain.gain.value = 0;
      input.connect(air); air.connect(gain); gain.connect(pn); pn.connect(spatialBus);
      const stop = (GEN[src.type] || GEN.water)(ctx, input);
      return { gain, pn, air, stop, nodes: [input, air, gain, pn], type: src.type, d: Infinity, target: 0, cur: FLOOR * 0.5 };
    }
    function retire(v) {
      const t = A.ctx.currentTime; v.gain.gain.cancelScheduledValues(t); v.gain.gain.setTargetAtTime(0, t, FADE);
      setTimeout(() => { try { v.stop(); } catch (e) { /* déjà arrêté */ } v.nodes.forEach(n => { try { n.disconnect(); } catch (e) { /* déjà débranché */ } }); }, FADE * 6000);
    }
    // Met à jour les voix à partir de la position de la personne (x, y, z, cap) et des sources du décor.
    function listen(L, sources) {
      if (!A.ctx || !L) return;
      const t = A.ctx.currentTime, ch = Math.cos(L.heading || 0), sh = Math.sin(L.heading || 0);
      const near = [];
      for (const s of sources) { const dx = s.x - L.x, dy = (s.y - L.y) * 0.7, dz = s.z - L.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz); if (d < CULL) near.push({ s, d, dx, dz }); }
      near.sort((a, b) => a.d - b.d);
      if (P.typeMax) { const cnt = {}; /* on garde les plus proches de chaque type */ const kept = []; for (const n of near) { const ty = n.s.type, mx = P.typeMax[ty] || 3; cnt[ty] = (cnt[ty] || 0) + 1; if (cnt[ty] <= mx) kept.push(n); } near.length = 0; near.push(...kept); }
      near.length = Math.min(near.length, VOICES);
      const keep = new Set();
      for (const n of near) {
        const key = n.s.key || n.s; keep.add(key);
        let v = voices.get(key); if (!v) { v = spawn(n.s); voices.set(key, v); }
        v.d = n.d; v.target = distanceGain(n.d) * typeK(v.type);
        // on se rapproche de la cible d'au plus STEP_DB décibels à chaque mise à jour (montée et descente progressives)
        const cd = toDb(v.cur), td = toDb(v.target); v.cur = fromDb(cd + Math.max(-STEP_DB, Math.min(STEP_DB, td - cd)));
        v.gain.gain.setTargetAtTime(v.cur, t, SMOOTH);
        // gauche / droite selon la position de la source par rapport au cap ; aigus atténués au loin (air)
        const lat = n.dx * -sh + n.dz * ch, fwd = n.dx * ch + n.dz * sh, pv = Math.max(-0.85, Math.min(0.85, lat / Math.sqrt(lat * lat + fwd * fwd + 4)));
        if (v.pn.pan) v.pn.pan.setTargetAtTime(pv, t, 0.25);
        v.air.frequency.setTargetAtTime(Math.max(2500, 16000 - n.d * 60), t, SMOOTH);
      }
      for (const [k, v] of voices) if (!keep.has(k)) { retire(v); voices.delete(k); }
    }

    function apply() {
      if (!A.ctx) return;
      const t = A.ctx.currentTime;
      master.gain.cancelScheduledValues(t); master.gain.setTargetAtTime(A.on ? 2.6 : 0, t, 0.4);
      if (A.on && A.ctx.state === 'suspended') A.ctx.resume().catch(() => {});
    }
    const inst = {
      get on() { return A.on; },
      // À appeler après un geste de la personne (clic, touche) : les navigateurs bloquent le son avant.
      start() {
        if (A.ctx) { apply(); return; }
        const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
        try { A.ctx = new AC(); build(); apply(); } catch (e) { A.ctx = null; }
        document.addEventListener('visibilitychange', () => { if (!A.ctx) return; if (document.hidden) A.ctx.suspend().catch(() => {}); else if (A.on) A.ctx.resume().catch(() => {}); });
      },
      setOn(on) { A.on = !!on; savePref(A.on); if (A.on) this.start(); else apply(); },
      get spatial() { return A.spatial; },
      // Active ou coupe le son selon la distance (fondu doux, choix mémorisé).
      setSpatial(on) { A.spatial = !!on; writePref(SKEY, A.spatial); if (spatialBus) spatialBus.gain.setTargetAtTime(A.spatial ? 1 : 0, A.ctx.currentTime, 0.4);
        if (A.lakeBed) A.lakeBed.gain.setTargetAtTime(A.spatial ? 0.006 : 0.012, A.ctx.currentTime, 0.8); /* le lac spatialisé prend le relais : pas de double clapotis */
        if (!A.spatial) for (const [k, v] of voices) { retire(v); voices.delete(k); } },
      listen(L, sources) { if (A.spatial && A.on) listen(L, sources); },
      get state() { return A.ctx ? A.ctx.state : 'none'; },
      // Pour les tests et le débogage : distance, volume visé et volume réel de chaque voix.
      voices() { return [...voices.values()].map(v => ({ type: v.type, d: Math.round(v.d * 10) / 10, target: Math.round(v.target * 1000) / 1000, gain: Math.round(v.gain.gain.value * 1000) / 1000, pan: v.pn.pan ? Math.round(v.pn.pan.value * 100) / 100 : 0 })); },
      // Hauteur du cycliste dans le parcours (0 = point le plus bas, 1 = sommet) : en montagne, le vent forcit et les
      // oiseaux se raréfient en montant vers le col.
      setAltitude(f) {
        if (!P.altitude || !(f >= 0)) return; A.alt = f;
        const k = Math.max(0, Math.min(1, (f - 0.3) / 0.6)); A.altK = 1 + k * 0.9; A.birdK = Math.max(0.25, Math.min(1, 1 - (f - 0.55) / 0.45 * 0.75));
        if (A.ctx && windGain) this.setSpeed(A.speed);
      },
      get altitude() { return A.alt; },
      // Météo et moment de la journée (0 → 1) : pluie, couverture nuageuse, nuit, lumière du lever / coucher.
      // Les sons existants restent ; seuls leurs volumes varient doucement (vent plus fort par temps couvert ou pluvieux,
      // oiseaux plus rares la nuit et sous la pluie) et des couches s'ajoutent (pluie, grillons et chouette la nuit).
      setWeather(o) {
        if (!o) return; const c = x => Math.max(0, Math.min(1, Number(x) || 0));
        A.wx = { rain: c(o.rain), cloud: c(o.cloud), night: c(o.night), glow: c(o.glow) };
        A.wxK = 1 + A.wx.cloud * 0.25 + A.wx.rain * 0.6;
        A.dayK = Math.max(0.08, 1 - Math.max(A.wx.night * 0.92, A.wx.rain * 0.7));
        if (A.ctx && windGain) this.setSpeed(A.speed);
        wxApply();
      },
      get weather() { return { ...A.wx, layers: !!WX.rain }; },
      setSpeed(v) {
        A.speed = v; if (!A.ctx) return;
        const t = A.ctx.currentTime;
        windGain.gain.setTargetAtTime((0.012 + Math.min(16, v) * 0.006) * P.wind * A.altK * A.wxK, t, 0.5);
        if (A.leaves) A.leaves.gain.setTargetAtTime(0.01 + Math.min(16, v) * 0.0004, t, 0.8);
        windFilter.Q.setTargetAtTime(0.6 + Math.min(16, v) * 0.03, t, 0.5);
      },
      // Pour les tests : à la jonction de chaque boucle de bruit (fin → début), écart entre deux échantillons voisins,
      // comparé à l'écart moyen dans la boucle (un clic se verrait comme un saut bien plus grand que la moyenne).
      loopJoin() { return Object.entries(SEAM).map(([k, b]) => { const d = b.getChannelData(0), n = d.length; let m = 0; for (let i = 1; i < n; i++) m += Math.abs(d[i] - d[i - 1]); return { bruit: k === 'b' ? 'grave' : 'blanc', secondes: b.duration, jonction: Math.abs(d[0] - d[n - 1]), moyenne: m / (n - 1) }; }); },
      supported: !!(window.AudioContext || window.webkitAudioContext),
    };
    window.VVAmbience.active = inst; // dernière ambiance créée (débogage et tests)
    return inst;
  }
  window.VVAmbience = { create, distanceGain, REF, MAX_D, FLOOR };
})();
