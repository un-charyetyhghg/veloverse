// VéloVerse — capteurs Bluetooth (Web Bluetooth) : home trainer (FTMS), cardio, cadence, capteur de puissance.
// Expose window.VVSensors. Les valeurs viennent uniquement des appareils connectés : rien n'est simulé ici.
(function () {
  'use strict';
  const BATTERY = 0x180f;
  const KINDS = {
    trainer: { label: 'Home trainer', desc: 'Puissance, cadence et vitesse. La résistance suit la pente du parcours (FTMS).', filters: [{ services: [0x1826] }], optional: [0x1826, 0x1818, BATTERY] },
    pwr: { label: 'Capteur de puissance', desc: 'Pédales, manivelle ou moyeu (Cycling Power). Prioritaire sur le home trainer pour la puissance.', filters: [{ services: [0x1818] }], optional: [0x1818, BATTERY] },
    cad: { label: 'Capteur de cadence', desc: 'Capteur de cadence ou vitesse/cadence (CSC). Prioritaire pour la cadence.', filters: [{ services: [0x1816] }], optional: [0x1816, BATTERY] },
    hr: { label: 'Cardio', desc: 'Ceinture ou brassard cardio (Coospo, Garmin, Polar, Wahoo…).', filters: [{ services: [0x180d] }, { namePrefix: 'COOSPO' }, { namePrefix: 'H6' }, { namePrefix: 'H808' }, { namePrefix: 'H9' }, { namePrefix: 'HW' }], optional: [0x180d, BATTERY] },
  };
  const ORDER = ['trainer', 'hr', 'cad', 'pwr'];
  const st = {}; for (const k of ORDER) st[k] = { status: 'off', name: '', battery: null, dev: null, error: '' };
  // dernières mesures par source : { v, t }
  const last = { power: {}, cadence: {}, hr: {}, speed: {} };
  const subs = new Set();
  let cp = null, cpQ = Promise.resolve();
  const now = () => performance.now();
  const emit = type => { for (const f of subs) { try { f(type); } catch (e) { /* abonné défaillant : ignoré */ } } };
  const put = (what, src, v) => { last[what][src] = { v, t: now() }; emit(what); };
  const fresh = (what, src, ms = 3000) => { const x = last[what][src]; return x && now() - x.t < ms ? x.v : null; };

  // Source utilisée pour chaque mesure, par ordre de priorité.
  const PRIO = { power: ['pwr', 'trainer'], cadence: ['cad', 'pwr', 'trainer'], hr: ['hr'], speed: ['trainer', 'cad'] };
  function source(what) { for (const s of PRIO[what]) if (st[s].status === 'on' && last[what][s]) return s; return null; }
  function value(what) { const s = source(what); if (!s) return null; const v = fresh(what, s, what === 'power' ? 3000 : 4000); return v === null ? 0 : v; }

  // Cadence à partir des tours de manivelle cumulés (CSC et Cycling Power).
  function crankTracker(src) {
    let prev = null;
    return (revs, time) => {
      if (prev) {
        const dr = (revs - prev.r + 65536) % 65536, dt = ((time - prev.t + 65536) % 65536) / 1024;
        if (dt > 0 && dr < 20) put('cadence', src, Math.min(200, dr / dt * 60));
        else if (dr === 0 && now() - prev.at > 2500) put('cadence', src, 0);
        if (dr || dt) prev = { r: revs, t: time, at: now() };
      } else prev = { r: revs, t: time, at: now() };
    };
  }
  function wheelTracker(src) {
    let prev = null;
    return (revs, time) => {
      if (prev) { const dr = revs - prev.r, dt = ((time - prev.t + 65536) % 65536) / 1024; if (dt > 0 && dr >= 0 && dr < 50) put('speed', src, dr * 2.105 / dt * 3.6); }
      prev = { r: revs, t: time };
    };
  }

  const parsers = {
    async trainer(srv) {
      const ftms = await srv.getPrimaryService(0x1826);
      const d = await ftms.getCharacteristic(0x2ad2);
      d.addEventListener('characteristicvaluechanged', e => {
        const v = e.target.value, f = v.getUint16(0, true); let o = 2;
        if (!(f & 1)) { put('speed', 'trainer', v.getUint16(o, true) / 100); o += 2; }
        if (f & 2) o += 2;
        if (f & 4) { put('cadence', 'trainer', v.getUint16(o, true) / 2); o += 2; }
        if (f & 8) o += 2; if (f & 16) o += 3; if (f & 32) o += 2;
        if (f & 64) { put('power', 'trainer', Math.max(0, v.getInt16(o, true))); o += 2; }
      });
      await d.startNotifications();
      try { const c = await ftms.getCharacteristic(0x2ad9); await c.startNotifications(); cp = c; write([0x00]); write([0x07]); } catch (e) { cp = null; }
    },
    async pwr(srv) {
      const c = await (await srv.getPrimaryService(0x1818)).getCharacteristic(0x2a63), crank = crankTracker('pwr');
      c.addEventListener('characteristicvaluechanged', e => {
        const v = e.target.value, f = v.getUint16(0, true);
        put('power', 'pwr', Math.max(0, v.getInt16(2, true)));
        let o = 4 + (f & 1 ? 1 : 0) + (f & 4 ? 2 : 0) + (f & 16 ? 6 : 0);
        if (f & 32 && v.byteLength >= o + 4) crank(v.getUint16(o, true), v.getUint16(o + 2, true));
      });
      await c.startNotifications();
    },
    async cad(srv) {
      const c = await (await srv.getPrimaryService(0x1816)).getCharacteristic(0x2a5b), crank = crankTracker('cad'), wheel = wheelTracker('cad');
      c.addEventListener('characteristicvaluechanged', e => {
        const v = e.target.value, f = v.getUint8(0); let o = 1;
        if (f & 1) { wheel(v.getUint32(o, true), v.getUint16(o + 4, true)); o += 6; }
        if (f & 2 && v.byteLength >= o + 4) crank(v.getUint16(o, true), v.getUint16(o + 2, true));
      });
      await c.startNotifications();
    },
    async hr(srv) {
      const c = await (await srv.getPrimaryService(0x180d)).getCharacteristic(0x2a37);
      c.addEventListener('characteristicvaluechanged', e => { const v = e.target.value; put('hr', 'hr', v.getUint8(0) & 1 ? v.getUint16(1, true) : v.getUint8(1)); });
      await c.startNotifications();
    },
  };

  function write(bytes) { if (!cp) return; const c = cp, b = new Uint8Array(bytes); cpQ = cpQ.then(() => c.writeValueWithResponse ? c.writeValueWithResponse(b) : c.writeValue(b)).catch(() => {}); }
  // Pente envoyée au home trainer (simulation FTMS), entre −10 % et +20 %.
  function setGrade(g) { const v = Math.round(Math.max(-10, Math.min(20, g * 100)) * 100); write([0x11, 0, 0, v & 255, (v >> 8) & 255, 40, 51]); }

  const supported = () => !!(navigator.bluetooth && navigator.bluetooth.requestDevice);
  const NO_BT = 'Bluetooth indisponible dans ce navigateur. Utilise Chrome ou Edge (ordinateur ou Android). Sur iPhone : app Bluefy.';

  async function connect(kind) {
    const K = KINDS[kind], s = st[kind];
    if (!supported()) { s.error = NO_BT; emit('state'); return false; }
    if (s.status === 'on' || s.status === 'wait') return true;
    let dev;
    try { dev = await navigator.bluetooth.requestDevice({ filters: K.filters, optionalServices: K.optional }); }
    catch (e) { if (e.name !== 'NotFoundError') { s.error = e.name === 'SecurityError' || e.name === 'NotAllowedError' ? NO_BT : 'Connexion impossible : ' + e.message; emit('state'); } return false; }
    s.status = 'wait'; s.error = ''; s.name = dev.name || K.label; s.dev = dev; emit('state');
    try {
      const srv = await dev.gatt.connect();
      await parsers[kind](srv);
      s.status = 'on';
      dev.addEventListener('gattserverdisconnected', () => { if (s.dev !== dev) return; s.status = 'off'; s.dev = null; if (kind === 'trainer') cp = null; s.error = s.name + ' s’est déconnecté.'; emit('state'); });
      try { const b = await (await (await srv.getPrimaryService(BATTERY)).getCharacteristic(0x2a19)).readValue(); s.battery = b.getUint8(0); } catch (e) { s.battery = null; }
      try { localStorage.setItem('vv_sensor_' + kind, s.name); } catch (e) { /* stockage indisponible */ }
      emit('state'); return true;
    } catch (e) {
      s.status = 'off'; s.dev = null; s.error = 'Connexion impossible : ' + e.message; try { dev.gatt.disconnect(); } catch (x) { /* déjà coupé */ }
      emit('state'); return false;
    }
  }
  function disconnect(kind) {
    const s = st[kind], dev = s.dev; s.dev = null; s.status = 'off'; s.error = ''; s.battery = null;
    for (const w of Object.keys(last)) delete last[w][kind];
    if (kind === 'trainer') cp = null;
    try { dev && dev.gatt.disconnect(); } catch (e) { /* déjà coupé */ }
    emit('state');
  }
  const lastName = kind => { try { return localStorage.getItem('vv_sensor_' + kind) || ''; } catch (e) { return ''; } };

  /* ---------- Panneau d'affichage (page Capteurs et panneau de la sortie 3D) ---------- */
  const CSS = `.vvs{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr));gap:12px}
.vvs-c{background:#0f1b2e;border:1px solid #23395c;border-radius:14px;padding:14px;color:#e6eefb;display:flex;flex-direction:column;gap:8px;min-width:0}
.vvs-c[data-s="on"]{border-color:#22d3ee;box-shadow:0 0 0 1px #22d3ee33 inset}
.vvs-h{display:flex;align-items:center;justify-content:space-between;gap:8px}.vvs-h b{font-size:16px}
.vvs-pill{font-size:12px;padding:3px 9px;border-radius:999px;background:#1e2d47;color:#9fb3cf;white-space:nowrap}
.vvs-c[data-s="on"] .vvs-pill{background:#0e4f5c;color:#a5f3fc}.vvs-c[data-s="wait"] .vvs-pill{background:#4a3b12;color:#fde68a}
.vvs .vvs-d{margin:0;font-size:13px;color:#9fb3cf;line-height:1.4}
.vvs-v{display:flex;gap:16px;flex-wrap:wrap;min-height:44px;align-items:baseline}
.vvs-v span{font-size:12px;color:#9fb3cf}.vvs-v b{display:block;font-size:26px;font-variant-numeric:tabular-nums;color:#fff}.vvs-v b small{font-size:13px;color:#9fb3cf;margin-left:3px}
.vvs-n{font-size:13px;color:#cbd5e1;overflow-wrap:anywhere}.vvs .vvs-e{font-size:13px;color:#fca5a5;margin:0}
.vvs-btn{appearance:none;border:1px solid #2f4a73;background:#16263f;color:#fff;border-radius:10px;padding:9px 12px;font:inherit;font-weight:600;cursor:pointer}
.vvs-btn.pri{background:#22d3ee;border-color:#22d3ee;color:#04202a}.vvs-btn:focus-visible{outline:2px solid #fff;outline-offset:2px}
.vvs .vvs-warn{grid-column:1/-1;margin:0;padding:10px 12px;border-radius:10px;background:#3b2a10;color:#fde68a;font-size:14px}`;
  let cssDone = false;
  const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const UNITS = { power: ['Puissance', 'W'], cadence: ['Cadence', 'rpm'], hr: ['Fréquence cardiaque', 'bpm'], speed: ['Vitesse', 'km/h'] };
  const SHOWS = { trainer: ['power', 'cadence', 'speed'], pwr: ['power', 'cadence'], cad: ['cadence', 'speed'], hr: ['hr'] };

  function mountPanel(el) {
    if (!cssDone) { const s = document.createElement('style'); s.textContent = CSS; document.head.append(s); cssDone = true; }
    el.classList.add('vvs');
    const draw = () => {
      el.innerHTML = (supported() ? '' : '<p class="vvs-warn">' + esc(NO_BT) + '</p>') + ORDER.map(k => {
        const s = st[k], K = KINDS[k], prev = lastName(k);
        const pill = s.status === 'on' ? 'Connecté' : s.status === 'wait' ? 'Connexion…' : 'Non connecté';
        const vals = SHOWS[k].map(w => '<div><span>' + UNITS[w][0] + '</span><b data-v="' + k + ':' + w + '">—<small>' + UNITS[w][1] + '</small></b></div>').join('');
        return '<section class="vvs-c" data-s="' + s.status + '" aria-label="' + esc(K.label) + '"><div class="vvs-h"><b>' + esc(K.label) + '</b><span class="vvs-pill">' + pill + '</span></div>'
          + '<p class="vvs-d">' + esc(K.desc) + '</p>'
          + (s.status === 'on' ? '<div class="vvs-v">' + vals + '</div><div class="vvs-n">' + esc(s.name) + (s.battery !== null ? ' · batterie ' + s.battery + ' %' : '') + '</div>' : (prev ? '<div class="vvs-n">Dernier appareil : ' + esc(prev) + '</div>' : ''))
          + (s.error ? '<p class="vvs-e" role="alert">' + esc(s.error) + '</p>' : '')
          + '<button type="button" class="vvs-btn ' + (s.status === 'on' ? '' : 'pri') + '" data-vvs="' + k + '"' + (s.status === 'wait' ? ' disabled' : '') + '>' + (s.status === 'on' ? 'Déconnecter' : 'Connecter') + '</button></section>';
      }).join('');
      tick();
    };
    const tick = () => {
      el.querySelectorAll('[data-v]').forEach(b => {
        const [k, w] = b.dataset.v.split(':'), v = fresh(w, k, 4000), used = source(w) === k;
        b.firstChild.textContent = v === null ? '—' : (w === 'speed' ? v.toFixed(1).replace('.', ',') : Math.round(v));
        b.style.opacity = used || v === null ? 1 : 0.55; b.title = used ? 'Valeur utilisée' : 'Valeur non utilisée (un autre capteur est prioritaire)';
      });
    };
    el.addEventListener('click', e => { const b = e.target.closest('[data-vvs]'); if (!b) return; const k = b.dataset.vvs; st[k].status === 'on' ? disconnect(k) : connect(k); });
    const sub = t => { if (!el.isConnected) { subs.delete(sub); clearInterval(iv); return; } if (t === 'state') draw(); };
    subs.add(sub); const iv = setInterval(() => { if (!el.isConnected) { subs.delete(sub); clearInterval(iv); } else tick(); }, 500);
    draw();
    return { destroy() { subs.delete(sub); clearInterval(iv); } };
  }

  const anyOn = () => ORDER.some(k => st[k].status === 'on');
  window.VVSensors = { KINDS, state: st, connect, disconnect, value, source, setGrade, hasControl: () => !!cp, on: f => { subs.add(f); return () => subs.delete(f); }, mountPanel, supported, anyOn, powerConnected: () => st.pwr.status === 'on' || st.trainer.status === 'on' };
})();
