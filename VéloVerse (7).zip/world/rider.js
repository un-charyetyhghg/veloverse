// VéloVerse 3D — cyclistes et vélos « low-poly » construits à partir de la configuration du garage.
// Repère du vélo : x vers l'avant, y vers le haut, z vers la droite (mètres). Expose window.VVRider.
(function () {
  'use strict';
  const { M, Geo, col } = window.VV3D;

  const PALETTE = ['#22d3ee', '#2dd4bf', '#0ea5e9', '#1e3a8a', '#6366f1', '#a855f7', '#ec4899', '#ef4444', '#f97316', '#f59e0b', '#facc15', '#84cc16', '#22c55e', '#ffffff', '#9ca3af', '#111827', '#d6a35e', '#5f6f5c', '#7dd3fc', '#d9f21a'];
  const CATALOG = {
    palette: PALETTE,
    bike: {
      model: [['aero', 'Aéro', 'Tubes larges et roues hautes, pour aller vite sur le plat.'], ['grimpeur', 'Grimpeur', 'Cadre fin et léger, roues basses pour la montagne.'], ['gravel', 'Gravel', 'Pneus larges, cintre évasé, pour tous les chemins.'], ['clm', 'Contre-la-montre', 'Prolongateurs et roue lenticulaire.'], ['rouge-carbone', 'Rouge Carbone', 'Le vélo de la boutique (à acheter d’abord).', 'img/velo-rouge.jpg'], ['givre-rouge', 'Givre Rouge', 'Cadre blanc qui vire au rouge à l’arrière, roues carbone hautes et flancs beiges.', 'img/velo-givre-rouge.jpg'], ['eclair-blanc', 'Éclair Blanc', 'Cadre aéro blanc, tige de selle noire, roues hautes à grands motifs blancs.', 'img/velo-eclair-blanc.jpg'], ['or-olympe', 'Or Olympe', 'Cadre or et noir, roues hautes.'], ['nuit-polaire', 'Nuit Polaire', 'Noir profond qui s’illumine de cyan, jantes à motifs.'], ['aurore', 'Aurore', 'Dégradé violet et rose, flancs beiges.'], ['legende', 'Légende', 'Blanc et or, jantes dorées : le vélo des plus grands.'], ['rubis', 'Rubis', 'Cadre rouge vif, déco noire, roues 45 mm.', 'img/velo-rubis.jpg'], ['celeste', 'Céleste', 'Turquoise intégral, déco sombre, roues hautes.', 'img/velo-celeste.jpg'], ['flamme', 'Flamme', 'Dégradé orange et rouge, avant noir.', 'img/velo-flamme.jpg'], ['braise', 'Braise', 'Rouge qui s’assombrit vers le noir, roues carbone à motifs.', 'img/velo-braise.jpg'], ['neige', 'Neige', 'Blanc nacré, déco bleu nuit, flancs beiges.', 'img/velo-neige.jpg'], ['comete', 'Comète', 'Blanc argenté, cockpit rouge en dégradé, roues hautes.', 'img/velo-comete.jpg'], ['arlequin', 'Arlequin', 'Bleu roi, tube de selle rouge, tube horizontal jaune.', 'img/velo-arlequin.jpg'], ['soleil', 'Soleil', 'Jaune intégral, guidoline et selle jaunes, jantes à motifs jaunes.', 'img/velo-soleil.jpg'], ['meteore', 'Météore', 'Gris pierre et rose vif, tige de selle dorée.', 'img/velo-meteore.jpg'], ['contraste', 'Contraste', 'Aéro noir mat, avant blanc, jantes à grands motifs blancs.', 'img/velo-contraste.jpg'], ['chrono-or', 'Chrono Or', 'Contre-la-montre noir et or, roue lenticulaire, prolongateurs.', 'img/velo-chrono-or.jpg'], ['grenat-cross', 'Grenat Cross', 'Cyclo-cross rouge qui plonge vers le noir, pneus à crampons à flancs beiges.', 'img/velo-grenat-cross.jpg'], ['prisme-or', 'Prisme Or', 'Blanc nacré, lettrage or, jantes blanches à motifs géométriques dorés.', 'img/velo-prisme-or.jpg'], ['lichen', 'Lichen', 'Vert-de-gris satiné, lettrage argent, roues carbone hautes à motifs sombres.', 'img/velo-lichen.jpg'], ['arc-en-ciel', 'Arc-en-ciel', 'Blanc, tube horizontal bleu ciel, filets aux couleurs arc-en-ciel, roues hautes à lettrage blanc.', 'img/velo-arc-en-ciel.jpg'], ['citron-fluo', 'Citron Fluo', 'Jaune fluo qui plonge vers le noir, guidoline fluo, roues hautes à bandeaux fluo.', 'img/velo-citron-fluo.jpg'], ['ivoire', 'Ivoire', 'Blanc mat, tige de selle noire, guidoline blanche, roues hautes à grands motifs blancs.', 'img/velo-ivoire.jpg'], ['azur', 'Azur', 'Bleu ciel nacré, lettrage noir, roues hautes à grands motifs blancs.', 'img/velo-azur.jpg']],
      wheels: [['bas', 'Jantes basses'], ['moyen', 'Profil 45 mm'], ['haut', 'Profil 80 mm'], ['disque', 'Roue lenticulaire'], ['carbone67', 'Carbone 67 mm'], ['batons', 'Carbone 5 bâtons'], ['arcenciel45', 'Carbone 45 arc-en-ciel'], ['or60', 'Carbone 60 or']],
      tyres: [['noir', 'Noirs'], ['beige', 'Flancs beiges']],
    },
    rider: {
      skin: [['s1', '#f2d3bd'], ['s2', '#e0b393'], ['s3', '#c68e6a'], ['s4', '#9b6a48'], ['s5', '#6b4630']],
      helmet: [['route', 'Casque route'], ['aero', 'Casque aéro'], ['casquette', 'Casquette rétro']],
      jerseyPattern: [['uni', 'Uni'], ['bande', 'Bande poitrine'], ['bicolore', 'Bicolore'], ['manches', 'Manches contrastées'], ['col', 'Col et épaules']],
      socks: [['courtes', 'Courtes'], ['hautes', 'Hautes']],
      glasses: [['aucune', 'Sans lunettes', null], ['noires', 'Noires', '#111827'], ['miroir', 'Miroir cyan', '#22d3ee'], ['orange', 'Orange', '#f97316']],
    },
  };
  // Couleurs d'origine des vélos « signature », appliquées quand on choisit le modèle (modifiables ensuite).
  CATALOG.presets = {
    'rouge-carbone': { frameColor: '#ef4444', accentColor: '#ef4444', wheels: 'moyen', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    'givre-rouge': { frameColor: '#ffffff', accentColor: '#ef4444', wheels: 'haut', rimColor: '#111827', tyres: 'beige', tapeColor: '#111827', saddleColor: '#111827' },
    'eclair-blanc': { frameColor: '#ffffff', accentColor: '#ffffff', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    // vélos exclusifs des paliers de niveau
    'or-olympe': { frameColor: '#facc15', accentColor: '#111827', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    'nuit-polaire': { frameColor: '#111827', accentColor: '#22d3ee', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#22d3ee', saddleColor: '#111827' },
    aurore: { frameColor: '#a855f7', accentColor: '#ec4899', wheels: 'haut', rimColor: '#111827', tyres: 'beige', tapeColor: '#ffffff', saddleColor: '#ffffff' },
    legende: { frameColor: '#ffffff', accentColor: '#facc15', wheels: 'haut', rimColor: '#facc15', tyres: 'beige', tapeColor: '#facc15', saddleColor: '#ffffff' },
    rubis: { frameColor: '#ef4444', accentColor: '#ef4444', wheels: 'moyen', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    celeste: { frameColor: '#2dd4bf', accentColor: '#2dd4bf', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    flamme: { frameColor: '#ef4444', accentColor: '#f97316', wheels: 'moyen', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    braise: { frameColor: '#ef4444', accentColor: '#111827', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    neige: { frameColor: '#ffffff', accentColor: '#ffffff', wheels: 'haut', rimColor: '#111827', tyres: 'beige', tapeColor: '#111827', saddleColor: '#111827' },
    comete: { frameColor: '#ffffff', accentColor: '#ef4444', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    arlequin: { frameColor: '#1e3a8a', accentColor: '#0ea5e9', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    soleil: { frameColor: '#facc15', accentColor: '#facc15', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#facc15', saddleColor: '#facc15' },
    meteore: { frameColor: '#9ca3af', accentColor: '#ec4899', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    contraste: { frameColor: '#111827', accentColor: '#ffffff', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    'chrono-or': { frameColor: '#111827', accentColor: '#111827', wheels: 'disque', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    'grenat-cross': { frameColor: '#ef4444', accentColor: '#111827', wheels: 'moyen', rimColor: '#111827', tyres: 'beige', tapeColor: '#111827', saddleColor: '#111827' },
    // vélos ajoutés (photos de la boutique)
    'prisme-or': { frameColor: '#ffffff', accentColor: '#ffffff', wheels: 'haut', rimColor: '#ffffff', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    lichen: { frameColor: '#5f6f5c', accentColor: '#5f6f5c', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    'arc-en-ciel': { frameColor: '#ffffff', accentColor: '#ffffff', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    'citron-fluo': { frameColor: '#d9f21a', accentColor: '#111827', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#d9f21a', saddleColor: '#111827' },
    ivoire: { frameColor: '#ffffff', accentColor: '#ffffff', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#ffffff', saddleColor: '#111827' },
    azur: { frameColor: '#7dd3fc', accentColor: '#7dd3fc', wheels: 'haut', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
  };
  const DEFAULT = {
    rider: { skin: 's2', helmet: 'route', helmetColor: '#ffffff', jerseyPattern: 'bande', jerseyColor: '#22d3ee', jerseyColor2: '#111827', shortsColor: '#111827', socks: 'courtes', socksColor: '#ffffff', shoesColor: '#ffffff', glasses: 'noires', gloves: 'aucun' },
    bike: { model: 'aero', frameColor: '#111827', accentColor: '#22d3ee', wheels: 'moyen', rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
  };
  const opt = (list, id) => (list.find(o => o[0] === id) || list[0]);
  const merge = (cfg, kind) => ({ ...DEFAULT[kind], ...(cfg || {}) });

  const GEOM = {
    aero: { tube: 0.03, head: 0.036, wheels: 'haut', tyre: 0.013 },
    grimpeur: { tube: 0.019, head: 0.026, wheels: 'bas', tyre: 0.012 },
    gravel: { tube: 0.024, head: 0.03, wheels: 'bas', tyre: 0.021, flare: true },
    clm: { tube: 0.032, head: 0.036, wheels: 'disque', tyre: 0.012, aeroBars: true },
    'rouge-carbone': { tube: 0.029, head: 0.034, wheels: 'moyen', tyre: 0.013, darkSeat: true },
    'givre-rouge': { tube: 0.027, head: 0.033, wheels: 'haut', tyre: 0.013, fade: true },
    'eclair-blanc': { tube: 0.033, head: 0.038, wheels: 'haut', tyre: 0.013, darkSeat: true, rimDecal: true, stripe: true },
    'or-olympe': { tube: 0.031, head: 0.036, wheels: 'haut', tyre: 0.013, darkSeat: true, stripe: true },
    'nuit-polaire': { tube: 0.031, head: 0.036, wheels: 'haut', tyre: 0.013, fade: true, rimDecal: true },
    aurore: { tube: 0.027, head: 0.033, wheels: 'haut', tyre: 0.013, fade: true },
    legende: { tube: 0.033, head: 0.038, wheels: 'haut', tyre: 0.013, fade: true, rimDecal: true },
    rubis: { tube: 0.029, head: 0.034, wheels: 'moyen', tyre: 0.013, darkSeat: true, stripe: true },
    celeste: { tube: 0.031, head: 0.036, wheels: 'haut', tyre: 0.013, stripe: true },
    flamme: { tube: 0.028, head: 0.034, wheels: 'moyen', tyre: 0.013, fade: true, forkColor: '#111827', topFade: '#111827', stripeColor: '#e5e7eb' },
    braise: { tube: 0.029, head: 0.034, wheels: 'haut', tyre: 0.013, fade: true, rimDecal: true, stripeColor: '#e5e7eb' },
    neige: { tube: 0.028, head: 0.034, wheels: 'haut', tyre: 0.013, stripe: true, stripeColor: '#1e3a8a', rimDecal: true },
    comete: { tube: 0.032, head: 0.037, wheels: 'haut', tyre: 0.013, darkSeat: true, topFade: '#ef4444', stripe: true },
    arlequin: { tube: 0.032, head: 0.037, wheels: 'haut', tyre: 0.013, seatColor: '#ef4444', topColor: '#facc15', stripe: true, stripeColor: '#ffffff' },
    soleil: { tube: 0.029, head: 0.034, wheels: 'haut', tyre: 0.013, stripe: true, rimDecal: true, decal: '#facc15' },
    meteore: { tube: 0.029, head: 0.034, wheels: 'haut', tyre: 0.013, fade: true, seatColor: '#d6a35e', stripe: true, stripeColor: '#f3f4f6' },
    contraste: { tube: 0.034, head: 0.039, wheels: 'haut', tyre: 0.013, rimDecal: true, darkSeat: true, topFade: '#ffffff', stripe: true, stripeColor: '#f3f4f6' },
    'chrono-or': { tube: 0.034, head: 0.038, wheels: 'disque', tyre: 0.012, aeroBars: true, stripe: true, stripeColor: '#d6a35e' },
    'grenat-cross': { tube: 0.026, head: 0.032, wheels: 'moyen', tyre: 0.02, flare: true, fade: true, stripeColor: '#e5e7eb' }, // cyclo-cross : pneus larges à crampons
    'prisme-or': { tube: 0.031, head: 0.036, wheels: 'haut', tyre: 0.013, stripe: true, stripeColor: '#d6a35e', rimDecal: true, decal: '#d6a35e' },
    lichen: { tube: 0.031, head: 0.036, wheels: 'haut', tyre: 0.013, stripe: true, stripeColor: '#e5e7eb', rimDecal: true, decal: '#4b5563' },
    'arc-en-ciel': { tube: 0.032, head: 0.037, wheels: 'haut', tyre: 0.013, topColor: '#7dd3fc', rainbow: true, rimDecal: true, stripe: true, stripeColor: '#111827' },
    'citron-fluo': { tube: 0.031, head: 0.036, wheels: 'haut', tyre: 0.013, fade: true, rimDecal: true, decal: '#d9f21a', stripeColor: '#111827' },
    ivoire: { tube: 0.027, head: 0.033, wheels: 'haut', tyre: 0.013, darkSeat: true, rimDecal: true, stripe: true, stripeColor: '#d1d5db' },
    azur: { tube: 0.032, head: 0.037, wheels: 'haut', tyre: 0.013, stripe: true, stripeColor: '#111827', rimDecal: true, darkSeat: true },
  };
  const R = 0.34; // rayon de roue (700c)
  const P = {
    rear: [-0.5, R, 0], front: [0.5, R, 0], bb: [-0.06, 0.27, 0],
    seat: [-0.2, 0.78, 0], saddle: [-0.235, 0.955, 0], headTop: [0.36, 0.8, 0], headBot: [0.4, 0.64, 0],
  };
  const z = (p, dz) => [p[0], p[1], dz];
  const hexMix = (a, b, t) => { const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)), A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
  // Tube peint en dégradé : de la couleur c0 (au point a) à c1 (au point b), en n tronçons.
  const fadeTube = (g, a, b, r, c0, c1, n = 6, sides = 7, r1 = r) => { for (let i = 0; i < n; i++) g.tube(mix(a, b, i / n), mix(a, b, (i + 1) / n), r + (r1 - r) * i / n, hexMix(c0, c1, Math.min(1, Math.max(0, (i + 0.5) / n * 1.6 - 0.3))), sides, r + (r1 - r) * (i + 1) / n, false); };
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

  /* ---------- Vélo (cadre fixe) ---------- */
  function buildFrame(g, bike) {
    const G = GEOM[bike.model] || GEOM.aero, F = bike.frameColor, A = bike.accentColor, dark = '#1f2937', metal = '#9ca3af';
    const t = G.tube;
    if (G.topFade) fadeTube(g, P.seat, P.headTop, t, F, G.topFade, 6); // tube horizontal (dégradé vers l'avant)
    else g.tube(P.seat, P.headTop, t, G.topColor || F, 7);     // tube horizontal
    g.tube(P.bb, P.headBot, t * 1.15, F, 7);                  // tube oblique
    if (G.seatColor) g.tube(P.bb, P.seat, t, G.seatColor, 7);  // tube de selle d'une autre couleur
    else if (G.fade) fadeTube(g, P.bb, P.seat, t, A, F, 6);   // tube de selle (dégradé)
    else g.tube(P.bb, P.seat, t, G.darkSeat ? dark : F, 7);   // tube de selle
    g.tube(P.headBot, P.headTop, G.head, G.topFade || A, 8);  // douille de direction
    for (const s of [-1, 1]) {
      g.tube(z(P.bb, s * 0.02), z(P.rear, s * 0.065), t * 0.65, G.fade ? A : F, 6);        // bases
      if (G.fade) fadeTube(g, z(P.rear, s * 0.065), z(P.seat, s * 0.025), t * 0.6, A, F, 5, 6);
      else g.tube(z(P.seat, s * 0.025), z(P.rear, s * 0.065), t * 0.6, F, 6);      // haubans
      if (G.forkColor) g.tube(z(P.headBot, s * 0.035), z(P.front, s * 0.055), t * 0.75, G.forkColor, 6, t * 0.5);
      else if (G.fade) fadeTube(g, z(P.front, s * 0.055), z(P.headBot, s * 0.035), t * 0.5, A, F, 4, 6, t * 0.75);
      else g.tube(z(P.headBot, s * 0.035), z(P.front, s * 0.055), t * 0.75, A, 6, t * 0.5); // fourche
    }
    if (G.rainbow) { const RB = ['#2563eb', '#ef4444', '#111827', '#facc15', '#16a34a']; for (const sd of [-1, 1]) RB.forEach((c, k) => { const t0 = 0.25 + k * 0.1; g.tube(mix(z(P.rear, sd * 0.066), z(P.seat, sd * 0.026), t0), mix(z(P.rear, sd * 0.066), z(P.seat, sd * 0.026), t0 + 0.08), t * 0.66, c, 6); g.tube(mix(z(P.rear, sd * 0.066), z(P.bb, sd * 0.021), t0), mix(z(P.rear, sd * 0.066), z(P.bb, sd * 0.021), t0 + 0.08), t * 0.7, c, 6); }); } // filets arc-en-ciel
    // décor : filet sombre le long du tube oblique (sans logo ni lettrage)
    if (G.fade || G.stripe) for (const s of [-1, 1]) g.tube(z(mix(P.bb, P.headBot, 0.3), s * t * 1.12), z(mix(P.bb, P.headBot, 0.78), s * t * 1.12), t * 0.28, G.stripeColor || dark, 4, t * 0.28, false);
    g.tube(P.seat, P.saddle, 0.014, dark, 6);                  // tige de selle
    g.box(M.chain(M.t(-0.245, 0.965, 0), M.rz(-0.04)), 0.27, 0.035, 0.11, bike.saddleColor);
    g.box(M.t(-0.33, 0.958, 0), 0.08, 0.03, 0.14, bike.saddleColor);
    // poste et cintre
    const stem = [0.45, 0.86, 0];
    g.tube(P.headTop, stem, 0.016, dark, 6);
    g.tube([0.46, 0.86, -0.2], [0.46, 0.86, 0.2], 0.013, bike.tapeColor, 6);
    for (const s of [-1, 1]) {
      const w = G.flare ? 0.25 : 0.2;
      const pts = [[0.46, 0.86, s * 0.2], [0.53, 0.84, s * 0.2], [0.56, 0.78, s * (0.2 + (w - 0.2) * 0.4)], [0.53, 0.72, s * w], [0.46, 0.71, s * w]];
      for (let i = 0; i < pts.length - 1; i++) g.tube(pts[i], pts[i + 1], 0.013, bike.tapeColor, 6);
      g.box(M.t(0.53, 0.875, s * 0.2), 0.05, 0.04, 0.03, dark); // cocottes
      if (G.aeroBars) { g.tube([0.46, 0.88, s * 0.07], [0.68, 0.9, s * 0.07], 0.012, bike.tapeColor, 6); g.box(M.t(0.5, 0.905, s * 0.07), 0.09, 0.02, 0.06, dark); }
    }
    // pédalier : plateau et chaîne
    g.ring(M.t(P.bb[0], P.bb[1], 0.07), 0.07, 0.105, 0.004, '#374151', 20);
    g.ring(M.t(P.rear[0], P.rear[1], 0.07), 0.02, 0.055, 0.004, metal, 14);
    g.tube([P.bb[0], P.bb[1] + 0.105, 0.07], [P.rear[0], P.rear[1] + 0.055, 0.07], 0.004, '#4b5563', 4, 0.004, false);
    g.tube([P.bb[0], P.bb[1] - 0.105, 0.07], [P.rear[0], P.rear[1] - 0.055, 0.07], 0.004, '#4b5563', 4, 0.004, false);
    // dérailleur, étriers
    g.box(M.t(-0.49, 0.25, 0.075), 0.05, 0.08, 0.02, dark);
    g.box(M.t(0.47, 0.42, -0.06), 0.06, 0.05, 0.03, dark);
    g.box(M.t(-0.42, 0.4, -0.07), 0.06, 0.05, 0.03, dark);
  }

  /* ---------- Roue (construite au centre, tourne autour de Z) ---------- */
  function buildWheel(g, bike, rear) {
    const G = GEOM[bike.model] || GEOM.aero;
    let w = bike.wheels || G.wheels;
    if (w === 'disque' && !rear) w = 'haut';
    const depth = { bas: 0.03, moyen: 0.05, haut: 0.08, disque: 0.08, carbone67: 0.068, batons: 0.055, arcenciel45: 0.045, or60: 0.06 }[w] || 0.05;
    const tyre = G.tyre, rimOuter = R - tyre, rimInner = rimOuter - depth;
    g.torus(M.id(), R - tyre * 0.6, tyre, '#151a21', 28, 6);
    if (bike.tyres === 'beige') { g.ring(M.id(), R - tyre * 1.4, R - tyre * 0.75, tyre * 0.85, '#c8a777', 28); }
    g.ring(M.id(), rimInner, rimOuter, 0.012, bike.rimColor, 28);
    // roues de la boutique : motifs de la couleur de la paire (or, ou blanc avec touches arc-en-ciel)
    const WD = { or60: '#d6a35e', arcenciel45: '#f3f4f6' }[w], gd = WD ? { ...G, decal: WD } : G;
    if (w === 'arcenciel45') for (let k = 0; k < 2; k++) ['#ef4444', '#facc15', '#22c55e', '#0ea5e9'].forEach((c, j) => { const u = k * Math.PI + 1.15 + j * 0.06, rm = rimInner + depth * 0.5; for (const sd of [-1, 1]) g.tube([Math.cos(u) * rm, Math.sin(u) * rm, sd * 0.0066], [Math.cos(u + 0.055) * rm, Math.sin(u + 0.055) * rm, sd * 0.0066], depth * 0.32, c, 4, depth * 0.32, false); });
    if ((gd.rimDecal || WD || w === 'carbone67') && w !== 'disque' && w !== 'batons') for (let k = 0; k < 4; k++) { const a0 = k * Math.PI / 2 + 0.2, a1 = a0 + 0.75; for (const sd of [-1, 1]) for (let j = 0; j < 4; j++) { const u = a0 + (a1 - a0) * j / 4, v = a0 + (a1 - a0) * (j + 1) / 4, rm = rimInner + depth * 0.5; g.tube([Math.cos(u) * rm, Math.sin(u) * rm, sd * 0.0065], [Math.cos(v) * rm, Math.sin(v) * rm, sd * 0.0065], depth * 0.28, gd.decal || '#f3f4f6', 4, depth * 0.28, false); } }
    if (w === 'disque') g.ring(M.id(), 0.02, rimInner, 0.016, bike.rimColor, 28);
    else if (w === 'batons') for (let i = 0; i < 5; i++) { // roue à 5 bâtons : larges branches carbone
      const a = i / 5 * Math.PI * 2; g.box(M.chain(M.rz(a), M.t(rimInner / 2 + 0.01, 0, 0)), rimInner - 0.02, 0.045, 0.022, bike.rimColor);
    }
    else for (let i = 0; i < 18; i++) {
      const a = i / 18 * Math.PI * 2, s = i % 2 ? 1 : -1;
      g.tube([0, 0, s * 0.03], [Math.cos(a) * rimInner, Math.sin(a) * rimInner, 0], 0.0025, '#cbd5e1', 3, 0.0025, false);
    }
    g.ring(M.t(0, 0, 0), 0.008, 0.025, 0.04, '#374151', 10);
    g.ring(M.t(0, 0, -0.05), 0.05, 0.075, 0.002, '#d1d5db', 16); // disque de frein
  }

  /* ---------- Cycliste (parties fixes) ---------- */
  function jerseyColors(r) {
    const c1 = r.jerseyColor, c2 = r.jerseyColor2;
    switch (r.jerseyPattern) {
      case 'bande': return { low: c1, mid: c2, up: c1, collar: c1, sleeve: c1 };
      case 'bicolore': return { low: c2, mid: c2, up: c1, collar: c1, sleeve: c1 };
      case 'manches': return { low: c1, mid: c1, up: c1, collar: c2, sleeve: c2 };
      case 'col': return { low: c1, mid: c1, up: c2, collar: c2, sleeve: c2 };
      default: return { low: c1, mid: c1, up: c1, collar: c1, sleeve: c1 };
    }
  }
  const skinOf = r => opt(CATALOG.rider.skin, r.skin)[1];

  function buildBody(g, r, bike) {
    const skin = skinOf(r), J = jerseyColors(r), G = GEOM[bike.model] || GEOM.aero;
    const aero = G.aeroBars;
    const hip = [-0.19, 1.03, 0], sh = aero ? [0.24, 1.27, 0] : [0.2, 1.34, 0];
    // bassin (cuissard) et torse en trois bandes
    g.tube([-0.25, 1.0, 0], [-0.12, 1.07, 0], 0.13, r.shortsColor, 8);
    const seg = (a, b, r0, r1, c) => g.tube(mix(hip, sh, a), mix(hip, sh, b), r0, c, 8, r1, false);
    seg(0, 0.38, 0.13, 0.145, J.low); seg(0.38, 0.66, 0.145, 0.155, J.mid); seg(0.66, 0.92, 0.155, 0.15, J.up);
    seg(0.92, 1.04, 0.15, 0.09, J.collar);
    // épaules
    g.sphere(M.chain(M.t(sh[0], sh[1], 0), M.s(1, 0.7, 1.35)), 0.13, J.up, 4, 8);
    // tête
    const head = aero ? [0.38, 1.44, 0] : [0.35, 1.52, 0];
    g.tube(mix(sh, head, 0.2), mix(sh, head, 0.7), 0.045, skin, 6);
    g.sphere(M.t(head[0], head[1], 0), 0.1, skin, 5, 8);
    // casque
    const hc = r.helmetColor, hx = head[0] - 0.015, hy = head[1] + 0.045;
    if (r.helmet === 'aero') {
      g.sphere(M.chain(M.t(hx, hy, 0), M.s(1.15, 0.82, 0.95)), 0.122, hc, 5, 10, (i) => i === 0 ? hc : hc);
      g.tube([hx - 0.06, hy + 0.01, 0], [hx - 0.3, hy - 0.04, 0], 0.085, hc, 8, 0.012);
      g.box(M.t(head[0] + 0.08, head[1] + 0.01, 0), 0.03, 0.06, 0.2, '#0f172a'); // visière
    } else if (r.helmet === 'casquette') {
      g.cyl(M.t(hx, hy - 0.02, 0), 0.105, 0.098, 0.06, 10, hc);
      g.box(M.chain(M.t(hx + 0.11, hy - 0.02, 0), M.rz(0.25)), 0.09, 0.012, 0.16, hc);
    } else {
      g.sphere(M.chain(M.t(hx, hy, 0), M.s(1.2, 0.78, 1)), 0.122, hc, 5, 10, (i, j) => (j % 3 === 0 && i < 3) ? '#1f2937' : hc);
    }
    // lunettes
    const gl = opt(CATALOG.rider.glasses, r.glasses);
    if (gl[2]) g.box(M.t(head[0] + 0.085, head[1] + 0.005, 0), 0.03, 0.035, 0.19, gl[2]);
    // bras (manche, peau, gant)
    for (const s of [-1, 1]) {
      const S = [sh[0], sh[1] - 0.02, s * 0.17];
      const hand = aero ? [0.6, 0.93, s * 0.07] : [0.52, 0.9, s * 0.2];
      const elbow = aero ? [0.48, 0.96, s * 0.1] : [0.36, 1.12, s * 0.2];
      g.tube(S, mix(S, elbow, 0.55), 0.055, J.sleeve, 6, 0.048);
      g.tube(mix(S, elbow, 0.55), elbow, 0.042, skin, 6, 0.038);
      g.tube(elbow, hand, 0.036, skin, 6, 0.032);
      const gc = r.gloves && r.gloves !== 'aucun' ? r.gloves : skin;
      g.sphere(M.t(hand[0], hand[1], hand[2]), 0.04, gc, 3, 6);
    }
  }

  /* ---------- Parties animées : manivelles et jambes ---------- */
  function buildLegs(g, r, crank) {
    const skin = skinOf(r);
    const L1 = 0.5, L2 = 0.47, cl = 0.17;
    for (const s of [-1, 1]) {
      const a = crank + (s > 0 ? 0 : Math.PI);
      const pedal = [P.bb[0] + Math.sin(a) * cl, P.bb[1] - Math.cos(a) * cl, s * 0.1];
      g.tube([P.bb[0], P.bb[1], s * 0.08], pedal, 0.012, '#111827', 5);               // manivelle
      g.box(M.t(pedal[0], pedal[1], pedal[2]), 0.09, 0.015, 0.07, '#1f2937');          // pédale
      const hipP = [-0.19, 1.0, s * 0.09], foot = [pedal[0] + 0.01, pedal[1] + 0.035, s * 0.1];
      const dx = foot[0] - hipP[0], dy = foot[1] - hipP[1];
      let d = Math.hypot(dx, dy); d = Math.min(d, L1 + L2 - 0.002);
      const ux = dx / Math.hypot(dx, dy), uy = dy / Math.hypot(dx, dy);
      const pa = (L1 * L1 - L2 * L2 + d * d) / (2 * d), h = Math.sqrt(Math.max(0, L1 * L1 - pa * pa));
      let px = -uy, py = ux; if (px < 0) { px = -px; py = -py; } // le genou part vers l'avant
      const knee = [hipP[0] + ux * pa + px * h, hipP[1] + uy * pa + py * h, s * 0.1];
      g.tube(hipP, mix(hipP, knee, 0.62), 0.075, r.shortsColor, 7, 0.06);
      g.tube(mix(hipP, knee, 0.62), knee, 0.06, skin, 7, 0.05);
      const sockFrom = r.socks === 'hautes' ? 0.5 : 0.75;
      g.tube(knee, mix(knee, foot, sockFrom), 0.05, skin, 7, 0.04);
      g.tube(mix(knee, foot, sockFrom), foot, 0.04, r.socksColor, 7, 0.035);
      g.box(M.t(foot[0] + 0.03, foot[1] - 0.005, foot[2]), 0.15, 0.06, 0.075, r.shoesColor);
    }
  }

  /* ---------- Modèle complet ---------- */
  class Model {
    constructor(renderer, cfg) { this.r = renderer; this.set(cfg); this.legGeo = new Geo(); this.legs = renderer.mesh(new Geo(), true); }
    set(cfg) {
      const rider = merge(cfg && cfg.rider, 'rider'), bike = merge(cfg && cfg.bike, 'bike');
      this.cfg = { rider, bike };
      for (const k of ['frame', 'body', 'rw', 'fw']) this.r.free(this[k]);
      const f = new Geo(); buildFrame(f, bike); this.frame = this.r.mesh(f);
      const b = new Geo(); buildBody(b, rider, bike); this.body = this.r.mesh(b);
      const rw = new Geo(); buildWheel(rw, bike, true); this.rw = this.r.mesh(rw);
      const fw = new Geo(); buildWheel(fw, bike, false); this.fw = this.r.mesh(fw);
      this.lastCrank = null;
    }
    // base : matrice de placement dans le monde ; wheel/crank : angles en radians.
    draw(base, wheel, crank, { noRider = false } = {}) {
      const R2 = this.r;
      R2.draw(this.frame, base);
      R2.draw(this.rw, M.chain(base, M.t(P.rear[0], P.rear[1], 0), M.rz(-wheel)));
      R2.draw(this.fw, M.chain(base, M.t(P.front[0], P.front[1], 0), M.rz(-wheel)));
      if (this.lastCrank === null || Math.abs(crank - this.lastCrank) > 0.01) {
        this.legGeo.d.length = 0;
        if (noRider) { const g = this.legGeo, cl = 0.17; for (const s of [-1, 1]) { const a = crank + (s > 0 ? 0 : Math.PI); const pe = [P.bb[0] + Math.sin(a) * cl, P.bb[1] - Math.cos(a) * cl, s * 0.1]; g.tube([P.bb[0], P.bb[1], s * 0.08], pe, 0.012, '#111827', 5); g.box(M.t(pe[0], pe[1], pe[2]), 0.09, 0.015, 0.07, '#1f2937'); } }
        else buildLegs(this.legGeo, this.cfg.rider, crank);
        R2.update(this.legs, this.legGeo); this.lastCrank = crank;
      }
      R2.draw(this.legs, base);
      if (!noRider) R2.draw(this.body, base);
    }
    dispose() { for (const k of ['frame', 'body', 'rw', 'fw', 'legs']) this.r.free(this[k]); }
  }

  // Tenue aléatoire pour les bots (reproductible).
  function randomCfg(rand) {
    const pick = a => a[Math.floor(rand() * a.length)];
    const pal = PALETTE.slice(0, 16).filter(c => c !== '#9ca3af'); // les couleurs ajoutées ensuite ne changent pas les bots
    return {
      rider: { skin: pick(CATALOG.rider.skin)[0], helmet: rand() < 0.8 ? 'route' : 'aero', helmetColor: pick(pal), jerseyPattern: pick(CATALOG.rider.jerseyPattern)[0], jerseyColor: pick(pal), jerseyColor2: pick(pal), shortsColor: rand() < 0.8 ? '#111827' : pick(pal), socks: pick(['courtes', 'hautes']), socksColor: pick(['#ffffff', '#111827', pick(pal)]), shoesColor: pick(['#ffffff', '#111827', pick(pal)]), glasses: pick(CATALOG.rider.glasses)[0], gloves: rand() < 0.5 ? 'aucun' : pick(pal) },
      bike: { model: pick(['aero', 'grimpeur', 'gravel']), frameColor: pick(pal), accentColor: pick(pal), wheels: pick(['bas', 'moyen', 'haut']), rimColor: '#111827', tyres: 'noir', tapeColor: '#111827', saddleColor: '#111827' },
    };
  }

  window.VVRider = { CATALOG, DEFAULT, Model, merge, randomCfg, skinOf, jerseyColors, WHEEL_R: R };
})();
