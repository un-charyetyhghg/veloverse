// VéloVerse — ciel, cycle jour / nuit et météo dynamique.
// Heure et météo se calculent à partir de l'heure (horloge du serveur quand elle est connue) : tous les joueurs du même
// parcours voient le même ciel au même moment, sans service externe. Cycle complet : 40 minutes (jour ≈ 22 min,
// coucher ≈ 3 min, nuit ≈ 12 min, lever ≈ 3 min). La météo change toutes les 15 minutes, avec une transition de 90 s,
// selon le climat de chaque décor (le désert reste presque toujours ensoleillé, le brouillard est fréquent en montagne).
// En plein jour et par beau temps, les couleurs de chaque parcours sont exactement celles d'origine.
// Expose window.VVSky = { Sky, clock, weatherAt, LABEL }.
(function () {
  'use strict';
  const { M, Geo, rng, col } = window.VV3D;
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const mul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
  const clamp01 = v => Math.max(0, Math.min(1, v));
  const smooth = t => { t = clamp01(t); return t * t * (3 - 2 * t); };
  const CYCLE = 40 * 60000;
  // [part du cycle, heure de jeu] : 8 h → 17 h (jour), 17 h → 20 h (coucher), 20 h → 5 h (nuit), 5 h → 8 h (lever)
  const KEYS = [[0, 8], [0.55, 17], [0.625, 20], [0.925, 29], [1, 32]];
  // Heure de jeu et lumière du soleil : night = 1 en pleine nuit, glow = lumière dorée du lever / coucher.
  function clock(nowMs, opts = {}) {
    if (opts.cycle === false) return { hour: 13, night: 0, glow: 0, sunEl: 0.86, sunAz: 0.6, phase: 'day' };
    const c = ((nowMs % CYCLE) + CYCLE) % CYCLE / CYCLE;
    let k = 0; while (k < KEYS.length - 2 && c >= KEYS[k + 1][0]) k++;
    const [c0, h0] = KEYS[k], [c1, h1] = KEYS[k + 1], hour = (h0 + (h1 - h0) * (c - c0) / (c1 - c0)) % 24;
    const el = Math.sin((hour - 6.5) / 12 * Math.PI); // > 0 de 6 h 30 à 18 h 30
    const night = smooth((-el + 0.05) / 0.3), glow = clamp01(1 - Math.abs(el - 0.02) / 0.32) * (1 - night * 0.7);
    const phase = night > 0.6 ? 'night' : glow > 0.35 ? (hour < 12 ? 'dawn' : 'dusk') : 'day';
    return { hour, night, glow, sunEl: el, sunAz: (hour - 6) / 12 * Math.PI, phase };
  }
  const W8 = { littoral: [45, 30, 10, 15], montagne: [35, 25, 25, 15], canyon: [72, 21, 2, 5], foret: [30, 30, 20, 20], ville: [40, 30, 10, 20], campagne: [45, 30, 10, 15] };
  const KINDS = ['clear', 'cloudy', 'fog', 'rain'];
  const PARAMS = { clear: { cloud: 0.12, fog: 0, rain: 0 }, cloudy: { cloud: 0.85, fog: 0.08, rain: 0 }, fog: { cloud: 0.55, fog: 1, rain: 0 }, rain: { cloud: 1, fog: 0.35, rain: 1 } };
  const LABEL = { clear: 'Ensoleillé', cloudy: 'Nuageux', fog: 'Brouillard', rain: 'Pluie' };
  const SLOT = 15 * 60000, BLEND = 90000;
  const hash = (a, b) => { let h = (a * 374761393 + b * 668265263) >>> 0; h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0; return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  function slotKind(theme, seed, slot) {
    const w = W8[theme] || W8.campagne, t = w.reduce((a, b) => a + b, 0); let r = hash(seed + 7, slot) * t;
    for (let i = 0; i < 4; i++) { r -= w[i]; if (r < 0) return KINDS[i]; } return 'clear';
  }
  // Météo à un instant : paramètres continus (nuages, brouillard, pluie) avec transition progressive entre deux créneaux.
  function weatherAt(theme, seed, nowMs, opts = {}) {
    if (opts.dynamic === false) return { ...PARAMS.clear, kind: 'clear', next: 'clear', t: 0 };
    const slot = Math.floor(nowMs / SLOT), a = slotKind(theme, seed, slot), b = slotKind(theme, seed, slot + 1);
    const t = smooth((nowMs - slot * SLOT - (SLOT - BLEND)) / BLEND), A = PARAMS[a], B = PARAMS[b];
    return { cloud: A.cloud + (B.cloud - A.cloud) * t, fog: A.fog + (B.fog - A.fog) * t, rain: A.rain + (B.rain - A.rain) * t, kind: t > 0.5 ? b : a, next: b, t, nextAt: (slot + 1) * SLOT };
  }

  class Sky {
    constructor(R, route, W, opts = {}) {
      this.R = R; this.route = route; this.W = W; this.opts = { cycle: true, dynamic: true, quality: 'high', ...opts };
      const T = window.VVWorld.THEMES[route.theme];
      this.base = { sky: col(T.sky), fog: col(T.fog), ground: col(T.ground), far: T.far, near: Math.round(T.far * 0.18) };
      this.cloudY = W.maxE + 520; this.st = null; this.domeAt = 0;
      // dôme du ciel (couleurs recalculées 4 fois par seconde)
      this.domeGeo = new Geo(); this.buildDome(); this.dome = R.mesh(this.domeGeo, true);
      const g = new Geo(), rd = rng(route.seed * 31 + 5);
      // nuages : 60 amas aplatis sur une tuile de 6 km, dessinée 3 × 3 fois autour du cycliste
      for (let k = 0; k < 60; k++) { const x = (rd() - 0.5) * 6000, z = (rd() - 0.5) * 6000, s = 140 + rd() * 260;
        for (let j = 0; j < 4; j++) g.sphere(M.chain(M.t(x + (rd() - 0.5) * s * 1.4, (rd() - 0.5) * 30, z + (rd() - 0.5) * s), M.s(1.6, 0.42, 1.1)), s * (0.45 + rd() * 0.4), j % 2 ? '#ffffff' : '#eef2f6', 3, 7); }
      this.clouds = R.mesh(g); this.cloudsPer = g.count / 60;
      // pluie : traits fins (deux plans croisés) dans un bloc de 70 × 40 × 70 m autour de la caméra
      const rg = new Geo(), rr = rng(99);
      for (let k = 0; k < 1400; k++) { const x = (rr() - 0.5) * 70, y = rr() * 40, z = (rr() - 0.5) * 70, L = 0.9 + rr() * 0.5, w = 0.018;
        rg.quad([x - w, y, z], [x + w, y, z], [x + w + 0.12, y + L, z], [x - w + 0.12, y + L, z], '#c9d6e3'); rg.quad([x, y, z - w], [x, y, z + w], [x + 0.12, y + L, z + w], [x + 0.12, y + L, z - w], '#b8c7d6'); }
      this.rain = R.mesh(rg); this.rainPer = rg.count / 1400;
      // étoiles et disque du soleil / de la lune
      const sg = new Geo(), sr = rng(7);
      for (let k = 0; k < 420; k++) { const a = sr() * 6.283, e = 0.08 + Math.pow(sr(), 0.7) * 1.45, R0 = 2400, x = Math.cos(a) * Math.cos(e) * R0, y = Math.sin(e) * R0, z = Math.sin(a) * Math.cos(e) * R0, s = 3 + sr() * 5;
        sg.quad([x - s, y, z], [x, y - s, z], [x + s, y, z], [x, y + s, z], sr() < 0.15 ? '#cfe1ff' : '#ffffff'); }
      this.stars = R.mesh(sg);
      const dg = new Geo(); dg.sphere(M.id(), 70, '#ffffff', 6, 12); this.disc = R.mesh(dg);
    }
    buildDome(colors) {
      const g = this.domeGeo; g.d.length = 0;
      const RINGS = [-0.35, -0.05, 0.04, 0.12, 0.25, 0.42, 0.65, 1.0, 1.5708], SEG = 18, R0 = 2600;
      const P = (e, a) => [Math.cos(a) * Math.cos(e) * R0, Math.sin(e) * R0, Math.sin(a) * Math.cos(e) * R0];
      for (let i = 0; i < RINGS.length - 1; i++) for (let j = 0; j < SEG; j++) {
        const a0 = j / SEG * 6.2832, a1 = (j + 1) / SEG * 6.2832, e0 = RINGS[i], e1 = RINGS[i + 1];
        const c = (e, a) => colors ? colors(e, a) : [1, 1, 1];
        const p = [P(e0, a0), P(e0, a1), P(e1, a1), P(e1, a0)], cc = [c(e0, a0), c(e0, a1), c(e1, a1), c(e1, a0)];
        for (const [x, y, z] of [[0, 1, 2], [0, 2, 3]]) for (const k of [x, y, z]) g.d.push(p[k][0], p[k][1], p[k][2], 0, 1, 0, cc[k][0], cc[k][1], cc[k][2], 0);
      }
    }
    // État du ciel à l'instant : couleurs, lumière, brouillard (appliqués au moteur), météo et heure.
    update(nowMs, eye) {
      const o = this.opts, k = clock(nowMs, o), w = weatherAt(this.route.theme, this.route.seed, nowMs, o), B = this.base;
      const night = k.night, glow = k.glow * (1 - w.cloud * 0.7), cl = w.cloud, fg = w.fog, rn = w.rain;
      // couleurs du jour (identiques au thème par beau temps), coucher doré, nuit bleu nuit ; nuages et pluie : gris
      const grayDay = col('#c4ccd4'), grayNight = col('#1f2836'), fogWhite = col('#dfe5ea');
      let fog = B.fog, sky = B.sky, top = mul(B.sky, 0.82);
      const cloudK = smooth((cl - 0.3) / 0.7);
      fog = mix(fog, grayDay, cloudK * 0.55); sky = mix(sky, grayDay, cloudK * 0.5); top = mix(top, mul(grayDay, 0.85), cloudK * 0.6);
      fog = mix(fog, fogWhite, fg * 0.7); sky = mix(sky, fogWhite, fg * 0.5); top = mix(top, fogWhite, fg * 0.6);
      const sunset = col('#f0a06a'), sunsetTop = col('#6b7bb4'), sunsetFog = col('#e7b590');
      fog = mix(fog, sunsetFog, glow * 0.75); top = mix(top, sunsetTop, glow * 0.6); sky = mix(sky, sunset, glow * 0.35);
      const nightTop = col('#081227'), nightFog = col('#1b2843'), nightSky = col('#2a3c63');
      fog = mix(fog, mix(nightFog, grayNight, cloudK * 0.6), night); top = mix(top, mix(nightTop, grayNight, cloudK * 0.7), night); sky = mix(sky, nightSky, night);
      const dark = 1 - rn * 0.22; fog = mul(fog, dark); top = mul(top, dark); sky = mul(sky, dark);
      // soleil (ou lune la nuit) : direction et intensité ; plein jour = lumière d'origine
      const dayDir = [0.45, 0.8, 0.35], el = Math.max(0.08, k.sunEl), low = [Math.cos(k.sunAz) * 0.9, el, Math.sin(k.sunAz) * 0.5];
      const lowK = clamp01(1 - (k.sunEl - 0.25) / 0.35);
      let dir = mix(dayDir, low, lowK);
      let sunC = mix([0.78, 0.78, 0.78], [0.95, 0.66, 0.45], glow);
      if (night > 0) { dir = mix(dir, [-0.4, 0.7, -0.3], night); sunC = mix(sunC, [0.2, 0.25, 0.36], night); }
      // la nuit, nuages et pluie n'assombrissent presque plus la lumière lunaire : la route reste lisible
      sunC = mul(sunC, Math.max(night * 0.75, 1 - cl * 0.5 - rn * 0.15 + 0.06));
      const amb = 0.62 * (1 - night * 0.38) + cloudK * 0.06 - rn * 0.04 * (1 - night);
      const ground = mix(B.ground, mul(B.ground, 0.45), night);
      // visibilité : brouillard plus dense, mais la route reste toujours visible (au moins 380 m)
      const far = Math.max(380, B.far * (1 - fg * 0.66) * (1 - rn * 0.3) * (1 - night * 0.12)), near = Math.max(30, B.near * (1 - fg * 0.75) * (1 - rn * 0.3));
      this.R.env({ sky, fog, ground, near, far, sun: dir, amb, sunC });
      this.st = { k, w, top, fog, night, glow, cl, rn, dir, sunDisc: night < 0.5 ? mix([1, 0.96, 0.85], [1, 0.62, 0.32], glow) : [0.86, 0.9, 1] };
      if (nowMs - this.domeAt > 250) { this.domeAt = nowMs;
        const sAz = k.sunAz, sunHalo = night < 0.5 ? glow : 0;
        this.buildDome((e, a) => { const t = smooth((e + 0.05) / 0.9); let c = mix(fog, top, t);
          if (sunHalo > 0.02) { const d = Math.cos(a - sAz); c = mix(c, col('#ffb37a'), sunHalo * Math.max(0, d) ** 3 * (1 - t) * 0.8); }
          return c; });
        this.R.update(this.dome, this.domeGeo); }
      return this.st;
    }
    // Dessin après le décor (le décor proche masque déjà le ciel : moins de calcul).
    draw(eye, nowMs) {
      const R = this.R, s = this.st; if (!s) return;
      R.drawUnlit(this.dome, M.t(eye[0], eye[1] - 120, eye[2]), [1, 1, 1], 0);
      if (s.night > 0.25 && s.cl < 0.85) R.drawUnlit(this.stars, M.t(eye[0], eye[1], eye[2]), mul([1, 1, 1], (s.night - 0.25) / 0.75 * (1 - s.cl)), 0);
      // soleil / lune, cachés par un ciel couvert
      if (s.cl < 0.8) { const d = s.night > 0.5 ? [-s.dir[0], Math.max(0.25, s.dir[1]), -s.dir[2]] : s.dir, n = Math.hypot(...d), D = 2300;
        R.drawUnlit(this.disc, M.chain(M.t(eye[0] + d[0] / n * D, eye[1] + d[1] / n * D, eye[2] + d[2] / n * D), M.s(s.night > 0.5 ? 0.7 : 1, s.night > 0.5 ? 0.7 : 1, s.night > 0.5 ? 0.7 : 1)), s.sunDisc, 0); }
      // nuages : couverture selon la météo, teinte selon l'heure ; dérive lente avec le vent
      if (this.opts.quality !== 'low' || s.cl > 0.6) {
        const n = Math.round(60 * Math.min(1, 0.15 + s.cl)), tint = mix(mix([1, 1, 1], [0.62, 0.66, 0.72], smooth((s.cl - 0.5) * 2) * 0.9 + s.rn * 0.1), mul([0.2, 0.24, 0.33], 1), s.night * 0.9);
        const tg = mix(tint, [1, 0.72, 0.55], s.glow * 0.6), drift = (nowMs / 1000 * 4) % 6000, tx = Math.round((eye[0] - drift) / 6000) * 6000 + drift, tz = Math.round(eye[2] / 6000) * 6000;
        for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) R.drawUnlit(this.clouds, M.t(tx + i * 6000, this.cloudY, tz + j * 6000), tg, 0.55, n * this.cloudsPer);
      }
      // pluie : deux blocs empilés qui tombent, centrés sur la caméra
      if (s.rn > 0.04) {
        const n = Math.round(1400 * s.rn * (this.opts.quality === 'low' ? 0.35 : 1)), fall = (nowMs / 1000 * 18) % 40, bx = Math.floor(eye[0] / 70) * 70, bz = Math.floor(eye[2] / 70) * 70;
        const tint = mul([1, 1, 1], 1 - s.night * 0.6);
        for (const dy of [0, 40]) for (const [ox, oz] of [[0, 0], [70, 0], [0, 70], [70, 70]]) R.drawUnlit(this.rain, M.t(bx + ox - 35, eye[1] - 20 + dy - fall, bz + oz - 35), tint, 1, n * this.rainPer);
      }
    }
    dispose() { for (const m of [this.dome, this.clouds, this.rain, this.stars, this.disc]) this.R.free(m); }
  }
  window.VVSky = { Sky, clock, weatherAt, LABEL, PARAMS };
})();
