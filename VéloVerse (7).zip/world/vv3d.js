// VéloVerse 3D — petit moteur WebGL « low-poly » (ombrage plat, couleurs par sommet, brouillard).
// Aucune dépendance. Expose window.VV3D.
(function () {
  'use strict';
  /* ---------- Maths (matrices colonne par colonne, comme WebGL) ---------- */
  const M = {
    id: () => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
    mul(a, b) {
      const o = new Array(16);
      for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
        o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
      return o;
    },
    t: (x, y, z) => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1],
    s: (x, y, z) => [x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1],
    rx: a => { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]; },
    ry: a => { const c = Math.cos(a), s = Math.sin(a); return [c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]; },
    rz: a => { const c = Math.cos(a), s = Math.sin(a); return [c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; },
    chain(...ms) { return ms.reduce((a, b) => M.mul(a, b)); },
    persp(fov, asp, n, f) { const t = 1 / Math.tan(fov / 2); return [t / asp, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) / (n - f), -1, 0, 0, 2 * f * n / (n - f), 0]; },
    lookAt(e, c, up = [0, 1, 0]) {
      let z = norm(sub(e, c)), x = norm(cross(up, z)), y = cross(z, x);
      return [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -dot(x, e), -dot(y, e), -dot(z, e), 1];
    },
    apply(m, p) { return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]]; },
  };
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const scl = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const len = a => Math.hypot(a[0], a[1], a[2]);
  const norm = a => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

  const hexCache = {};
  function col(h) {
    if (Array.isArray(h)) return h;
    if (hexCache[h]) return hexCache[h];
    const n = parseInt(h.slice(1), 16);
    return (hexCache[h] = [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]);
  }
  const shade = (h, k) => { const c = col(h); return [Math.min(1, c[0] * k), Math.min(1, c[1] * k), Math.min(1, c[2] * k)]; };

  // Générateur pseudo-aléatoire reproductible.
  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /* ---------- Construction de géométrie ---------- */
  class Geo {
    // sw : souplesse au vent (herbe, fleurs). { y0, h } → poids 0 au pied, 1 à la pointe ; null = rigide.
    constructor() { this.d = []; this.sw = null; }
    tri(a, b, c, color) {
      const n = norm(cross(sub(b, a), sub(c, a)));
      const k = col(color), d = this.d, sw = this.sw;
      const w = q => sw ? Math.pow(Math.max(0, Math.min(1, (q[1] - sw.y0) / sw.h)), 1.5) * (sw.k || 1) : 0;
      d.push(a[0], a[1], a[2], n[0], n[1], n[2], k[0], k[1], k[2], w(a), b[0], b[1], b[2], n[0], n[1], n[2], k[0], k[1], k[2], w(b), c[0], c[1], c[2], n[0], n[1], n[2], k[0], k[1], k[2], w(c));
    }
    quad(a, b, c, d, color) { this.tri(a, b, c, color); this.tri(a, c, d, color); }
    get count() { return this.d.length / 10; }
    box(m, w, h, d, color, colorTop) {
      const x = w / 2, y = h / 2, z = d / 2, P = p => M.apply(m, p);
      const v = [[-x, -y, -z], [x, -y, -z], [x, y, -z], [-x, y, -z], [-x, -y, z], [x, -y, z], [x, y, z], [-x, y, z]].map(P);
      this.quad(v[4], v[5], v[6], v[7], color); this.quad(v[1], v[0], v[3], v[2], color);
      this.quad(v[5], v[1], v[2], v[6], color); this.quad(v[0], v[4], v[7], v[3], color);
      this.quad(v[7], v[6], v[2], v[3], colorTop || color); this.quad(v[0], v[1], v[5], v[4], color);
    }
    // Cylindre/cône le long de Y, de y=0 à y=h.
    cyl(m, r0, r1, h, seg, color, caps = true, colorTop) {
      const P = p => M.apply(m, p), b = [], t = [];
      for (let i = 0; i < seg; i++) { const a = i / seg * Math.PI * 2, c = Math.cos(a), s = Math.sin(a); b.push(P([c * r0, 0, s * r0])); t.push(P([c * r1, h, s * r1])); }
      for (let i = 0; i < seg; i++) { const j = (i + 1) % seg; if (r1 > 0) this.quad(b[i], t[i], t[j], b[j], color); else this.tri(b[i], t[i], b[j], color); }
      if (caps) { const cb = P([0, 0, 0]), ct = P([0, h, 0]); for (let i = 0; i < seg; i++) { const j = (i + 1) % seg; this.tri(cb, b[i], b[j], color); if (r1 > 0) this.tri(ct, t[j], t[i], colorTop || color); } }
    }
    // Tube entre deux points (cadres, membres).
    tube(p0, p1, r0, color, seg = 6, r1 = r0, caps = true) {
      const d = sub(p1, p0), L = len(d); if (L < 1e-5) return;
      const dir = scl(d, 1 / L), ref = Math.abs(dir[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
      const u = norm(cross(dir, ref)), v = cross(dir, u), a = [], b = [];
      for (let i = 0; i < seg; i++) { const t = i / seg * Math.PI * 2, c = Math.cos(t), s = Math.sin(t); const o = add(scl(u, c), scl(v, s)); a.push(add(p0, scl(o, r0))); b.push(add(p1, scl(o, r1))); }
      for (let i = 0; i < seg; i++) { const j = (i + 1) % seg; this.quad(a[j], b[j], b[i], a[i], color); }
      if (caps) for (let i = 0; i < seg; i++) { const j = (i + 1) % seg; this.tri(p0, a[i], a[j], color); this.tri(p1, b[j], b[i], color); }
    }
    sphere(m, r, color, lat = 5, lon = 8, colorFn) {
      const P = (la, lo) => { const th = la / lat * Math.PI, ph = lo / lon * Math.PI * 2; return M.apply(m, [r * Math.sin(th) * Math.cos(ph), r * Math.cos(th), r * Math.sin(th) * Math.sin(ph)]); };
      for (let i = 0; i < lat; i++) for (let j = 0; j < lon; j++) {
        const c = colorFn ? colorFn(i, j) : color;
        const a = P(i, j), b = P(i + 1, j), cc = P(i + 1, j + 1), d = P(i, j + 1);
        if (i === 0) this.tri(a, cc, b, c); else if (i === lat - 1) this.tri(a, d, b, c); else this.quad(a, d, cc, b, c);
      }
    }
    // Tore dans le plan XY (axe Z) : pneus.
    torus(m, R, r, color, segR = 24, segr = 6) {
      const P = (i, j) => { const a = i / segR * Math.PI * 2, b = j / segr * Math.PI * 2, rr = R + r * Math.cos(b); return M.apply(m, [rr * Math.cos(a), rr * Math.sin(a), r * Math.sin(b)]); };
      for (let i = 0; i < segR; i++) for (let j = 0; j < segr; j++) this.quad(P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1), color);
    }
    // Anneau plat dans le plan XY (jantes, disques), visible des deux côtés.
    ring(m, r0, r1, z, color, seg = 24) {
      for (let i = 0; i < seg; i++) {
        const a = i / seg * Math.PI * 2, b = (i + 1) / seg * Math.PI * 2;
        const p = (r, t, zz) => M.apply(m, [r * Math.cos(t), r * Math.sin(t), zz]);
        for (const zz of [z, -z]) { const q = [p(r0, a, zz), p(r1, a, zz), p(r1, b, zz), p(r0, b, zz)]; if (zz >= 0) this.quad(q[0], q[1], q[2], q[3], color); else this.quad(q[3], q[2], q[1], q[0], color); }
      }
    }
  }

  /* ---------- Rendu ---------- */
  // Vent : les sommets souples (attribut s) ondulent, avec des rafales qui traversent le paysage (Wd = temps, force).
  const VS = `attribute vec3 p;attribute vec3 n;attribute vec3 c;attribute float s;uniform mat4 P,V,Mo;uniform vec2 Wd;varying vec3 vc;varying float vd;varying vec3 vn;
void main(){vec4 w=Mo*vec4(p,1.);if(s>0.&&Wd.y>0.){float t=Wd.x;float gust=.55+.45*sin(t*.45+w.x*.012+w.z*.009);float sway=sin(t*2.2+w.x*.35+w.z*.27)*.65+sin(t*3.9+w.x*.8)*.25+.55;w.xz+=vec2(.26,.14)*s*sway*gust*Wd.y;w.y-=.05*s*gust*Wd.y;}
vec4 e=V*w;vd=-e.z;vn=normalize(mat3(Mo)*n);vc=c;gl_Position=P*e;}`;
  // Ux.x = 1 : objet sans éclairage (ciel, nuages, pluie, étoiles) teinté par Ti ; Ux.y = part du brouillard appliquée.
  // Sc = couleur × intensité du soleil (ou de la lune). Valeurs par défaut : rendu identique à la version sans météo.
  const FS = `precision mediump float;varying vec3 vc;varying float vd;varying vec3 vn;uniform vec3 L,F,Sky,Gnd,Sc,Ti;uniform vec2 Fd,Ux;uniform float Amb;
void main(){float f=clamp((vd-Fd.x)/(Fd.y-Fd.x),0.,1.);if(Ux.x>.5){gl_FragColor=vec4(mix(vc*Ti,F,f*Ux.y),1.);return;}
vec3 nn=gl_FrontFacing?vn:-vn;float d=max(dot(nn,L),0.);vec3 hemi=mix(Gnd,Sky,nn.y*.5+.5);vec3 col=vc*(hemi*Amb+d*Sc);gl_FragColor=vec4(mix(col,F,f),1.);}`;

  class Renderer {
    constructor(canvas) {
      this.canvas = canvas;
      const gl = canvas.getContext('webgl', { antialias: true, preserveDrawingBuffer: true }) || canvas.getContext('experimental-webgl');
      if (!gl) throw new Error('WebGL indisponible sur cet appareil.');
      this.gl = gl;
      const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
      const pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
      this.a = { p: gl.getAttribLocation(pr, 'p'), n: gl.getAttribLocation(pr, 'n'), c: gl.getAttribLocation(pr, 'c'), s: gl.getAttribLocation(pr, 's') };
      this.u = {}; for (const k of ['P', 'V', 'Mo', 'L', 'F', 'Fd', 'Sky', 'Gnd', 'Amb', 'Wd', 'Sc', 'Ti', 'Ux']) this.u[k] = gl.getUniformLocation(pr, k);
      this.wind = 0; // force du vent sur l'herbe (0 = immobile)
      gl.enable(gl.DEPTH_TEST); // formes vues des deux côtés : la normale est retournée dans le shader
      this.env({});
    }
    env({ sky = '#a9d4ef', fog = '#c9e3f2', ground = '#7a8a6a', near = 120, far = 900, sun = [0.45, 0.8, 0.35], amb = 0.62, sunC = [0.78, 0.78, 0.78] }) {
      this.skyC = typeof sky === 'string' ? col(sky) : sky; this.fogC = typeof fog === 'string' ? col(fog) : fog; this.gndC = typeof ground === 'string' ? col(ground) : ground;
      this.fogN = near; this.fogF = far; this.sun = norm(sun); this.amb = amb; this.sunC = sunC;
    }
    mesh(geo, dynamic = false) { const m = { buf: this.gl.createBuffer(), count: 0, dynamic }; this.update(m, geo); return m; }
    update(m, geo) { const gl = this.gl; gl.bindBuffer(gl.ARRAY_BUFFER, m.buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(geo.d), m.dynamic ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW); m.count = geo.count; }
    free(m) { if (m && m.buf) this.gl.deleteBuffer(m.buf); }
    resize() {
      const c = this.canvas, dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, Math.round(c.clientWidth * dpr)), h = Math.max(1, Math.round(c.clientHeight * dpr));
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
      return c.width / c.height;
    }
    begin(view, fov = 0.95) {
      const gl = this.gl, asp = this.resize();
      gl.viewport(0, 0, this.canvas.width, this.canvas.height);
      gl.clearColor(this.fogC[0], this.fogC[1], this.fogC[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.uniformMatrix4fv(this.u.P, false, M.persp(fov, asp, 0.25, 3000)); gl.uniformMatrix4fv(this.u.V, false, view);
      gl.uniform3fv(this.u.L, this.sun); gl.uniform3fv(this.u.F, this.fogC); gl.uniform2f(this.u.Fd, this.fogN, this.fogF);
      gl.uniform3fv(this.u.Sky, this.skyC); gl.uniform3fv(this.u.Gnd, this.gndC); gl.uniform1f(this.u.Amb, this.amb);
      gl.uniform2f(this.u.Wd, (performance.now() / 1000) % 3600, this.wind);
      gl.uniform3fv(this.u.Sc, this.sunC); gl.uniform3f(this.u.Ti, 1, 1, 1); gl.uniform2f(this.u.Ux, 0, 1);
    }
    // Objet sans éclairage (ciel, nuages, pluie) : teinte, part de brouillard et nombre de sommets dessinés (densité).
    drawUnlit(m, model = M.id(), tint = [1, 1, 1], fog = 1, count) {
      if (!m || !m.count) return;
      const gl = this.gl; gl.uniform3fv(this.u.Ti, tint); gl.uniform2f(this.u.Ux, 1, fog);
      const c = m.count; if (count !== undefined) m.count = Math.max(0, Math.min(c, count - count % 3));
      this.draw(m, model); m.count = c;
      gl.uniform2f(this.u.Ux, 0, 1);
    }
    draw(m, model = M.id()) {
      if (!m || !m.count) return;
      const gl = this.gl;
      gl.bindBuffer(gl.ARRAY_BUFFER, m.buf);
      gl.uniformMatrix4fv(this.u.Mo, false, model);
      const S = 40;
      gl.enableVertexAttribArray(this.a.p); gl.vertexAttribPointer(this.a.p, 3, gl.FLOAT, false, S, 0);
      gl.enableVertexAttribArray(this.a.n); gl.vertexAttribPointer(this.a.n, 3, gl.FLOAT, false, S, 12);
      gl.enableVertexAttribArray(this.a.c); gl.vertexAttribPointer(this.a.c, 3, gl.FLOAT, false, S, 24);
      if (this.a.s >= 0) { gl.enableVertexAttribArray(this.a.s); gl.vertexAttribPointer(this.a.s, 1, gl.FLOAT, false, S, 36); }
      gl.drawArrays(gl.TRIANGLES, 0, m.count);
    }
  }

  window.VV3D = { M, Geo, Renderer, rng, col, shade, v: { sub, add, scl, dot, cross, len, norm, lerp } };
})();
