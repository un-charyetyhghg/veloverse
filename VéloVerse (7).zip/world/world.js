// VéloVerse 3D — parcours : profils, tracés, décors par thème, estimation de durée. Expose window.VVWorld.
(function () {
  'use strict';
  const { M, Geo, rng, col, shade } = window.VV3D;
  const STEP = 10;          // un point tous les 10 m
  const CHUNK = 20;         // 20 points = 200 m par tronçon de décor

  // Catalogue des parcours. Les quatre premiers sont ceux de l'accueil.
  const ROUTES = [
    { id: 'cap-horizon', name: 'Cap Horizon', theme: 'littoral', km: 32, dplus: 480, level: 'Facile', lv: 1, seed: 11, img: 'img/r1.jpg', desc: 'Une corniche au-dessus de la mer, puis une longue promenade en planches le long des plages.' },
    { id: 'col-des-lumieres', name: 'Col des Lumières', theme: 'montagne', km: 78, dplus: 1420, level: 'Difficile', lv: 3, seed: 23, img: 'img/r2.jpg', desc: 'Une vallée verte puis une grande montée en lacets jusqu’aux névés du col.' },
    { id: 'valley-loop', name: 'Valley Loop', theme: 'canyon', km: 56, dplus: 860, level: 'Moyen', lv: 2, seed: 37, img: 'img/r3.jpg', desc: 'Une boucle roulante au pied des falaises rouges et des mesas.' },
    { id: 'lac-des-sapins', name: 'Lac des Sapins', theme: 'foret', km: 48, dplus: 720, level: 'Moyen', lv: 2, seed: 41, img: 'img/r4.jpg', desc: 'Une route en sous-bois qui longe un lac d’altitude bordé de sapins.' },
    { id: 'vieux-port', name: 'Vieux Port', theme: 'ville', km: 24, dplus: 210, level: 'Facile', lv: 1, seed: 53, img: null, desc: 'Une boucle à travers un vieux bourg de bord de mer : maisons de brique, jardins, grands arbres et quais du port.' },
    { id: 'prairies-dor', name: 'Prairies d’Or', theme: 'campagne', km: 41, dplus: 390, level: 'Facile', lv: 1, seed: 67, img: null, desc: 'Des champs de blé, des bottes de foin et des fermes sur de douces collines.' },
    // parcours de sprint : courts, presque plats, longues lignes droites reliées par des virages larges (réseau de routes de campagne)
    { id: 'plaine-des-haies', name: 'Plaine des Haies', theme: 'campagne', km: 14, dplus: 24, level: 'Sprint', lv: 1, seed: 83, img: null, layout: 'reseau', sprint: true, brNames: ['Chemin des Haies', 'Route des Fermes', 'Chemin du Lavoir', 'Allée des Peupliers', 'Chemin des Prés'], segNames: ['Sprint des Haies', 'Sprint des Peupliers', 'Sprint du Calvaire', 'Sprint des Prés'], relNames: ['Relance du Carrefour', 'Relance des Fermes'], desc: 'Un réseau de routes de bocage tout plat : longues lignes droites entre les haies et les prés, virages larges, chemins de ferme qui bouclent. Idéal pour sprinter.' },
    { id: 'criterium-du-bourg', name: 'Critérium du Bourg', theme: 'ville', km: 11, dplus: 18, level: 'Sprint', lv: 1, seed: 97, img: null, layout: 'reseau', sprint: true, brNames: ['Rue de l’Église', 'Rue des Jardins', 'Rue du Lavoir', 'Rue des Tilleuls', 'Rue du Marché'], segNames: ['Sprint de la Grand-Rue', 'Sprint de la Mairie', 'Sprint du Champ de Foire', 'Sprint des Remparts'], relNames: ['Relance de la Place', 'Relance du Pont'], desc: 'Un circuit nerveux à travers un bourg et ses rues : lignes droites, virages à angle droit et relances, rues secondaires pour varier les boucles.' },
  ];
  const THEMES = {
    littoral: { label: 'Littoral', sky: '#9fd3f2', fog: '#cfe8f6', ground: '#b7a77f', far: 1700 },
    montagne: { label: 'Montagne', sky: '#8cc6ee', fog: '#c7e1f2', ground: '#5d7a4a', far: 2100 },
    canyon: { label: 'Canyon', sky: '#a6cfe8', fog: '#ead2b8', ground: '#a0583a', far: 1700 },
    foret: { label: 'Forêt', sky: '#9cc9e4', fog: '#c2dbd3', ground: '#3f6b3a', far: 1100 },
    ville: { label: 'Vieux bourg', sky: '#c8d6e0', fog: '#dde6ec', ground: '#7fae4e', far: 1800 },
    campagne: { label: 'Campagne', sky: '#9fd0f0', fog: '#dbeaf0', ground: '#8fae55', far: 1800 },
  };
  const byId = id => ROUTES.find(r => r.id === id);

  /* ---------- Profil et tracé ---------- */
  const cache = {};
  // Parcours « réseau » (sprint) : lignes droites (500 m à 1,5 km) reliées par des virages circulaires larges (rayon 48 m)
  // de 45°, 60° ou 90°. Le cap reste toujours entre -90° et +90° autour de la direction générale : le tracé avance toujours
  // dans le même sens et ne peut jamais se croiser ; deux portions parallèles sont séparées d'au moins une ligne droite.
  function planNetwork(route, L) {
    const rand = rng(route.seed * 97 + 5), R = 48, plan = [], ANG = [Math.PI / 2, Math.PI / 3, Math.PI / 4];
    let s = 0, h = 0, last = 1;
    const straight = len => { plan.push({ kind: 'droite', s0: s, s1: s + len, h0: h, h1: h }); s += len; };
    straight(520);
    while (s < L - 900) {
      let a = ANG[Math.floor(rand() * ANG.length)] * (rand() < 0.7 ? -last : last); // le plus souvent dans l'autre sens (zigzag)
      if (Math.abs(h + a) > Math.PI / 2 + 1e-6) a = -a;
      if (Math.abs(h + a) > Math.PI / 2 + 1e-6) a = Math.sign(-h) * Math.PI / 4;
      const len = R * Math.abs(a); plan.push({ kind: 'virage', s0: s, s1: s + len, h0: h, h1: h + a, R }); s += len; h += a; last = Math.sign(a);
      const want = plan.length % 4 === 1 ? 1100 + rand() * 450 : 520 + rand() * 650; // une longue ligne droite sur deux environ
      straight(Math.min(want, Math.max(400, L - s)));
    }
    if (s < L) { const p = plan[plan.length - 1]; if (p.kind === 'droite') { p.s1 = L; s = L; } else straight(L - s); }
    return plan;
  }
  // Relief des parcours « réseau » : une fonction lisse des coordonnées du monde (et non de la distance le long de la route).
  // Les terrains de deux portions voisines du réseau se raccordent donc exactement, sans marche ni pli.
  const netH = (w, x, z) => { const p = w.netPh; return Math.sin(x / 930 + p[0]) * 0.6 + Math.sin(z / 1270 + p[1]) * 0.5 + Math.sin((x + z) / 2150 + p[2]) * 0.7 + Math.sin((x - z) / 610 + p[3]) * 0.18; };
  const netGround = (w, x, z) => w.netBase + w.netAmp * netH(w, x, z);
  function buildNetwork(route) {
    const n = Math.round(route.km * 1000 / STEP) + 1, L = (n - 1) * STEP, plan = planNetwork(route, L), rand = rng(route.seed * 11 + 3);
    const X = new Float64Array(n), Z = new Float64Array(n), Hd = new Float64Array(n), E = new Float64Array(n);
    const headAt = s => { const p = plan.find(q => s >= q.s0 && s <= q.s1) || plan[plan.length - 1]; return p.h0 + (p.h1 - p.h0) * Math.max(0, Math.min(1, (s - p.s0) / Math.max(1e-6, p.s1 - p.s0))); };
    // cap au mètre près, puis lissé (deux moyennes glissantes de 31 m) : chaque virage commence et finit par un raccord
    // progressif (comme une vraie route) au lieu de passer d'un coup de la ligne droite à l'arc de cercle
    const M1 = Math.ceil(L) + 1; let hh = Float64Array.from({ length: M1 }, (_, q) => headAt(q));
    for (let pass = 0; pass < 2; pass++) { const o = new Float64Array(M1); for (let q = 0; q < M1; q++) { let a2 = 0, c2 = 0; for (let r = Math.max(0, q - 15); r <= Math.min(M1 - 1, q + 15); r++) { a2 += hh[r]; c2++; } o[q] = a2 / c2; } hh = o; }
    const hAt = u => { const q = Math.max(0, Math.min(M1 - 1.001, u)), i0 = Math.floor(q); return hh[i0] + (hh[Math.min(M1 - 1, i0 + 1)] - hh[i0]) * (q - i0); };
    let x = 0, z = 0, k = 0;
    for (let s = 0; s <= L + 1e-6; s += 1) { if (Math.abs(s - k * STEP) < 1e-6 && k < n) { X[k] = x; Z[k] = z; Hd[k] = hAt(s); k++; } const h = hAt(s + 0.5); x += Math.cos(h); z += Math.sin(h); }
    const w = { route, n, X, Z, Hd, E, plan, layout: true, netPh: [rand() * 6.28, rand() * 6.28, rand() * 6.28, rand() * 6.28], netBase: route.theme === 'ville' ? 18 : 40, netAmp: 1 };
    // amplitude réglée pour obtenir le dénivelé positif annoncé
    let g0 = 0, prev = netH(w, X[0], Z[0]); for (let i = 1; i < n; i++) { const v = netH(w, X[i], Z[i]); g0 += Math.max(0, v - prev); prev = v; }
    w.netAmp = route.dplus / Math.max(1e-6, g0);
    for (let i = 0; i < n; i++) E[i] = netGround(w, X[i], Z[i]);
    let g2 = 0; for (let i = 1; i < n; i++) g2 += Math.max(0, E[i] - E[i - 1]);
    Object.assign(w, { seaLevel: 0, dplus: Math.round(g2), length: L, maxE: Math.max(...E), minE: Math.min(...E) }); w.seaLevel = w.minE - 4;
    return w;
  }
  function build(route) {
    if (cache[route.id]) return cache[route.id];
    if (route.layout === 'reseau') return (cache[route.id] = buildNetwork(route));
    const rand = rng(route.seed), n = Math.round(route.km * 1000 / STEP) + 1;
    const waves = [];
    const k = route.theme === 'montagne' ? 3 : 6;
    for (let i = 0; i < k; i++) waves.push({ l: 1200 + rand() * 6000, p: rand() * Math.PI * 2, a: 0.4 + rand() });
    const raw = new Float64Array(n);
    for (let i = 0; i < n; i++) {
      const s = i * STEP; let e = 0;
      for (const w of waves) e += w.a * Math.sin(s / w.l * Math.PI * 2 + w.p);
      if (route.theme === 'montagne') { const x = s / (route.km * 1000); e += 9 * Math.sin(Math.min(1, x / 0.62) * Math.PI / 2) * (x < 0.62 ? 1 : Math.max(0, 1 - (x - 0.62) / 0.38)); }
      raw[i] = e;
    }
    // lissage puis mise à l'échelle pour obtenir exactement le dénivelé positif annoncé
    const sm = new Float64Array(n);
    for (let i = 0; i < n; i++) { let a = 0, c = 0; for (let j = -6; j <= 6; j++) { const q = i + j; if (q >= 0 && q < n) { a += raw[q]; c++; } } sm[i] = a / c; }
    let gain = 0; for (let i = 1; i < n; i++) gain += Math.max(0, sm[i] - sm[i - 1]);
    const kk = route.dplus / gain, base = route.theme === 'littoral' ? 12 : route.theme === 'montagne' ? 600 : 150;
    const E = new Float64Array(n); let minE = Infinity;
    for (let i = 0; i < n; i++) { E[i] = (sm[i] - sm[0]) * kk + base; minE = Math.min(minE, E[i]); }
    if (minE < 3) for (let i = 0; i < n; i++) E[i] += 3 - minE;
    // tracé : cap qui ondule doucement
    const turns = [];
    for (let i = 0; i < 4; i++) turns.push({ l: 500 + rand() * 2500, p: rand() * 6.28, a: (route.theme === 'ville' ? 0.5 : 0.28) * (0.4 + rand()) });
    const X = new Float64Array(n), Z = new Float64Array(n), Hd = new Float64Array(n);
    let x = 0, z = 0;
    for (let i = 0; i < n; i++) {
      const s = i * STEP; let h = 0;
      for (const t of turns) h += t.a * Math.sin(s / t.l * Math.PI * 2 + t.p);
      Hd[i] = h; X[i] = x; Z[i] = z; x += Math.cos(h) * STEP; z += Math.sin(h) * STEP;
    }
    let g2 = 0; for (let i = 1; i < n; i++) g2 += Math.max(0, E[i] - E[i - 1]);
    const out = { route, n, X, Z, E, Hd, seaLevel: Math.max(0, minE < 3 ? 0 : 0), dplus: Math.round(g2), length: (n - 1) * STEP, maxE: Math.max(...E), minE: Math.min(...E) };
    out.seaLevel = out.minE - 4;
    return (cache[route.id] = out);
  }

  // Position interpolée à la distance s (mètres).
  function at(w, s) {
    const f = Math.max(0, Math.min(w.length - 0.001, s)) / STEP, i = Math.floor(f), t = f - i, j = Math.min(w.n - 1, i + 1);
    const L = (A) => A[i] + (A[j] - A[i]) * t;
    const grade = (w.E[j] - w.E[i]) / STEP;
    return { x: L(w.X), y: L(w.E), z: L(w.Z), heading: Math.atan2(w.Z[j] - w.Z[i], w.X[j] - w.X[i]), grade };
  }

  // Même position que at(), mais cap et pente continus (interpolés entre les points du tracé, tous les 10 m) : pour la
  // caméra et la pose du cycliste. at() donne le cap du petit segment de 10 m où l'on se trouve : il change d'un coup à
  // chaque point du tracé dans les virages (jusqu'à 3 à 6°), ce qui faisait pivoter l'image par à-coups.
  // Le cap interpolé est celui des bords de route dessinés (w.Hd) : cycliste et caméra suivent exactement la route.
  // La physique (vitesse, pente du home trainer) continue d'utiliser at(), inchangée.
  function atSmooth(w, s) {
    const f = Math.max(0, Math.min(w.length - 0.001, s)) / STEP, i = Math.min(w.n - 1, Math.floor(f)), t = f - i, j = Math.min(w.n - 1, i + 1);
    const L = A => A[i] + (A[j] - A[i]) * t;
    let dh = w.Hd[j] - w.Hd[i]; while (dh > Math.PI) dh -= 2 * Math.PI; while (dh < -Math.PI) dh += 2 * Math.PI;
    const gN = k => (w.E[Math.min(w.n - 1, k + 1)] - w.E[Math.max(0, k - 1)]) / (STEP * (Math.min(w.n - 1, k + 1) - Math.max(0, k - 1) || 1));
    // position sur une courbe d'Hermite (tangentes = cap des points du tracé) : pas de cassure aux points du tracé,
    // la caméra tourne sans à-coup même dans les virages serrés (écart à la ligne brisée : quelques centimètres)
    const ds = j > i ? STEP : 0, t2 = t * t, t3 = t2 * t, h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
    const x = ds ? h00 * w.X[i] + h10 * ds * Math.cos(w.Hd[i]) + h01 * w.X[j] + h11 * ds * Math.cos(w.Hd[j]) : w.X[i];
    const z = ds ? h00 * w.Z[i] + h10 * ds * Math.sin(w.Hd[i]) + h01 * w.Z[j] + h11 * ds * Math.sin(w.Hd[j]) : w.Z[i];
    return { x, y: L(w.E), z, heading: w.Hd[i] + dh * t, grade: gN(i) + (gN(j) - gN(i)) * t };
  }
  function placeOnSmooth(w, s, off = 0) {
    const p = atSmooth(w, s), nx = -Math.sin(p.heading), nz = Math.cos(p.heading);
    return { p, m: M.chain(M.t(p.x + nx * off, p.y + 0.05, p.z + nz * off), M.ry(-p.heading), M.rz(Math.atan(p.grade))) };
  }

  /* ---------- Physique (même modèle que le home trainer) ---------- */
  function speedFor(P, grade, mass = 84) {
    const g = 9.81, th = Math.atan(grade), crr = 0.004, k = 0.5 * 1.2 * 0.32;
    const f = v => v * (crr * mass * g * Math.cos(th) + mass * g * Math.sin(th) + k * v * v) - P * 0.97;
    let lo = 0, hi = 30; if (f(hi) < 0) return hi;
    for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; f(m) > 0 ? hi = m : lo = m; }
    return lo;
  }
  // Durée estimée pour un cycliste qui tient une puissance constante (vitesse limitée à 60 km/h en descente).
  function estimate(route, watts = 200, mass = 84) {
    const w = build(route); let t = 0;
    for (let i = 1; i < w.n; i++) { const v = Math.max(1.5, Math.min(16.7, speedFor(watts, (w.E[i] - w.E[i - 1]) / STEP, mass))); t += STEP / v; }
    return Math.round(t);
  }

  /* ---------- Décor ---------- */
  // 1 = désert ouvert, 0 = canyon fermé (Valley Loop) : alternance douce tous les 4 km, désert au départ.
  function desertOpen(s) { return Math.max(0, Math.min(1, (Math.sin(s * Math.PI * 2 / 4000 + 1.0) - 0.15) / 0.45)); }
  function noise(a, b) { return Math.sin(a * 0.013 + b * 0.07) * 0.6 + Math.sin(a * 0.031 - b * 0.11) * 0.3 + Math.sin(a * 0.007 + b * 0.019) * 0.8; }
  const OFFS = [-400, -260, -160, -90, -50, -28, -14, -7, -4.6, 4.6, 7, 14, 28, 50, 90, 160, 260, 400];
  // Vieux Port : terrain plus large (700 m de chaque côté) et bandes supplémentaires pour le trottoir et le mur du quai.
  const OFFS_V = [-700, -550, -400, -260, -160, -90, -50, -28.5, -28, -14, -9, -7, -4.6, 4.6, 7, 9, 14, 28, 50, 90, 160, 260, 400, 550, 700];
  // Tous les parcours : terrain jusqu'à 700 m de chaque côté (avant : 400 m), pour que le monde s'étende vers l'horizon.
  const OFFS_W = [-700, -550, ...OFFS, 550, 700];
  const offsOf = theme => theme === 'ville' ? OFFS_V : OFFS_W;
  // Côté intérieur d'un virage, une bande de terrain plus large que le rayon du virage se replierait sur elle-même
  // (surfaces qui se croisent et clignotent, objets posés de l'autre côté de la route). Sur tous les parcours, chaque côté
  // est limité à 85 % du plus petit rayon des 300 m voisins quand ce côté est l'intérieur du virage.
  // lim(w, i, sgn) = distance maximale autorisée.
  function lim(w, i, sgn) {
    if (w.layout) { // chaque bande de terrain s'arrête là où un autre point du réseau devient plus proche (diagramme de Voronoï)
      if (!w._vor) {
        const n = w.n, out = [new Float64Array(n), new Float64Array(n)];
        for (let k = 0; k < n; k++) for (const sd of [-1, 1]) {
          const ux = -Math.sin(w.Hd[k]) * sd, uz = Math.cos(w.Hd[k]) * sd; let best = 700;
          for (let j = 0; j < n; j++) { if (Math.abs(j - k) <= 1) continue; const dx = w.X[j] - w.X[k], dz = w.Z[j] - w.Z[k], dot = dx * ux + dz * uz; if (dot <= 0) continue; const o = (dx * dx + dz * dz) / (2 * dot); if (o < best) best = o; }
          out[sd > 0 ? 1 : 0][k] = Math.max(12, best - 1.5);
        }
        w._vor = out;
      }
      return w._vor[sgn > 0 ? 1 : 0][Math.max(0, Math.min(w.n - 1, i))];
    }
    if (w.route.theme === 'montagne' && !limBase.on) { // Col des Lumières : voir limVor
      if (!w._vorM) w._vorM = limVor(w);
      return w._vorM[sgn > 0 ? 1 : 0][Math.max(0, Math.min(w.n - 1, i))];
    }
    return limBase(w, i, sgn);
  }
  // Limite d'origine (85 % du plus petit rayon des 300 m voisins) : elle sert aussi à choisir les routes secondaires, qui
  // restent donc exactement les mêmes.
  function limBase(w, i, sgn) {
    if (!w._lim) {
      const n = w.n, raw = [new Float64Array(n).fill(1e9), new Float64Array(n).fill(1e9)];
      for (let j = 0; j < n - 1; j++) { const dh = w.Hd[j + 1] - w.Hd[j], r = STEP / Math.max(1e-6, Math.abs(dh)); raw[dh > 0 ? 1 : 0][j] = r * 0.85; }
      w._lim = raw.map(a => { const o = new Float64Array(n); for (let j = 0; j < n; j++) { let m = 1e9; for (let k = Math.max(0, j - 30); k <= Math.min(n - 1, j + 30); k++) m = Math.min(m, a[k]); o[j] = Math.max(40, m); } return o; });
    }
    return w._lim[sgn > 0 ? 1 : 0][Math.max(0, Math.min(w.n - 1, i))];
  }
  // Vieux Port : le bassin du port longe la route (côté gauche) sur environ un tiers du parcours, dont le départ.
  const portOpen0 = s => Math.sin(s * Math.PI * 2 / 6000 + 2.2) > 0.55 ? 1 : 0;
  let portOpen = portOpen0; // remplacé, le temps d'un calcul, sur les parcours « réseau » (pas de port)

  // Col des Lumières : la limite d'origine coupait le terrain bien trop tôt à l'intérieur des longs virages (souvent à
  // 100–200 m au lieu de 700 m) ; au-delà, on voyait le sol de secours, 190 m plus bas : des trous dans la carte.
  // Ici, chaque bande s'étend jusqu'à ce qu'un autre point de la route devienne plus proche (diagramme de Voronoï) :
  // aucune bande ne se replie ni ne chevauche une autre, et il n'y a plus de vide entre elles.
  function limVor(w) {
    const n = w.n, out = [new Float64Array(n), new Float64Array(n)], who = [new Int32Array(n).fill(-1), new Int32Array(n).fill(-1)];
    for (let k = 0; k < n; k++) for (const sd of [-1, 1]) {
      const ux = -Math.sin(w.Hd[k]) * sd, uz = Math.cos(w.Hd[k]) * sd; let best = 700, bj = -1;
      for (let j = Math.max(0, k - 400); j <= Math.min(n - 1, k + 400); j++) { if (Math.abs(j - k) <= 1) continue; const dx = w.X[j] - w.X[k], dz = w.Z[j] - w.Z[k], dot = dx * ux + dz * uz; if (dot <= 0) continue; const o = (dx * dx + dz * dz) / (2 * dot); if (o < best) { best = o; bj = j; } }
      out[sd > 0 ? 1 : 0][k] = Math.max(12, Math.min(700, best - 1.5)); who[sd > 0 ? 1 : 0][k] = best < 700 ? bj : -1;
    }
    w._vorJ = who; // point de la route voisin, de l'autre côté de la limite (pour raccorder les hauteurs)
    return out;
  }
  limBase.on = false;
  // Deux bandes voisines viennent de deux portions de route éloignées le long du tracé (souvent à des altitudes
  // différentes) : sur les 120 derniers mètres, chaque bande rejoint la moyenne des deux terrains, pour qu'elles se
  // raccordent à la même hauteur (pas de marche ni de fente).
  const SEAM = 120;
  function seamBlend(theme, w, i, off, h) {
    if (!w._vorM || !w._vorJ || w._noSeam) return h;
    const sd = off > 0 ? 1 : 0, cut = w._vorM[sd][i], j = w._vorJ[sd][i], a = Math.abs(off);
    if (j < 0 || a <= cut - SEAM) return h;
    const p = crossPoint(w, i, off, 0), oj = (p[0] - w.X[j]) * -Math.sin(w.Hd[j]) + (p[2] - w.Z[j]) * Math.cos(w.Hd[j]);
    const hj = sideRaw(theme, w, j, oj)[0], t = Math.min(1, (a - (cut - SEAM)) / SEAM) * 0.5;
    return h * (1 - t) + hj * t;
  }
  function side(theme, w, i, off) {
    if (theme === 'montagne' && !w.layout && w._vorM && Math.abs(off) > 9) { const r = sideBase(theme, w, i, off); return w._adj && w._adj.has(i * 16384 + Math.round(off * 10) + 8192) ? r : [seamBlend(theme, w, i, off, r[0]), r[1]]; }
    return sideBase(theme, w, i, off);
  }
  function sideBase(theme, w, i, off) {
    if (w.layout) { // parcours réseau : même terrain que le thème, mais hauteur donnée par le relief du monde (raccords parfaits)
      const keep = portOpen; portOpen = () => 0; let r;
      try { r = sideRaw(theme, w, i, off); } finally { portOpen = keep; }
      if (w._adj) { const h = w._adj.get(i * 16384 + Math.round(off * 10) + 8192); if (h !== undefined) return [h, r[1]]; }
      const a = Math.abs(off), q = crossPoint(w, i, off, 0), flat = netGround(w, q[0], q[2]) + 0.08, t = Math.max(0, Math.min(1, (a - 9) / 12));
      return [r[0] * (1 - t) + flat * t, r[1]];
    }
    if (w._adj) { const h = w._adj.get(i * 16384 + Math.round(off * 10) + 8192); if (h !== undefined) { const r = sideRaw(theme, w, i, off); return [h, r[1]]; } }
    return sideRaw(theme, w, i, off);
  }
  function sideRaw(theme, w, i, off) {
    const e = w.E[i], s = i * STEP, a = Math.abs(off), out = Math.max(0, a - 6);
    const hill = noise(s, off) * Math.min(1, out / 40);
    switch (theme) {
      case 'littoral': {
        if (off < 0) {
          const sea = w.seaLevel;
          if (a <= 7) return [e - 0.25, '#d9c79a'];
          if (a <= 28) { const t = (a - 7) / 21; return [e + (sea + 1.2 - e) * t, '#e5d3a3']; }
          return [sea + 0.4 - (a - 28) * 0.02, '#e1cf9e'];
        }
        return [e + hill * 6 + out * 0.08, out > 30 ? '#6f9a52' : '#86ad5c'];
      }
      case 'montagne': {
        const h = e + hill * 14 + (off > 0 ? out * 0.55 : -out * 0.22);
        const c = h > 1400 ? '#eef3f7' : h > 1150 ? '#8d8f8a' : out > 60 ? '#55794a' : '#6c9450';
        return [h, c];
      }
      case 'canyon': {
        // par endroits, le canyon s'ouvre sur un grand désert de sable (où se dressent les pyramides)
        const k = desertOpen(s), wall = Math.min(55, Math.max(0, a - 22) * 1.4) * (1 - 0.9 * k);
        const h = e + wall + hill * (3 + k * 5) + Math.max(0, a - 400) * 0.06; // plateau qui remonte doucement vers l'horizon
        const c = k > 0.6 ? (a > 28 ? (Math.floor((s + off * 3) / 70) % 2 ? '#dba86a' : '#d39d5e') : '#d9a874') : a > 28 ? (Math.floor(h / 6) % 2 ? '#b5623c' : '#c47448') : '#cf9a6a';
        return [h, c];
      }
      case 'foret': {
        if (off < -16) return [e - 2.2, a > 22 ? '#2f6f8f' : '#3a7f9c'];
        return [e + hill * 5 + out * 0.05, '#3f6b3a'];
      }
      case 'ville': { // vieux bourg : bande d'herbe, trottoir, pelouses et jardins, champs et collines au loin ; quais du port par endroits
        const port = off < 0 && portOpen(s);
        if (a <= 7) return [e + 0.06, '#7db34c'];
        if (a <= 9) return [e + 0.1, off < 0 ? '#c4c3ba' : '#bab29d'];
        if (port) {
          if (a <= 28) return [e + 0.12, '#aaa69b'];                 // pavés du quai
          if (a <= 260) return [e - 2.4, a <= 28.6 ? '#7c786d' : '#3f7fa0']; // mur du quai puis eau du bassin
          if (a <= 400) return [e - 1.2, '#cdbf94'];                  // grève de l'autre rive
        }
        const patch = (((Math.floor(s / 120) * 5 + Math.floor((off + 700) / 45)) % 5) + 5) % 5;
        const c = a <= 14 ? '#82b551' : a <= 160 ? ['#82b551', '#78ab49', '#8cbb58', '#7eb04c', '#86b654'][patch] : ['#9cbf5e', '#8db556', '#b7bd6c', '#a2c262', '#8fb653'][patch];
        return [e + 0.08 + hill * 6 * Math.min(1, Math.max(0, a - 40) / 160) + Math.max(0, a - 400) * 0.03, c];
      }
      default: { // campagne
        const patch = (((Math.floor(s / 90) * 7 + Math.floor((off + 400) / 32)) % 4) + 4) % 4;
        const c = a <= 7 ? '#8fae55' : ['#d9b84a', '#8fae55', '#b99a5b', '#a7c160'][patch];
        return [e + hill * 4 + Math.max(0, a - 300) * 0.04 * (1 + noise(s * 0.5, off)), c]; // la plaine ondule et remonte un peu au loin
      }
    }
  }

  // Hauteur du sol telle qu'elle est dessinée (interpolée entre les points du maillage), pour poser les objets.
  function groundY(theme, w, i, off) {
    if (Math.abs(off) <= 4.6) return w.E[i];
    const OF = offsOf(theme);
    for (let k = 0; k < OF.length - 1; k++) if (off >= OF[k] && off <= OF[k + 1]) {
      const a = side(theme, w, i, OF[k])[0], b = side(theme, w, i, OF[k + 1])[0], t = (off - OF[k]) / (OF[k + 1] - OF[k]);
      return a + (b - a) * t;
    }
    return side(theme, w, i, off)[0];
  }

  function crossPoint(w, i, off, y) {
    const h = w.Hd[i], nx = -Math.sin(h), nz = Math.cos(h);
    return [w.X[i] + nx * off, y, w.Z[i] + nz * off];
  }

  // Petits objets du décor (placés dans le repère du monde).
  const P = {
    blobTree(g, x, y, z, s, c = '#4f8f3a') { g.cyl(M.t(x, y, z), 0.25 * s, 0.18 * s, 2.2 * s, 5, '#7b5a3a', false); g.sphere(M.chain(M.t(x, y + 3.2 * s, z), M.s(1, 0.9, 1)), 1.9 * s, c, 3, 6, (i, j) => (i + j) % 3 ? c : shade(c, 1.12)); },
    pine(g, x, y, z, s, c = '#2f5d3a') { g.cyl(M.t(x, y, z), 0.22 * s, 0.15 * s, 1.4 * s, 5, '#6b4a2f', false); for (let k = 0; k < 3; k++) g.cyl(M.t(x, y + (1.1 + k * 1.5) * s, z), (2.2 - k * 0.55) * s, 0, 2.6 * s, 6, k % 2 ? c : shade(c, 1.1), false); },
    rock(g, x, y, z, s, c = '#8b8f94') { g.sphere(M.chain(M.t(x, y + 0.15 * s, z), M.s(1.3, 0.6, 1)), s, c, 3, 6, (i, j) => (i + j) % 2 ? c : shade(c, 1.08)); },
    parasol(g, x, y, z, c) { g.tube([x, y, z], [x, y + 2.3, z], 0.04, '#e5e7eb', 4); g.cyl(M.t(x, y + 1.9, z), 1.3, 0, 0.6, 8, c, false); },
    cabin(g, x, y, z, rot, c) { const m = M.chain(M.t(x, y + 1.2, z), M.ry(rot)); g.box(m, 2.2, 2.4, 2.2, '#f3f4f6', '#e5e7eb'); g.box(M.chain(m, M.t(0, -0.2, 1.11)), 0.9, 1.7, 0.04, c); },
    lamp(g, x, y, z) { g.tube([x, y, z], [x, y + 4.5, z], 0.07, '#374151', 5); g.box(M.t(x, y + 4.55, z), 0.5, 0.15, 0.3, '#fde68a'); },
    hay(g, x, y, z, rot) { const m = M.chain(M.t(x, y + 0.75, z), M.ry(rot), M.rx(Math.PI / 2), M.t(0, -0.7, 0)); g.cyl(m, 0.75, 0.75, 1.4, 8, '#d9b45a'); },
    farm(g, x, y, z, rot) {
      const m = M.chain(M.t(x, y + 2, z), M.ry(rot));
      g.box(m, 9, 4, 6, '#f1ebe0'); g.box(M.chain(m, M.t(0, 0, 3.01)), 1.4, 2.4, 0.05, '#7c3a2a');
      const roof = M.chain(m, M.t(0, 2, 0));
      g.quad(M.apply(roof, [-4.8, 0, -3.3]), M.apply(roof, [4.8, 0, -3.3]), M.apply(roof, [4.8, 2.4, 0]), M.apply(roof, [-4.8, 2.4, 0]), '#b4452f');
      g.quad(M.apply(roof, [-4.8, 0, 3.3]), M.apply(roof, [-4.8, 2.4, 0]), M.apply(roof, [4.8, 2.4, 0]), M.apply(roof, [4.8, 0, 3.3]), '#c24f37');
    },
    building(g, x, y, z, rot, w, h, d, c, rand) {
      const m = M.chain(M.t(x, y + h / 2, z), M.ry(rot));
      g.box(m, w, h, d, c, shade(c, 0.9));
      const rows = Math.floor((h - 3) / 3.2), cols = Math.max(1, Math.floor(w / 2.6));
      for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) {
        const px = -w / 2 + (k + 0.5) * (w / cols), py = -h / 2 + 3.5 + r * 3.2;
        g.box(M.chain(m, M.t(px, py, d / 2 + 0.02)), 1.1, 1.5, 0.04, rand() < 0.15 ? '#fde68a' : '#334155');
      }
      g.box(M.chain(m, M.t(0, -h / 2 + 1.3, d / 2 + 0.03)), Math.min(w - 1, 3), 2.4, 0.05, shade(c, 0.6));
    },
    // Montagne : le flanc s'arrête à la limite des neiges et la neige le prolonge (même silhouette, aucune surface
    // superposée : avant, les deux cônes se recouvraient exactement et clignotaient l'un à travers l'autre).
    // Montagne : silhouette variée d'un sommet à l'autre (nombre de faces, orientation, largeur, épaulement ou second sommet),
    // tirée de sa position (toujours la même). Le flanc s'arrête à la limite des neiges et la neige le prolonge (aucune surface
    // superposée), et le pied est enfoncé : sur une pente, on ne voit jamais le dessous de la montagne.
    mountain(g, x, y, z, r, h, snow) {
      const hs = k => { const v = Math.sin(x * 12.9898 + z * 78.233 + k * 37.719) * 43758.5453; return v - Math.floor(v); };
      const seg = 5 + Math.floor(hs(1) * 4), sx = 0.8 + hs(2) * 0.45, sk = 0.75 + hs(4) * 0.5;
      const peak = (px, pz, rr, hh, rot) => {
        const m = M.chain(M.t(px, y, pz), M.ry(rot), M.s(sx, 1, 2 - sx));
        g.cyl(M.chain(m, M.t(0, -320, 0)), rr * 1.04, rr, 320, seg, '#6d7a84', false);
        if (!snow) { g.cyl(m, rr, 0, hh, seg, '#6d7a84', false); return; }
        const line = 0.6 + hs(3) * 0.12;
        g.cyl(m, rr, rr * (1 - line) * sk, hh * line, seg, '#6d7a84', false);
        g.cyl(M.chain(m, M.t(0, hh * line, 0)), rr * (1 - line) * sk, 0, hh * (1 - line), seg, '#f1f5f9', false);
      };
      peak(x, z, r, h, hs(5) * 6.28);
      if (hs(6) > 0.45) { const a = hs(7) * 6.28, d = r * (0.35 + hs(8) * 0.25); peak(x + Math.cos(a) * d, z + Math.sin(a) * d, r * (0.5 + hs(9) * 0.2), h * (0.6 + hs(10) * 0.2), hs(11) * 6.28); }
    },
    mesa(g, x, y, z, r, h) { g.cyl(M.t(x, y, z), r, r * 0.8, h, 7, '#b4603b', true, '#c9784b'); },
    // Maison de village (façade vers la route) : murs, fenêtres encadrées, porte, toit à deux pans, cheminée.
    house(g, x, y, z, rot, w, d, floors, wall, roof, rand) {
      const h = floors * 2.8, m = M.chain(M.t(x, y + h / 2, z), M.ry(rot)), at = (px, py, pz) => M.chain(m, M.t(px, py, pz));
      g.box(m, w, h, d, wall, shade(wall, 0.92));
      g.box(at(0, -h / 2 + 0.2, 0), w + 0.15, 0.4, d + 0.15, shade(wall, 0.7)); // soubassement
      const cols = Math.max(2, Math.floor(w / 2.3)), doorK = Math.floor(rand() * cols);
      for (let f = 0; f < floors; f++) for (let k = 0; k < cols; k++) {
        const px = -w / 2 + (k + 0.5) * (w / cols), py = -h / 2 + 1.5 + f * 2.8;
        if (f === 0 && k === doorK) { g.box(at(px, -h / 2 + 1.05, d / 2 + 0.03), 1.0, 2.1, 0.06, '#f8fafc'); g.box(at(px, -h / 2 + 1.0, d / 2 + 0.05), 0.8, 1.9, 0.06, rand() < 0.5 ? '#334155' : '#7c2d12'); continue; }
        g.box(at(px, py, d / 2 + 0.03), 1.05, 1.35, 0.06, '#f8fafc'); g.box(at(px, py, d / 2 + 0.05), 0.82, 1.1, 0.06, rand() < 0.12 ? '#fde68a' : '#3b4a5c');
      }
      for (const sx of [-1, 1]) for (let f = 0; f < floors; f++) { g.box(at(sx * (w / 2 + 0.03), -h / 2 + 1.5 + f * 2.8, 0), 0.06, 1.35, 1.05, '#f8fafc'); g.box(at(sx * (w / 2 + 0.05), -h / 2 + 1.5 + f * 2.8, 0), 0.06, 1.1, 0.82, '#3b4a5c'); }
      const rh = d * 0.42, o = 0.35, R = (px, py, pz) => M.apply(m, [px, h / 2 + py, pz]);
      g.quad(R(-w / 2 - o, -0.15, -d / 2 - o), R(w / 2 + o, -0.15, -d / 2 - o), R(w / 2 + o, rh, 0), R(-w / 2 - o, rh, 0), roof);
      g.quad(R(-w / 2 - o, -0.15, d / 2 + o), R(-w / 2 - o, rh, 0), R(w / 2 + o, rh, 0), R(w / 2 + o, -0.15, d / 2 + o), shade(roof, 1.12));
      for (const sx of [-1, 1]) g.tri(R(sx * w / 2, 0, -d / 2), R(sx * w / 2, rh, 0), R(sx * w / 2, 0, d / 2), wall);
      g.box(at(w * 0.28, h / 2 + rh * 0.75, -d * 0.18), 0.6, 1.5, 0.6, '#8a3b2b');
    },
    /* --- Vieux Port : maisons variées, rangées de brique, grands arbres ronds, poteaux électriques, bateaux --- */
    // Maison individuelle : largeur, profondeur, étages, toit (deux pans, croupe ou pignon sur rue), pente, couleurs,
    // encadrements, volets, lucarnes, porche et cheminée varient d'une maison à l'autre.
    villa(g, x, y, z, rot, o, rand) {
      const { w, d, fl, wall, roof, kind } = o, h = fl * 2.7 + 0.3;
      const m = M.chain(M.t(x, y + h / 2, z), M.ry(rot)), at = (px, py, pz) => M.chain(m, M.t(px, py, pz)), R = (px, py, pz) => M.apply(m, [px, h / 2 + py, pz]);
      g.box(m, w, h, d, wall, shade(wall, 0.9));
      g.box(at(0, -h / 2 + 0.22, 0), w + 0.14, 0.44, d + 0.14, shade(wall, 0.62)); // soubassement
      const glass = '#33414f', frame = o.frame, W1 = o.wide ? 1.4 : 0.95, H1 = 1.25;
      const win = (px, py, face) => {
        if (Math.abs(face) === 1) { const z0 = face * d / 2;
          g.box(at(px, py, z0 + face * 0.03), W1 + 0.16, H1 + 0.16, 0.06, frame); g.box(at(px, py, z0 + face * 0.06), W1, H1, 0.06, rand() < 0.08 ? '#fde68a' : glass);
          if (o.shutter) for (const sx of [-1, 1]) g.box(at(px + sx * (W1 / 2 + 0.3), py, z0 + face * 0.05), 0.42, H1 + 0.1, 0.05, o.shutter); }
        else { const sx = Math.sign(face), x0 = sx * w / 2; g.box(at(x0 + sx * 0.03, py, px), 0.06, H1 + 0.16, 0.95 + 0.16, frame); g.box(at(x0 + sx * 0.06, py, px), 0.06, H1, 0.95, glass); }
      };
      const cols = Math.max(2, Math.round(w / (o.wide ? 3 : 2.4))), door = Math.floor(rand() * cols);
      for (let f = 0; f < fl; f++) for (let k = 0; k < cols; k++) {
        const px = -w / 2 + (k + 0.5) * (w / cols), py = -h / 2 + 1.55 + f * 2.7;
        if (f === 0 && k === door) {
          g.box(at(px, -h / 2 + 1.15, d / 2 + 0.04), 1.15, 2.2, 0.08, frame); g.box(at(px, -h / 2 + 1.1, d / 2 + 0.08), 0.9, 2.05, 0.06, o.door);
          g.box(at(px, -h / 2 + 0.1, d / 2 + 0.5), 1.5, 0.2, 0.9, '#a3a39b'); // marche
          if (o.porch) { g.box(at(px, -h / 2 + 2.55, d / 2 + 0.75), 2.2, 0.14, 1.5, shade(roof, 1.1)); for (const sx of [-1, 1]) g.box(at(px + sx * 1.0, -h / 2 + 1.25, d / 2 + 1.4), 0.12, 2.5, 0.12, frame); }
          continue;
        }
        win(px, py, 1); if (rand() < 0.75) win(px, py, -1);
      }
      const sc = Math.max(1, Math.round(d / 3.2));
      for (let f = 0; f < fl; f++) for (let k = 0; k < sc; k++) { if (rand() < 0.4) continue; const pz = -d / 2 + (k + 0.5) * (d / sc), py = -h / 2 + 1.55 + f * 2.7; win(pz, py, 2); if (rand() < 0.7) win(pz, py, -2); }
      const ov = 0.35, rc = roof, rc2 = shade(roof, 1.13);
      let rh;
      if (kind === 'hip') { // toit à quatre pans
        rh = d * (o.pitch || 0.36); const L = Math.max(0.2, w / 2 - d / 2);
        g.quad(R(-w / 2 - ov, -0.12, d / 2 + ov), R(w / 2 + ov, -0.12, d / 2 + ov), R(L, rh, 0), R(-L, rh, 0), rc2);
        g.quad(R(-w / 2 - ov, -0.12, -d / 2 - ov), R(w / 2 + ov, -0.12, -d / 2 - ov), R(L, rh, 0), R(-L, rh, 0), rc);
        g.tri(R(-w / 2 - ov, -0.12, -d / 2 - ov), R(-w / 2 - ov, -0.12, d / 2 + ov), R(-L, rh, 0), rc);
        g.tri(R(w / 2 + ov, -0.12, -d / 2 - ov), R(w / 2 + ov, -0.12, d / 2 + ov), R(L, rh, 0), rc2);
      } else if (kind === 'front') { // pignon sur rue
        rh = w * (o.pitch || 0.42);
        g.quad(R(-w / 2 - ov, -0.12, -d / 2 - ov), R(-w / 2 - ov, -0.12, d / 2 + ov), R(0, rh, d / 2 + ov), R(0, rh, -d / 2 - ov), rc);
        g.quad(R(w / 2 + ov, -0.12, -d / 2 - ov), R(w / 2 + ov, -0.12, d / 2 + ov), R(0, rh, d / 2 + ov), R(0, rh, -d / 2 - ov), rc2);
        for (const sz of [-1, 1]) g.tri(R(-w / 2, 0, sz * d / 2), R(w / 2, 0, sz * d / 2), R(0, rh, sz * d / 2), wall);
        if (rh > 2.2) { g.box(at(0, h / 2 + rh * 0.33, d / 2 + 0.04), 0.9, 1.0, 0.06, frame); g.box(at(0, h / 2 + rh * 0.33, d / 2 + 0.07), 0.7, 0.8, 0.06, glass); }
      } else { // deux pans, faîtage parallèle à la rue
        rh = d * (o.pitch || 0.42);
        g.quad(R(-w / 2 - ov, -0.12, -d / 2 - ov), R(w / 2 + ov, -0.12, -d / 2 - ov), R(w / 2 + ov, rh, 0), R(-w / 2 - ov, rh, 0), rc);
        g.quad(R(-w / 2 - ov, -0.12, d / 2 + ov), R(-w / 2 - ov, rh, 0), R(w / 2 + ov, rh, 0), R(w / 2 + ov, -0.12, d / 2 + ov), rc2);
        for (const sx of [-1, 1]) g.tri(R(sx * w / 2, 0, -d / 2), R(sx * w / 2, rh, 0), R(sx * w / 2, 0, d / 2), wall);
        if (o.dormers) for (let k = 0; k < o.dormers; k++) { // lucarnes sur le pan avant
          const px = -w / 2 + (k + 0.5) * (w / o.dormers), pz = d * 0.2, py = h / 2 + rh * (1 - (pz + ov) / (d / 2 + ov)) * 0.95;
          g.box(at(px, py + 0.35, pz), 1.3, 1.3, 1.6, wall); g.box(at(px, py + 0.35, pz + 0.82), 0.75, 0.8, 0.06, glass);
          g.cyl(M.chain(at(px, py + 1.0, pz), M.ry(Math.PI / 4)), 1.15, 0, 0.7, 4, roof, false);
        }
      }
      if (o.chimney) { const cx = (rand() < 0.5 ? -1 : 1) * w * 0.28; g.box(at(cx, h / 2 + rh * 0.75, kind === 'front' ? -d * 0.2 : -d * 0.12), 0.6, 1.8, 0.6, o.chimney); }
    },
    // Rangée de maisons de ville en brique (2 à 3 étages), toit d'ardoise, une porte et une cheminée par logement.
    brickRow(g, x, y, z, rot, len, d, fl, brick, roof, rand) {
      const h = fl * 3 + 0.4, m = M.chain(M.t(x, y + h / 2, z), M.ry(rot)), at = (px, py, pz) => M.chain(m, M.t(px, py, pz)), R = (px, py, pz) => M.apply(m, [px, h / 2 + py, pz]);
      g.box(m, len, h, d, brick, shade(brick, 0.9));
      for (let f = 1; f < fl; f++) g.box(at(0, -h / 2 + f * 3, d / 2 + 0.02), len, 0.18, 0.05, shade(brick, 1.3)); // bandeaux entre les étages
      const units = Math.max(2, Math.round(len / 6.5)), uw = len / units, doorC = ['#1f2937', '#14532d', '#1e3a8a', '#7f1d1d', '#f8fafc'];
      for (let u = 0; u < units; u++) {
        const ux = -len / 2 + (u + 0.5) * uw;
        if (u > 0) g.tube(M.apply(m, [ux - uw / 2, -h / 2, d / 2 + 0.08]), M.apply(m, [ux - uw / 2, h / 2 - 0.1, d / 2 + 0.08]), 0.05, '#2b2f36', 4); // descente d'eau
        for (let f = 0; f < fl; f++) for (const k of [-1, 0, 1]) {
          const px = ux + k * uw * 0.3, py = -h / 2 + 1.7 + f * 3;
          if (f === 0 && k === -1) { g.box(at(px, -h / 2 + 1.2, d / 2 + 0.04), 1.2, 2.4, 0.08, '#f1efe8'); g.box(at(px, -h / 2 + 1.15, d / 2 + 0.08), 0.95, 2.2, 0.06, doorC[Math.floor(rand() * doorC.length)]); continue; }
          g.box(at(px, py, d / 2 + 0.03), 1.15, 1.75, 0.06, '#f1efe8'); g.box(at(px, py, d / 2 + 0.06), 0.9, 1.5, 0.06, rand() < 0.07 ? '#fde68a' : '#2f3b48');
          g.box(at(px, py, -d / 2 - 0.03), 1.0, 1.5, 0.06, '#2f3b48');
        }
        const ch = R(ux + uw * 0.35, d * 0.42 * 0.8, 0); g.box(M.chain(M.t(ch[0], ch[1] + 0.6, ch[2]), M.ry(rot)), 0.7, 1.6, 1.1, shade(brick, 0.85));
      }
      const rh = d * 0.42, ov = 0.3;
      g.quad(R(-len / 2 - ov, -0.1, -d / 2 - ov), R(len / 2 + ov, -0.1, -d / 2 - ov), R(len / 2 + ov, rh, 0), R(-len / 2 - ov, rh, 0), roof);
      g.quad(R(-len / 2 - ov, -0.1, d / 2 + ov), R(-len / 2 - ov, rh, 0), R(len / 2 + ov, rh, 0), R(len / 2 + ov, -0.1, d / 2 + ov), shade(roof, 1.12));
      for (const sx of [-1, 1]) g.tri(R(sx * len / 2, 0, -d / 2), R(sx * len / 2, rh, 0), R(sx * len / 2, 0, d / 2), brick);
    },
    // Grand arbre feuillu au houppier rond, à facettes (comme sur la photo de référence).
    roundTree(g, x, y, z, s, c) {
      g.cyl(M.t(x, y, z), 0.3 * s, 0.2 * s, 2.8 * s, 6, '#6b4f36', false);
      g.sphere(M.chain(M.t(x, y + 4.6 * s, z), M.s(1, 1.18, 1)), 2.5 * s, c, 4, 7, (i, j) => (i * 3 + j) % 4 === 0 ? shade(c, 1.1) : (i + j) % 3 === 0 ? shade(c, 0.92) : c);
    },
    // Poteau électrique en bois avec traverse ; renvoie les points d'accroche des câbles.
    pole2(g, x, y, z, rot) {
      g.tube([x, y, z], [x, y + 8.6, z], 0.13, '#5b4632', 5);
      const m = M.chain(M.t(x, y + 8.1, z), M.ry(rot)); g.box(m, 0.14, 0.16, 2.1, '#5b4632');
      const pts = [M.apply(m, [0, 0.15, -0.9]), M.apply(m, [0, 0.15, 0.9]), [x, y + 8.6, z]];
      for (const q of pts.slice(0, 2)) g.box(M.t(q[0], q[1] - 0.02, q[2]), 0.08, 0.16, 0.08, '#d6d3d1');
      return pts;
    },
    wire(g, a, b) { const mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2 - 0.55, (a[2] + b[2]) / 2]; g.tube(a, mid, 0.022, '#2b2b2b', 3, 0.022, false); g.tube(mid, b, 0.022, '#2b2b2b', 3, 0.022, false); },
    mailbox(g, x, y, z, rot) { g.box(M.t(x, y + 0.55, z), 0.08, 1.1, 0.08, '#2b2b2b'); g.box(M.chain(M.t(x, y + 1.2, z), M.ry(rot)), 0.32, 0.36, 0.5, '#1f2328'); },
    poplar(g, x, y, z, s, c = '#4e8f3a') { g.cyl(M.t(x, y, z), 0.22 * s, 0.16 * s, 2.4 * s, 5, '#6b5038', false); g.sphere(M.chain(M.t(x, y + 6.2 * s, z), M.s(0.62, 2.1, 0.62)), 2.3 * s, c, 4, 7, (i, j) => (i + j) % 3 ? c : shade(c, 1.12)); },
    // panneau de virage dangereux : chevrons rouges sur fond blanc, tournés vers le cycliste qui arrive
    chevron(g, x, y, z, rot, dir) { const m = M.chain(M.t(x, y, z), M.ry(rot)); g.tube([x, y, z], [x, y + 1.7, z], 0.05, '#9ca3af', 4);
      g.box(M.chain(m, M.t(0, 2.05, 0)), 0.05, 0.7, 1.6, '#f8fafc'); for (let k = -1; k <= 1; k++) { const c = 0.42 * k, P2 = (a, b) => M.apply(m, [-0.04, 2.05 + b, c + a * dir]); g.tri(P2(0.16, 0), P2(-0.12, 0.26), P2(-0.12, 0.12), '#dc2626'); g.tri(P2(0.16, 0), P2(-0.12, -0.12), P2(-0.12, -0.26), '#dc2626'); g.tri(P2(0.16, 0), P2(-0.12, 0.12), P2(-0.12, -0.12), '#dc2626'); } },
    // barrière d'arrivée (barrière de course métallique)
    barrier(g, a, b, y) { const L = Math.hypot(b[0] - a[0], b[2] - a[2]); if (L < 0.5) return; const r = -Math.atan2(b[2] - a[2], b[0] - a[0]);
      g.box(M.chain(M.t((a[0] + b[0]) / 2, y + 0.95, (a[2] + b[2]) / 2), M.ry(r)), L, 0.06, 0.05, '#d1d5db'); g.box(M.chain(M.t((a[0] + b[0]) / 2, y + 0.55, (a[2] + b[2]) / 2), M.ry(r)), L, 0.55, 0.02, '#e5e7eb');
      for (const p of [a, b]) g.box(M.t(p[0], y + 0.5, p[2]), 0.05, 1, 0.05, '#9ca3af'); },
    hedge(g, a, b, y, c = '#4f8a36') { const dx = b[0] - a[0], dz = b[2] - a[2], L = Math.hypot(dx, dz); if (L < 0.5) return; g.box(M.chain(M.t((a[0] + b[0]) / 2, y + 0.5, (a[2] + b[2]) / 2), M.ry(-Math.atan2(dz, dx))), L, 1.0, 0.8, c, shade(c, 1.12)); },
    picket(g, a, b, y) { const L = Math.hypot(b[0] - a[0], b[2] - a[2]), n = Math.max(2, Math.round(L / 0.6));
      for (let k = 0; k <= n; k++) { const t = k / n; g.box(M.t(a[0] + (b[0] - a[0]) * t, y + 0.45, a[2] + (b[2] - a[2]) * t), 0.08, 0.9, 0.08, '#f4f4f0'); }
      g.tube([a[0], y + 0.6, a[2]], [b[0], y + 0.6, b[2]], 0.035, '#f4f4f0', 4, 0.035, false); },
    boat(g, x, y, z, rot, c, mast) {
      const m = M.chain(M.t(x, y, z), M.ry(rot)), at = (a, b, cc) => M.chain(m, M.t(a, b, cc)), P2 = (a, b, cc) => M.apply(m, [a, b, cc]);
      g.box(at(0, 0.35, 0), 5, 0.9, 2.0, c, '#e7e2d6');
      for (const yy of [-0.1, 0.8]) g.tri(P2(2.5, yy, -1), P2(2.5, yy, 1), P2(3.7, yy, 0), yy > 0 ? '#e7e2d6' : c);
      for (const sz of [-1, 1]) g.quad(P2(2.5, -0.1, sz), P2(3.7, -0.1, 0), P2(3.7, 0.8, 0), P2(2.5, 0.8, sz), c);
      g.box(at(-0.7, 1.2, 0), 1.8, 0.8, 1.4, '#f8fafc'); g.box(at(-0.7, 1.25, 0.71), 1.2, 0.35, 0.03, '#33414f');
      if (mast) { g.tube(P2(0.8, 0.8, 0), P2(0.8, 7.5, 0), 0.06, '#e5e7eb', 4); g.tri(P2(0.9, 1.4, 0), P2(0.9, 7.2, 0), P2(3.0, 1.4, 0), '#f8fafc'); }
    },
    // Église du bourg : nef, clocher et flèche d'ardoise.
    church(g, x, y, z, rot) {
      const m = M.chain(M.t(x, y, z), M.ry(rot)), at = (a, b, cc) => M.chain(m, M.t(a, b, cc)), P2 = (a, b, cc) => M.apply(m, [a, b, cc]);
      g.box(at(0, 4.5, 0), 9, 9, 20, '#e6dfcf', '#d8d0bd');
      g.quad(P2(-4.9, 9, -10.3), P2(-4.9, 9, 10.3), P2(0, 13, 10.3), P2(0, 13, -10.3), '#3b3f46'); g.quad(P2(4.9, 9, -10.3), P2(4.9, 9, 10.3), P2(0, 13, 10.3), P2(0, 13, -10.3), '#454a52');
      for (const sz of [-1, 1]) g.tri(P2(-4.5, 9, sz * 10), P2(4.5, 9, sz * 10), P2(0, 13, sz * 10), '#e6dfcf');
      for (const sz of [-1, 1]) for (let k = -2; k <= 2; k++) g.box(at(sz * 4.53, 5, k * 3.6), 0.06, 3.2, 1.1, '#5b6b7d');
      g.box(at(0, 9, 11.5), 4.4, 18, 4.4, '#ddd5c3'); g.box(at(0, 14.5, 13.72), 1.2, 1.6, 0.06, '#33414f');
      g.cyl(M.chain(at(0, 18, 11.5), M.ry(Math.PI / 4)), 3.2, 0, 10, 4, '#3b3f46', false);
      g.tube(P2(0, 28, 11.5), P2(0, 30, 11.5), 0.08, '#c9a227', 4); g.box(at(0, 29.3, 11.5), 0.9, 0.08, 0.08, '#c9a227');
    },
    chalet(g, x, y, z, rot, rand) { P.house(g, x, y, z, rot, 8, 7, 2, '#a0703f', '#4b3a2f', rand); },
    pole(g, x, y, z) { g.tube([x, y, z], [x, y + 7.5, z], 0.11, '#6b5038', 5); g.box(M.t(x, y + 7.1, z), 0.12, 0.12, 1.5, '#6b5038'); },
    // Touffe d'herbe : quelques brins (triangles) orientés au hasard.
    grass(g, x, y, z, s, c, rand) {
      g.sw = { y0: y, h: 0.65 * s };
      for (let k = 0; k < 4; k++) { const a = rand() * 6.28, dx = Math.cos(a) * 0.07 * s, dz = Math.sin(a) * 0.07 * s, lx = (rand() - 0.5) * 0.25 * s, lz = (rand() - 0.5) * 0.25 * s, ht = (0.3 + rand() * 0.35) * s;
        g.tri([x + lx - dx, y, z + lz - dz], [x + lx + dx, y, z + lz + dz], [x + lx + (rand() - 0.5) * 0.15, y + ht, z + lz + (rand() - 0.5) * 0.15], k % 2 ? c : shade(c, 1.15)); }
      g.sw = null;
    },
    bush(g, x, y, z, s, c) { g.sphere(M.chain(M.t(x, y + 0.45 * s, z), M.s(1.25, 0.8, 1.1)), 0.7 * s, c, 3, 6, (i, j) => (i + j) % 2 ? c : shade(c, 1.12)); },
    // Massif de fleurs : tiges vertes et corolles colorées.
    flowers(g, x, y, z, cols, rand, n = 7) {
      g.sw = { y0: y, h: 0.8, k: 0.7 }; // les fleurs plient un peu moins que l'herbe
      for (let k = 0; k < n; k++) { const a = rand() * 6.28, r = rand() * 1.3, fx = x + Math.cos(a) * r, fz = z + Math.sin(a) * r, ht = 0.35 + rand() * 0.4, c = cols[Math.floor(rand() * cols.length)];
        g.tri([fx - 0.03, y, fz], [fx + 0.03, y, fz], [fx, y + ht, fz], '#3f7f35'); g.tri([fx, y, fz - 0.03], [fx, y, fz + 0.03], [fx, y + ht, fz], '#3f7f35');
        g.sphere(M.chain(M.t(fx, y + ht, fz), M.s(1, 0.55, 1)), 0.13, c, 2, 6); g.box(M.t(fx, y + ht + 0.05, fz), 0.06, 0.05, 0.06, '#fde047'); }
      g.sw = null;
    },
    sheep(g, x, y, z, rot) {
      const m = M.chain(M.t(x, y, z), M.ry(rot)), at = (a, b, c) => M.chain(m, M.t(a, b, c));
      g.sphere(M.chain(at(0, 0.62, 0), M.s(1.35, 0.85, 0.9)), 0.42, '#f4f4f0', 3, 7, (i, j) => (i + j) % 2 ? '#f4f4f0' : '#e7e5df');
      g.box(at(0.55, 0.78, 0), 0.3, 0.26, 0.22, '#2b2b2b'); g.box(at(0.5, 0.86, 0), 0.06, 0.08, 0.36, '#2b2b2b');
      for (const [a, c] of [[0.3, 0.16], [0.3, -0.16], [-0.3, 0.16], [-0.3, -0.16]]) g.box(at(a, 0.2, c), 0.08, 0.4, 0.08, '#2b2b2b');
    },
    fence(g, a, b, c = '#8b6b4a') { // deux lisses entre deux piquets
      g.box(M.t(a[0], a[1] + 0.55, a[2]), 0.12, 1.1, 0.12, c);
      for (const h of [0.45, 0.85]) g.tube([a[0], a[1] + h, a[2]], [b[0], b[1] + h, b[2]], 0.035, c, 4, 0.035, false);
    },
    bench(g, x, y, z, rot) { const m = M.chain(M.t(x, y, z), M.ry(rot)), at = (a, b, c) => M.chain(m, M.t(a, b, c)); g.box(at(0, 0.45, 0), 1.6, 0.06, 0.45, '#9a6b3f'); g.box(at(0, 0.75, -0.2), 1.6, 0.35, 0.05, '#9a6b3f'); for (const k of [-0.7, 0.7]) g.box(at(k, 0.22, 0), 0.06, 0.45, 0.4, '#374151'); },
    lighthouse(g, x, y, z) {
      for (let k = 0; k < 6; k++) g.cyl(M.t(x, y + k * 3, z), 2.2 - k * 0.18, 2.2 - (k + 1) * 0.18, 3, 10, k % 2 ? '#dc2626' : '#f8fafc', false);
      g.cyl(M.t(x, y + 18, z), 1.5, 1.5, 0.3, 10, '#1f2937'); g.cyl(M.t(x, y + 18.3, z), 0.9, 0.9, 1.6, 8, '#fde68a'); g.cyl(M.t(x, y + 19.9, z), 1.2, 0.1, 1.4, 8, '#b91c1c', false);
      g.box(M.t(x + 3.5, y + 1.4, z), 4, 2.8, 3.5, '#f1efe8', '#e5e7eb');
    },
    // Pyramide à degrés discrets (empilement de couches carrées), rayon R = demi-diagonale de la base.
    pyramid(g, x, y, z, R, rot) {
      const N = 14, H = R * 0.9;
      for (let k = 0; k < N; k++) { const r0 = R * (1 - k / N), r1 = R * (1 - (k + 1) / N); g.cyl(M.chain(M.t(x, y + H * k / N, z), M.ry(rot + Math.PI / 4)), r0, r1, H / N, 4, k % 2 ? '#d6a35e' : '#cf9a52', false); }
    },
    barrel(g, x, y, z, s) { g.sphere(M.chain(M.t(x, y + 0.35 * s, z), M.s(1, 1.15, 1)), 0.38 * s, '#4f7d3c', 3, 8, (i, j) => j % 2 ? '#4f7d3c' : '#5f9046'); g.sphere(M.t(x, y + 0.8 * s, z), 0.09 * s, '#f472b6', 2, 5); },
    pear(g, x, y, z, s, rand) { const pad = (px, py, pz, r, a) => g.sphere(M.chain(M.t(px, py, pz), M.ry(a), M.s(1, 1.25, 0.32)), r, '#5b8a3e', 3, 6); pad(x, y + 0.4 * s, z, 0.38 * s, rand() * 3); pad(x + 0.3 * s, y + 0.95 * s, z, 0.3 * s, rand() * 3); pad(x - 0.28 * s, y + 0.9 * s, z + 0.1 * s, 0.28 * s, rand() * 3); g.sphere(M.t(x + 0.3 * s, y + 1.3 * s, z), 0.07 * s, '#facc15', 2, 4); },
    // Palmier dattier (oasis) : tronc courbé en anneaux, couronne de palmes retombantes. a = direction de l'inclinaison.
    palm(g, x, y, z, s, a) {
      let prev = [x, y - 0.3, z]; const lx = Math.cos(a), lz = Math.sin(a);
      for (let k = 1; k <= 6; k++) { const t = k / 6, q = [x + lx * 1.4 * s * t * t, y + 7 * s * t, z + lz * 1.4 * s * t * t]; g.tube(prev, q, 0.24 * s * (1 - t * 0.35), k % 2 ? '#8a6a45' : '#7a5c3b', 5); prev = q; }
      const top = prev;
      for (let k = 0; k < 8; k++) { const b = a + k * Math.PI / 4 + 0.2, cx = Math.cos(b), cz = Math.sin(b), L = 3.4 * s, mid = [top[0] + cx * L * 0.55, top[1] + 0.5 * s, top[2] + cz * L * 0.55], tip = [top[0] + cx * L, top[1] - 1.4 * s, top[2] + cz * L], sx = -cz * 0.45 * s, sz = cx * 0.45 * s;
        const c = k % 2 ? '#3f8f3a' : '#4fa53f'; g.tri(top, [mid[0] + sx, mid[1], mid[2] + sz], mid, c); g.tri(top, mid, [mid[0] - sx, mid[1], mid[2] - sz], shade(c, 0.9)); g.tri([mid[0] + sx, mid[1], mid[2] + sz], tip, mid, c); g.tri(mid, tip, [mid[0] - sx, mid[1], mid[2] - sz], shade(c, 0.9)); }
      for (let k = 0; k < 4; k++) g.sphere(M.t(top[0] + Math.cos(k * 1.6) * 0.35 * s, top[1] - 0.35 * s, top[2] + Math.sin(k * 1.6) * 0.35 * s), 0.18 * s, '#c27c2c', 2, 4); // dattes
    },
    cactus(g, x, y, z, s) { const c = '#4d7c3a'; g.cyl(M.t(x, y, z), 0.28 * s, 0.24 * s, 3 * s, 6, c); g.cyl(M.chain(M.t(x + 0.25 * s, y + 1.4 * s, z), M.rz(-1.2)), 0.16 * s, 0.14 * s, 0.6 * s, 5, c); g.cyl(M.t(x + 0.75 * s, y + 1.6 * s, z), 0.15 * s, 0.13 * s, 0.9 * s, 5, c); },
    sign(g, x, y, z, rot, km) { const m = M.chain(M.t(x, y, z), M.ry(rot)); g.tube(M.apply(m, [0, 0, 0]), M.apply(m, [0, 1.6, 0]), 0.05, '#e5e7eb', 4); g.box(M.chain(m, M.t(0, 1.75, 0)), 0.1, 0.5, 0.8, '#22d3ee'); },
    arch(g, w, i, label) {
      const L = crossPoint(w, i, -5, w.E[i]), Rt = crossPoint(w, i, 5, w.E[i]);
      g.tube(L, [L[0], L[1] + 5, L[2]], 0.25, '#0e7490', 6); g.tube(Rt, [Rt[0], Rt[1] + 5, Rt[2]], 0.25, '#0e7490', 6);
      g.tube([L[0], L[1] + 5, L[2]], [Rt[0], Rt[1] + 5, Rt[2]], 0.6, label === 'fin' ? '#22d3ee' : '#2dd4bf', 6);
    },
  };

  /* ---------- Routes secondaires ----------
     Chaque parcours a plusieurs routes secondaires : elles quittent la route principale à un embranchement, traversent le
     décor (lacets, pistes entre les dunes, routes forestières, chemins de campagne, chemin côtier, rues du bourg) puis la
     rejoignent plus loin. Le tracé est défini dans le repère de la route (distance s, décalage latéral off), ce qui permet de
     suivre exactement le relief dessiné. Une route n'est retenue que si elle reste sur la terre ferme, hors des virages
     repliés, et si sa pente reste raisonnable (15 % maximum). Le cycliste peut réellement y rouler (même modèle que la route
     principale : position, pente, résistance du home trainer). */
  // Hauteur du terrain telle qu'elle est dessinée (colonnes de terrain rapprochées à l'intérieur des virages), à une distance s quelconque.
  function groundDrawn(theme, w, s, off) {
    const f = Math.max(0, Math.min(w.n - 1.001, s / STEP)), i = Math.floor(f), t = f - i;
    const one = ii => {
      if (Math.abs(off) <= 4.6) return w.E[ii];
      const OF = offsOf(theme), cl = o => Math.sign(o) * Math.min(Math.abs(o), lim(w, ii, o));
      const pos = OF.map(cl), hs = OF.map(o => side(theme, w, ii, cl(o))[0]);
      for (let k = 0; k < OF.length - 1; k++) if (off >= pos[k] && off <= pos[k + 1] && pos[k + 1] > pos[k]) return hs[k] + (hs[k + 1] - hs[k]) * (off - pos[k]) / (pos[k + 1] - pos[k]);
      return side(theme, w, ii, off)[0];
    };
    return one(i) * (1 - t) + one(i + 1) * t;
  }
  function frameAt(w, s) {
    const f = Math.max(0, Math.min(w.n - 1.001, s / STEP)), i = Math.floor(f), t = f - i;
    return { x: w.X[i] + (w.X[i + 1] - w.X[i]) * t, z: w.Z[i] + (w.Z[i + 1] - w.Z[i]) * t, h: w.Hd[i] + (w.Hd[i + 1] - w.Hd[i]) * t, i };
  }
  const BR_NAMES = {
    montagne: ['Lacets du Belvédère', 'Route panoramique des Aiguilles', 'Lacets de la Combe', 'Petit col du Lauzet', 'Lacets du Pré Vert', 'Route des Crêtes', 'Lacets des Marmottes'],
    canyon: ['Piste des Dunes', 'Passage des Grès', 'Piste des Caravanes', 'Route des Sables', 'Piste du Mirage', 'Passage des Vautours'],
    foret: ['Route forestière des Sapins', 'Chemin des Bûcherons', 'Route du Sous-bois', 'Allée des Pins', 'Chemin de la Clairière'],
    campagne: ['Chemin des Blés', 'Route des Fermes', 'Chemin du Moulin', 'Route des Haies', 'Chemin des Tournesols'],
    littoral: ['Route des Collines', 'Corniche des Prés', 'Route du Belvédère marin', 'Chemin des Genêts'],
    ville: ['Rue de l’Église', 'Rue des Jardins', 'Rue du Lavoir', 'Chemin des Vergers'],
  };
  const BR_KIND = { montagne: 'Route en lacets', canyon: 'Piste entre les dunes', foret: 'Route forestière', campagne: 'Route de campagne', littoral: 'Route panoramique sur la mer', ville: 'Rue du bourg' };
  // Tracé proposé (points de contrôle en (s, off)) selon le décor ; sg = côté (-1 gauche, +1 droite).
  function branchDesign(theme, sA, rand, k, w) {
    // facteur d'échelle le long de la route à un décalage donné (intérieur d'un virage : les distances se resserrent)
    const scaleAt = (s, off) => { if (!w) return 1; const i = Math.max(3, Math.min(w.n - 4, Math.round(s / STEP))); const kap = (w.Hd[i + 3] - w.Hd[i - 3]) / (6 * STEP); return Math.max(0.25, 1 - kap * off); };
    const P = [], push = (s, o) => P.push([s, o]);
    let sg = rand() < 0.5 ? -1 : 1, hw = 2.6, kind = BR_KIND[theme];
    const enter = (s0, sg) => { push(s0, sg * 3.2); push(s0 + 30, sg * 6); push(s0 + 75, sg * 14); };
    const leave = (s1, sg) => { push(s1 - 75, sg * 14); push(s1 - 30, sg * 6); push(s1, sg * 3.2); };
    if (theme === 'montagne') { // lacets qui descendent dans la vallée (côté gauche, moins raide), col, puis remontée
      sg = -1; enter(sA, sg);
      const leg = 160 + rand() * 80, D0 = 24 + rand() * 6, R = 11, legs = 2 + Math.floor(rand() * 2);
      let s = sA + 120, o = D0, dir = 1;
      push(s, sg * o);
      for (let l = 0; l < legs; l++) {
        const s2 = s + dir * leg, o2 = o + 14; push(s + dir * leg * 0.5, sg * (o + 7)); push(s2, sg * o2);
        const f2 = scaleAt(s2, sg * (o2 + R)); // épingle vraiment circulaire sur le terrain, même à l'intérieur d'un virage
        for (let a = 1; a <= 6; a++) { const th = -Math.PI / 2 + a * Math.PI / 6; push(s2 + dir * R * Math.cos(th) / f2, sg * (o2 + R + R * Math.sin(th))); }
        s = s2; o = o2 + 2 * R; dir = -dir; push(s + dir * 15, sg * o);
      }
      if (dir < 0) { const s2 = s - 120, f2 = scaleAt(s2, sg * (o + 8 + R)); push(s2, sg * (o + 8)); for (let a = 1; a <= 6; a++) { const th = -Math.PI / 2 + a * Math.PI / 6; push(s2 - R * Math.cos(th) / f2, sg * (o + 8 + R + R * Math.sin(th))); } s = s2; o = o + 8 + 2 * R; dir = 1; push(s + 15, sg * o); }
      const sTop = Math.max(s + 180, sA + 600); push(sTop, sg * (o + 4)); push(sTop + 220, sg * (o * 0.6)); const sB = sTop + 480 + rand() * 200; push(sB - 160, sg * 26); leave(sB, sg);
      return { P, sg, hw: 2.6, kind, sB };
    }
    if (theme === 'canyon') { // piste sinueuse entre les dunes, dans une zone de désert ouvert (hors des falaises)
      hw = 3; let s0 = sA; const span = 1000 + rand() * 250;
      const open = x => { for (let q = x; q <= x + span; q += 50) if (desertOpen(q) < 0.62) return false; return true; };
      while (!open(s0) && s0 < sA + 4000) s0 += 50;
      enter(s0, sg); let s = s0 + 120; const n = 2 + Math.floor(rand() * 2), stepS = (span - 360) / n;
      for (let j = 0; j < n; j++) { s += stepS; push(s, sg * (35 + rand() * 45)); }
      const sB = s0 + span; leave(sB, sg); return { P, sg, hw, kind, sB };
    }
    if (theme === 'foret') { // route sinueuse dans la forêt (côté opposé au lac)
      sg = 1; hw = 2.5; enter(sA, sg); const n = 5 + Math.floor(rand() * 4); let s = sA + 130;
      for (let j = 0; j < n; j++) { s += 170 + rand() * 150; push(s, sg * (30 + rand() * 110)); }
      const sB = s + 360; leave(sB, sg); return { P, sg, hw, kind, sB };
    }
    if (theme === 'campagne') { // chemin rural : part à angle droit, longe les champs, coude, revient à angle droit
      hw = 2.3; const net = w && w.layout, D = net ? 45 + rand() * 70 : 50 + rand() * 120, len = net ? 300 + rand() * 380 : 900 + rand() * 900, jog = (rand() < 0.5 ? -1 : 1) * (net ? 10 + rand() * 15 : 20 + rand() * 25);
      push(sA, sg * 3.2); push(sA + 14, sg * 8); push(sA + 22, sg * 18); push(sA + 28, sg * (D * 0.5)); push(sA + 34, sg * (D - 12)); push(sA + 50, sg * D);
      const s1 = sA + 50 + len * 0.5; push(s1 - 40, sg * D); push(s1, sg * (D + jog * 0.5)); push(s1 + 40, sg * (D + jog));
      const sB = sA + 100 + len; push(sB - 50, sg * (D + jog)); push(sB - 34, sg * (D + jog - 12)); push(sB - 28, sg * ((D + jog) * 0.5)); push(sB - 22, sg * 18); push(sB - 14, sg * 8); push(sB, sg * 3.2);
      return { P, sg, hw, kind, sB };
    }
    if (theme === 'littoral') {
      if (false) { // (chemin sur la plage : abandonné, la plage est trop raide sous la route sur tout le parcours)
        sg = -1; hw = 2.0; push(sA, -3.2); push(sA + 30, -6); push(sA + 80, -11);
        const len = 900 + rand() * 700; for (let s = sA + 200; s < sA + len; s += 220) push(s, -(12 + rand() * 4));
        const sB = sA + len + 160; push(sB - 80, -11); push(sB - 30, -6); push(sB, -3.2); return { P, sg, hw, kind: 'Chemin côtier', sB };
      }
      sg = 1; enter(sA, sg); let s = sA + 150; const n = 4 + Math.floor(rand() * 3); // route panoramique sur les collines
      for (let j = 0; j < n; j++) { s += 230 + rand() * 150; push(s, 40 + rand() * 130); }
      const sB = s + 380; leave(sB, sg); return { P, sg, hw, kind, sB };
    }
    // ville : rue qui traverse le bourg (côté opposé au port)
    sg = w && w.layout ? (rand() < 0.5 ? -1 : 1) : 1; hw = 2.8; enter(sA, sg); let s = sA + 130; const n = w && w.layout ? 1 + Math.floor(rand() * 2) : 3 + Math.floor(rand() * 3);
    for (let j = 0; j < n; j++) { s += (w && w.layout ? 120 + rand() * 90 : 180 + rand() * 120); push(s, sg * (28 + rand() * (w && w.layout ? 30 : 50))); }
    const sB = s + 340; leave(sB, sg); return { P, sg, hw, kind, sB };
  }
  // Courbe lisse (Catmull-Rom) passant par les points de contrôle, échantillonnée tous les ~2 m.
  function smoothPath(P0) {
    // points de contrôle d'abord rapprochés (12 m au plus) : la courbe ne fait pas de boucle entre une longue ligne droite et une épingle
    const P = [P0[0]];
    for (let k = 1; k < P0.length; k++) { const a = P0[k - 1], b = P0[k], m = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 12)); for (let q = 1; q <= m; q++) P.push([a[0] + (b[0] - a[0]) * q / m, a[1] + (b[1] - a[1]) * q / m]); }
    const out = [];
    for (let k = 0; k < P.length - 1; k++) {
      const p0 = P[Math.max(0, k - 1)], p1 = P[k], p2 = P[k + 1], p3 = P[Math.min(P.length - 1, k + 2)];
      const n = Math.max(2, Math.ceil(Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) / 2));
      for (let j = 0; j < n; j++) { const t = j / n, t2 = t * t, t3 = t2 * t;
        const f = (a, b, c, d) => 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
        out.push([f(p0[0], p1[0], p2[0], p3[0]), f(p0[1], p1[1], p2[1], p3[1])]); }
    }
    out.push(P[P.length - 1]);
    return out;
  }
  const BR_WHY = {};
  function buildBranch(w, d, idx, name) { return noPort(w, () => { w._noSeam = true; limBase.on = true; try { return buildBranch0(w, d, idx, name); } finally { w._noSeam = false; limBase.on = false; } }); } // routes secondaires : tracé et hauteurs inchangés (sans raccord des bandes)
  function buildBranch0(w, d, idx, name) {
    const why = k => { BR_WHY[k] = (BR_WHY[k] || 0) + 1; return null; };
    const theme = w.route.theme, dense = smoothPath(d.P), N = dense.length;
    const pts = dense.map(([s, off]) => { const f = frameAt(w, s), nx = -Math.sin(f.h), nz = Math.cos(f.h); return { s, off, x: f.x + nx * off, z: f.z + nz * off, g: groundDrawn(theme, w, s, off) }; });
    // contrôles : terre ferme, pas de repli de terrain, pas de demi-tour trop serré
    for (const p of pts) {
      const i = Math.round(p.s / STEP);
      if (p.s < 150 || p.s > w.length - 150) return why('bornes');
      if (Math.abs(p.off) > (w.layout ? lim : limBase)(w, i, p.off) - 22) return why('virage'); // lacets : jamais du côté intérieur d'un virage serré
      if (theme === 'littoral' && p.off < -22) return why('mer');
      if (theme === 'foret' && p.off < -12) return why('lac');
      if (theme === 'ville' && p.off < -22 && portOpen(p.s)) return why('port');
      if (theme === 'canyon' && Math.abs(p.off) > 18 && desertOpen(p.s) < 0.6) return why('falaise'); // pas dans les falaises du canyon
      if (theme === 'littoral' && p.off < -7 && at(w, p.s).y - p.g > 3.5) return why('falaise'); // chemin côtier seulement là où la plage est en pente douce
    }
    // la route ne doit jamais se rapprocher d'elle-même (lacets serrés à l'intérieur d'un virage de la route principale)
    { const G = new Map(), cs = 8, key = (x, z) => Math.floor(x / cs) + ',' + Math.floor(z / cs); let acc = 0; const Ls = [0];
      for (let j = 1; j < N; j++) Ls.push(acc += Math.hypot(pts[j].x - pts[j - 1].x, pts[j].z - pts[j - 1].z));
      pts.forEach((p, j) => { const k = key(p.x, p.z); let a = G.get(k); if (!a) G.set(k, a = []); a.push(j); });
      const minD = 2 * d.hw + 4;
      // rayon de virage suffisant partout (sinon le bord intérieur de la chaussée se replierait dans les épingles)
      for (let j = 4; j < N - 4; j++) { const a = pts[j - 4], b = pts[j], c = pts[j + 4], ab = Math.hypot(b.x - a.x, b.z - a.z), bc = Math.hypot(c.x - b.x, c.z - b.z), ac = Math.hypot(c.x - a.x, c.z - a.z), cr = Math.abs((b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x));
        if (ab > 1 && bc > 1 && cr > 1e-6 && ab * bc * ac / (2 * cr) < d.hw + 2.5) return why('épingle'); }
      for (let j = 0; j < N; j += 2) { const p = pts[j], cx = Math.floor(p.x / cs), cz = Math.floor(p.z / cs);
        for (let a = -1; a <= 1; a++) for (let c = -1; c <= 1; c++) for (const q of G.get((cx + a) + ',' + (cz + c)) || []) if (Math.abs(Ls[q] - Ls[j]) > 45 && Math.hypot(pts[q].x - p.x, pts[q].z - p.z) < minD) return why('croisement'); } }
    // Profil en long : comme une vraie route, il suit le relief en douceur (moyenne sur ±40 m) avec une pente limitée
    // (12 %, 13 % en montagne) ; le terrain est ensuite ajusté sous la route (déblais/remblais, voir branchesOf).
    const L = [0]; for (let j = 1; j < N; j++) L.push(L[j - 1] + Math.hypot(pts[j].x - pts[j - 1].x, pts[j].z - pts[j - 1].z));
    const GMAX = theme === 'montagne' ? 0.13 : 0.12, CUT = theme === 'montagne' ? 10 : 6;
    const e0 = at(w, pts[0].s).y + 0.07, e1 = at(w, pts[N - 1].s).y + 0.07;
    const sm = pts.map((_, j) => { let a = 0, c = 0; for (let q = Math.max(0, j - 20); q <= Math.min(N - 1, j + 20); q++) { a += pts[q].g; c++; } return a / c + 0.16; });
    // tant que la route secondaire touche la chaussée principale (embranchement), elle reste exactement à sa hauteur
    const glued = pts.map(p => Math.abs(p.off) - d.hw < 7.5), gy = pts.map(p => at(w, p.s).y + 0.07);
    const fix = () => { for (let j = 0; j < N; j++) if (glued[j]) sm[j] = gy[j]; };
    fix();
    for (let pass = 0; pass < 4; pass++) {
      for (let j = 1; j < N; j++) { const dd = (L[j] - L[j - 1]) * GMAX; sm[j] = Math.max(sm[j - 1] - dd, Math.min(sm[j - 1] + dd, sm[j])); }
      fix();
      for (let j = N - 2; j >= 0; j--) { const dd = (L[j + 1] - L[j]) * GMAX; sm[j] = Math.max(sm[j + 1] - dd, Math.min(sm[j + 1] + dd, sm[j])); }
      fix();
    }
    for (let j = 1; j < N; j++) if (Math.abs(sm[j] - sm[j - 1]) > (L[j] - L[j - 1]) * (GMAX + 0.01) + 0.02) return why('raccord');
    for (let j = 0; j < N; j++) if (!glued[j] && Math.abs(sm[j] - pts[j].g) > CUT) return why('terrassement');
    const len = L[N - 1], n = Math.ceil(len / STEP) + 1, X = new Float64Array(n), Z = new Float64Array(n), E = new Float64Array(n), S = new Float64Array(n), Hd = new Float64Array(n);
    let j = 0;
    for (let q = 0; q < n; q++) { const u = Math.min(len, q * STEP); /* le dernier point est exactement le raccord avec la route principale */ while (j < N - 2 && L[j + 1] < u) j++; const t = Math.max(0, Math.min(1, (u - L[j]) / Math.max(1e-6, L[j + 1] - L[j])));
      X[q] = pts[j].x + (pts[j + 1].x - pts[j].x) * t; Z[q] = pts[j].z + (pts[j + 1].z - pts[j].z) * t; E[q] = sm[j] + (sm[j + 1] - sm[j]) * t; S[q] = pts[j].s + (pts[j + 1].s - pts[j].s) * t; }
    for (let q = 0; q < n; q++) { const a = Math.max(0, q - 1), b = Math.min(n - 1, q + 1); Hd[q] = Math.atan2(Z[b] - Z[a], X[b] - X[a]); }
    let maxG = 0, gain = 0; for (let q = 1; q < n; q++) { const gr = (E[q] - E[q - 1]) / STEP; maxG = Math.max(maxG, Math.abs(gr)); gain += Math.max(0, E[q] - E[q - 1]); }
    if (maxG > GMAX + 0.015) return why('pente');
    const road = { route: w.route, branch: true, n, X, Z, E, Hd, S, length: (n - 1) * STEP, minE: Math.min(...E), maxE: Math.max(...E), dplus: Math.round(gain) };
    return { id: idx, name, kind: d.kind, side: d.sg, hw: d.hw, sA: pts[0].s, sB: pts[N - 1].s, road, len: road.length, dplus: road.dplus, maxGrade: maxG, L, dense: pts.map((p, q) => ({ ...p, y: sm[q] })) };
  }
  // Toutes les routes secondaires d'un parcours (déterministes : les mêmes pour tous les joueurs et à chaque chargement).
  function branchesOf(w) {
    if (w._br) return w._br;
    const theme = w.route.theme, rand = rng(w.route.seed * 313 + 7), out = [], L = w.length;
    const count = w.layout ? 5 : Math.max(3, Math.min(7, Math.round(L / 9000))), names = (w.route.brNames || BR_NAMES[theme] || BR_NAMES.campagne);
    for (let k = 0; k < count; k++) {
      for (let tr = 0; tr < 90; tr++) {
        const sA = w.layout ? 500 + (L - 2200) * (k + 0.1 + rand() * 0.8) / count : 700 + (L - 3500) * (k + 0.15 + rand() * 0.7) / count;
        const d = branchDesign(theme, sA, rand, k, w);
        if (d.sB > L - 400 || out.some(b => d.P[0][0] < b.sB + 300 && d.sB > b.sA - 300)) continue;
        if (w.layout && w.plan.some(p => p.kind === 'virage' && p.s0 < d.sB + 60 && p.s1 > d.P[0][0] - 60)) continue; // embranchements et raccords sur les lignes droites, jamais dans un virage
        const b = buildBranch(w, d, out.length, names[out.length % names.length]);
        if (b) { out.push(b); break; }
      }
    }
    out.sort((a, b) => a.sA - b.sA).forEach((b, i) => { b.id = i; });
    // repérage rapide des points des routes secondaires (cases de 16 m) pour dégager le décor
    const grid = new Map();
    for (const b of out) for (const p of b.dense) { const key = Math.floor(p.x / 16) + ',' + Math.floor(p.z / 16); let a = grid.get(key); if (!a) grid.set(key, a = []); a.push([p.x, p.z, b.hw]); }
    out.hit = (x, z, r) => { const cx = Math.floor(x / 16), cz = Math.floor(z / 16), R = Math.ceil((r + 4) / 16);
      for (let a = -R; a <= R; a++) for (let c = -R; c <= R; c++) { const l = grid.get((cx + a) + ',' + (cz + c)); if (l) for (const q of l) if (Math.hypot(q[0] - x, q[1] - z) < q[2] + r + 1.2) return true; } return false; };
    w._br = out;
    // Terrain ajusté sous les routes secondaires : les colonnes de terrain proches de la route prennent sa hauteur
    // (déblai dans les pentes, remblai dans les creux). La route n'est donc jamais enterrée ni suspendue.
    const adj = new Map(), OF = offsOf(theme);
    for (const b of out) {
      const iA = Math.max(0, Math.floor(Math.min(...b.dense.map(p => p.s)) / STEP) - 2), iB = Math.min(w.n - 1, Math.ceil(Math.max(...b.dense.map(p => p.s)) / STEP) + 2);
      for (let i = iA; i <= iB; i++) for (let k = 0; k < OF.length; k++) {
        const o = Math.sign(OF[k]) * Math.min(Math.abs(OF[k]), lim(w, i, OF[k])); if (Math.abs(o) <= 9) continue;
        const gap = Math.max(Math.abs(OF[Math.min(OF.length - 1, k + 1)] - OF[k]), Math.abs(OF[k] - OF[Math.max(0, k - 1)])), R = Math.max(b.hw + 10, gap * 0.9);
        const c = crossPoint(w, i, o, 0), R2 = R * R; let by = Infinity;
        for (const p of b.dense) { const dd = (p.x - c[0]) ** 2 + (p.z - c[2]) ** 2; if (dd <= R2 && p.y < by) by = p.y; }
        if (by < Infinity) { const key = i * 16384 + Math.round(o * 10) + 8192, prev = adj.get(key); adj.set(key, prev === undefined ? by - 0.22 : Math.min(prev, by - 0.22)); }
      }
    }
    w._adj = adj;
    // La chaussée dessinée ne passe jamais sous le terrain (petites bosses entre deux colonnes de terrain) ; le profil de la
    // route (hauteur du cycliste, pente, résistance) est recalé sur cette chaussée dessinée.
    for (const b of out) {
      const d = b.dense, N = d.length;
      for (let j = 0; j < N; j++) {
        const p = d[j], q = d[Math.min(N - 1, j + 1)], r0 = d[Math.max(0, j - 1)], ds = q.s - r0.s, dof = q.off - r0.off, Lr = Math.hypot(ds, dof) || 1;
        if (Math.abs(p.off) - b.hw < 7.5) continue; // embranchement : reste à la hauteur de la route principale
        let y = Math.max(p.y, groundDrawn(theme, w, p.s, p.off) + 0.06);
        for (const k of [-1, 1]) y = Math.max(y, groundDrawn(theme, w, p.s - dof / Lr * b.hw * k, p.off + ds / Lr * b.hw * k) + 0.06);
        p.y = y;
      }
      // pente adoucie autour de ces bosses : la route monte doucement dessus (petit remblai), jamais de mur
      const GM = theme === 'montagne' ? 0.13 : 0.12, glue = j => Math.abs(d[j].off) - b.hw < 7.5;
      for (let pass = 0; pass < 2; pass++) {
        for (let j = 1; j < N; j++) if (!glue(j)) d[j].y = Math.max(d[j].y, d[j - 1].y - GM * (b.L[j] - b.L[j - 1]));
        for (let j = N - 2; j >= 0; j--) if (!glue(j)) d[j].y = Math.max(d[j].y, d[j + 1].y - GM * (b.L[j + 1] - b.L[j]));
      }
      const rd = b.road; let jj = 0;
      for (let q = 0; q < rd.n; q++) { const u = Math.min(b.L[N - 1], q * STEP); while (jj < N - 2 && b.L[jj + 1] < u) jj++; const t = Math.max(0, Math.min(1, (u - b.L[jj]) / Math.max(1e-6, b.L[jj + 1] - b.L[jj]))); rd.E[q] = d[jj].y + (d[jj + 1].y - d[jj].y) * t; }
      let mg = 0, gain = 0; for (let q = 1; q < rd.n; q++) { mg = Math.max(mg, Math.abs(rd.E[q] - rd.E[q - 1]) / STEP); gain += Math.max(0, rd.E[q] - rd.E[q - 1]); }
      b.maxGrade = mg; b.dplus = rd.dplus = Math.round(gain); rd.minE = Math.min(...rd.E); rd.maxE = Math.max(...rd.E);
    }
    return out;
  }
  // Position sur la route principale correspondant à une position u sur une route secondaire (pour charger le décor).
  /* ---------- Segments chronométrés ----------
     Calculés à partir du vrai tracé (mêmes résultats sur tous les appareils et sur le serveur, voir
     scripts/segments-info.mjs) : la montée la plus raide sur 2 km, une portion rapide (1 km plat ou en légère descente),
     une seconde montée sur les parcours longs, et une route secondaire complète. Sur la route principale, un segment ne
     contient aucun embranchement : on le parcourt sans avoir à choisir. Départ et arrivée sont des positions exactes sur
     la route (en mètres depuis le départ, ou le long de la route secondaire). */
  const SEG_NAMES = {
    littoral: { climb: ['Montée de la Corniche', 'Côte du Sémaphore'], fast: 'Sprint de la Promenade' },
    montagne: { climb: ['Rampe du Belvédère', 'Montée des Mélèzes'], fast: 'Descente des Prés' },
    canyon: { climb: ['Côte des Falaises Rouges', 'Montée de la Mesa'], fast: 'Ligne droite du Désert' },
    foret: { climb: ['Côte des Sapins', 'Montée du Sous-bois'], fast: 'Sprint du Lac' },
    ville: { climb: ['Côte du Clocher', 'Montée des Jardins'], fast: 'Sprint des Quais' },
    campagne: { climb: ['Côte du Moulin', 'Montée des Blés'], fast: 'Sprint des Tournesols' },
  };
  function segmentsOf(w) {
    if (w._segs) return w._segs;
    const B = branchesOf(w), L = w.length, out = [], used = [];
    const free = (a, b) => !B.some(x => x.sA < b + 120 && x.sB > a - 120) && !used.some(([c, d]) => c < b + 300 && d > a - 300) && a > 600 && b < L - 400;
    const grade = (a, b) => (w.E[Math.round(b / STEP)] - w.E[Math.round(a / STEP)]) / (b - a);
    const best = (len, score) => { let bs = null; for (let a = 600; a + len < L - 400; a += 50) { if (!free(a, a + len)) continue; const v = score(a, a + len); if (v !== null && (!bs || v > bs.v)) bs = { a, b: a + len, v }; } return bs; };
    const N = SEG_NAMES[w.route.theme] || SEG_NAMES.campagne;
    if (w.route.sprint) { // parcours de sprint : sprints de 400 m en fin de longue ligne droite, relances de 300 m en sortie de virage
      const R = w.route, addF = (name, a, b) => { used.push([a, b]); out.push({ id: R.id + ':fast' + (out.filter(x => x.kind === 'fast').length + 1), kind: 'fast', name, road: -1, sA: a, sB: b, len: b - a, grade: Math.round(grade(a, b) * 1000) / 10, dplus: Math.max(0, Math.round(w.E[Math.round(b / STEP)] - w.E[Math.round(a / STEP)])) }); };
      const ok = (a, b) => !B.some(x => x.sA < b + 120 && x.sB > a - 120) && !used.some(([c, d]) => c < b + 150 && d > a - 150) && a > 300 && b < L - 150;
      const legs = w.plan.filter(p => p.kind === 'droite' && p.s1 - p.s0 >= 650).sort((x, y) => (y.s1 - y.s0) - (x.s1 - x.s0));
      let k = 0; for (const p of legs) { if (k >= 4) break; for (const end of [p.s1 - 60, p.s1 - 220, p.s0 + 460]) { const a = Math.round(end - 400), b = Math.round(end); if (a >= p.s0 + 20 && ok(a, b)) { addF(R.segNames[k], a, b); k++; break; } } }
      let r = 0; for (const p of w.plan.filter(q => q.kind === 'droite' && q.s0 > 0 && q.s1 - q.s0 >= 520)) { if (r >= 2) break; const a = Math.round(p.s0 + 15), b = a + 300; if (ok(a, b)) { addF(R.relNames[r], a, b); r++; } }
      const bi = B.reduce((kk, b, i) => (kk < 0 || b.len > B[kk].len ? i : kk), -1);
      if (bi >= 0) { const b = B[bi]; out.push({ id: R.id + ':branch' + (bi + 1), kind: 'branch', name: b.name, road: bi, sA: 0, sB: b.road.length, mainA: b.sA, mainB: b.sB, len: b.road.length, grade: Math.round((b.road.E[b.road.n - 1] - b.road.E[0]) / b.road.length * 1000) / 10, maxGrade: Math.round(b.maxGrade * 1000) / 10, dplus: b.dplus }); }
      out.sort((x, y) => (x.road < 0 ? x.sA : x.mainA) - (y.road < 0 ? y.sA : y.mainA));
      for (const x of out) { x.len = Math.round(x.len); x.sA = Math.round(x.sA * 10) / 10; x.sB = Math.round(x.sB * 10) / 10; }
      return (w._segs = out);
    }
    const add = (kind, name, a, b) => { used.push([a, b]); const g = grade(a, b); out.push({ id: w.route.id + ':' + kind + (out.filter(x => x.kind === kind).length + 1), kind, name, road: -1, sA: a, sB: b, len: b - a, grade: Math.round(g * 1000) / 10, dplus: Math.max(0, Math.round(w.E[Math.round(b / STEP)] - w.E[Math.round(a / STEP)])) }); };
    const c1 = best(2000, (a, b) => grade(a, b)); if (c1) add('climb', N.climb[0], c1.a, c1.b);
    const f1 = best(1000, (a, b) => { const g = grade(a, b); return g <= 0.005 && g >= -0.03 ? -Math.abs(g + 0.012) : null; }); if (f1) add('fast', N.fast, f1.a, f1.b);
    if (L >= 45000) { const c2 = best(1500, (a, b) => grade(a, b)); if (c2 && c2.v > 0.008) add('climb', N.climb[1], c2.a, c2.b); }
    // route secondaire : la plus longue (du départ de la route secondaire à son raccord)
    const bi = B.reduce((k, b, i) => (k < 0 || b.len > B[k].len ? i : k), -1);
    if (bi >= 0) { const b = B[bi]; out.push({ id: w.route.id + ':branch' + (bi + 1), kind: 'branch', name: b.name, road: bi, sA: 0, sB: b.road.length, mainA: b.sA, mainB: b.sB, len: b.road.length, grade: Math.round((b.road.E[b.road.n - 1] - b.road.E[0]) / b.road.length * 1000) / 10, maxGrade: Math.round(b.maxGrade * 1000) / 10, dplus: b.dplus }); }
    out.sort((x, y) => (x.road < 0 ? x.sA : x.mainA) - (y.road < 0 ? y.sA : y.mainA));
    for (const x of out) { x.len = Math.round(x.len); x.sA = Math.round(x.sA * 10) / 10; x.sB = Math.round(x.sB * 10) / 10; }
    return (w._segs = out);
  }
  const branchMainS = (b, u) => { const f = Math.max(0, Math.min(b.road.n - 1.001, u / STEP)), i = Math.floor(f); return b.road.S[i] + (b.road.S[i + 1] - b.road.S[i]) * (f - i); };

  // parcours « réseau » : pas de bassin de port (le port du Vieux Port suit la distance le long de la route)
  function noPort(w, fn) { if (!w.layout) return fn(); const k = portOpen; portOpen = () => 0; try { return fn(); } finally { portOpen = k; } }
  function buildChunk(w, c) { return noPort(w, () => buildChunk0(w, c)); }
  function buildChunk0(w, c) {
    const route = w.route, theme = route.theme, g = new Geo(), gd = new Geo(), rand = rng(route.seed * 1000 + c * 17);
    g.detail = gd; // petits détails (herbe, fleurs) : maillage à part, dessiné seulement près de la caméra
    const i0 = c * CHUNK, i1 = Math.min(w.n - 1, i0 + CHUNK);
    if (i0 >= w.n - 1) return g;
    // sol de part et d'autre
    const OFFS = offsOf(theme);
    const cl = (ii, o) => Math.sign(o) * Math.min(Math.abs(o), lim(w, ii, o)); // pas de repli à l'intérieur des virages
    for (let i = i0; i < i1; i++) {
      const A = OFFS.map(o => side(theme, w, i, cl(i, o))), B = OFFS.map(o => side(theme, w, i + 1, cl(i + 1, o)));
      for (let k = 0; k < OFFS.length - 1; k++) {
        if (OFFS[k] < 0 && OFFS[k + 1] > 0) continue; // la route est construite à part
        const a = crossPoint(w, i, cl(i, OFFS[k]), A[k][0]), b = crossPoint(w, i + 1, cl(i + 1, OFFS[k]), B[k][0]), cc = crossPoint(w, i + 1, cl(i + 1, OFFS[k + 1]), B[k + 1][0]), d = crossPoint(w, i, cl(i, OFFS[k + 1]), A[k + 1][0]);
        g.quad(a, d, cc, b, Math.abs(OFFS[k]) > Math.abs(OFFS[k + 1]) ? A[k][1] : A[k + 1][1]);
      }
    }
    // avant la ligne de départ : la route et le terrain se prolongent en ligne droite (pour la caméra placée derrière le cycliste)
    if (c === 0) {
      const h = w.Hd[0], dx = Math.cos(h), dz = Math.sin(h), A0 = OFFS.map(o => side(theme, w, 0, o)), e0 = w.E[0] + 0.05;
      const pb = (off, y, d) => { const q = crossPoint(w, 0, off, y); return [q[0] - dx * d, y, q[2] - dz * d]; };
      for (let d = 0; d < 120; d += 20) {
        const oe = o => w.layout ? cl(0, o) : o; // réseau : le prolongement avant le départ s'arrête aussi à la limite des portions voisines
        for (let k = 0; k < OFFS.length - 1; k++) { if (OFFS[k] < 0 && OFFS[k + 1] > 0) continue; g.quad(pb(oe(OFFS[k]), A0[k][0], d + 20), pb(oe(OFFS[k + 1]), A0[k + 1][0], d + 20), pb(oe(OFFS[k + 1]), A0[k + 1][0], d), pb(oe(OFFS[k]), A0[k][0], d), Math.abs(OFFS[k]) > Math.abs(OFFS[k + 1]) ? A0[k][1] : A0[k + 1][1]); }
        g.quad(pb(-4.6, e0 - 0.03, d + 20), pb(4.6, e0 - 0.03, d + 20), pb(4.6, e0 - 0.03, d), pb(-4.6, e0 - 0.03, d), theme === 'ville' ? '#aeb0a9' : theme === 'canyon' ? '#c99a6c' : '#7d8a6a');
        g.quad(pb(-3.6, e0, d + 20), pb(3.6, e0, d + 20), pb(3.6, e0, d), pb(-3.6, e0, d), '#4b5260');
        for (const o of [-3.35, 3.35]) g.quad(pb(o - 0.12, e0 + 0.01, d + 20), pb(o + 0.12, e0 + 0.01, d + 20), pb(o + 0.12, e0 + 0.01, d), pb(o - 0.12, e0 + 0.01, d), '#e5e7eb');
      }
    }
    // après la ligne d'arrivée : même prolongement de 120 m (sinon la route et le terrain s'arrêtent net devant la caméra)
    if (i1 === w.n - 1) {
      const N = w.n - 1, h = w.Hd[N], dx = Math.cos(h), dz = Math.sin(h), A0 = OFFS.map(o => side(theme, w, N, cl(N, o))), e0 = w.E[N] + 0.05;
      const pf = (off, y, d) => { const q = crossPoint(w, N, off, y); return [q[0] + dx * d, y, q[2] + dz * d]; };
      const prom = theme === 'littoral' && N * STEP > w.length * 0.45;
      for (let d = 0; d < 120; d += 20) {
        for (let k = 0; k < OFFS.length - 1; k++) { if (OFFS[k] < 0 && OFFS[k + 1] > 0) continue; const o0 = cl(N, OFFS[k]), o1 = cl(N, OFFS[k + 1]); g.quad(pf(o0, A0[k][0], d), pf(o1, A0[k + 1][0], d), pf(o1, A0[k + 1][0], d + 20), pf(o0, A0[k][0], d + 20), Math.abs(OFFS[k]) > Math.abs(OFFS[k + 1]) ? A0[k][1] : A0[k + 1][1]); }
        if (prom) for (let k = 0; k < 5; k++) g.quad(pf(-4.6, e0, d + k * 4), pf(4.6, e0, d + k * 4), pf(4.6, e0, d + k * 4 + 4), pf(-4.6, e0, d + k * 4 + 4), k % 2 ? '#a88760' : '#b8956b');
        else {
          g.quad(pf(-4.6, e0 - 0.03, d), pf(4.6, e0 - 0.03, d), pf(4.6, e0 - 0.03, d + 20), pf(-4.6, e0 - 0.03, d + 20), theme === 'ville' ? '#aeb0a9' : theme === 'canyon' ? '#c99a6c' : '#7d8a6a');
          g.quad(pf(-3.6, e0, d), pf(3.6, e0, d), pf(3.6, e0, d + 20), pf(-3.6, e0, d + 20), '#4b5260');
          for (const o of [-3.35, 3.35]) g.quad(pf(o - 0.12, e0 + 0.01, d), pf(o + 0.12, e0 + 0.01, d), pf(o + 0.12, e0 + 0.01, d + 20), pf(o - 0.12, e0 + 0.01, d + 20), '#e5e7eb');
        }
      }
    }
    // route
    const promenade = theme === 'littoral' && c * CHUNK * STEP > w.length * 0.45;
    for (let i = i0; i < i1; i++) {
      const e0 = w.E[i] + 0.05, e1 = w.E[i + 1] + 0.05;
      const r = (o, ii, ee) => crossPoint(w, ii, o, ee);
      if (promenade) {
        for (let k = 0; k < 5; k++) { const t0 = k / 5, t1 = (k + 1) / 5, mid = (p, q, t) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, p[2] + (q[2] - p[2]) * t];
          const a = r(-4.6, i, e0), b = r(-4.6, i + 1, e1), cc = r(4.6, i + 1, e1), d = r(4.6, i, e0);
          g.quad(mid(a, b, t0), mid(d, cc, t0), mid(d, cc, t1), mid(a, b, t1), k % 2 ? '#a88760' : '#b8956b'); }
      } else {
        g.quad(r(-4.6, i, e0 - 0.03), r(4.6, i, e0 - 0.03), r(4.6, i + 1, e1 - 0.03), r(-4.6, i + 1, e1 - 0.03), theme === 'ville' ? '#aeb0a9' : theme === 'canyon' ? '#c99a6c' : '#7d8a6a');
        // rebord sous l'accotement : pas de vide entre la route et un terrain plus bas (plage, talus)
        for (const o of [-4.6, 4.6]) g.quad(r(o, i, e0 - 0.03), r(o, i + 1, e1 - 0.03), r(o, i + 1, e1 - 1.5), r(o, i, e0 - 1.5), '#6b7558');
        g.quad(r(-3.6, i, e0), r(3.6, i, e0), r(3.6, i + 1, e1), r(-3.6, i + 1, e1), '#4b5260');
        for (const o of [-3.35, 3.35]) g.quad(r(o - 0.12, i, e0 + 0.01), r(o + 0.12, i, e0 + 0.01), r(o + 0.12, i + 1, e1 + 0.01), r(o - 0.12, i + 1, e1 + 0.01), '#e5e7eb');
        if (i % 2 === 0) g.quad(r(-0.1, i, e0 + 0.01), r(0.1, i, e0 + 0.01), r(0.1, i + 1, e1 + 0.01), r(-0.1, i + 1, e1 + 0.01), '#f8fafc');
      }
    }
    // routes secondaires : chaussée, bas-côtés, îlot et panneau aux embranchements, marquage au sol
    const BR = branchesOf(w), c0s = i0 * STEP, c1s = i1 * STEP;
    const BRC = { montagne: '#535a66', canyon: '#a8845c', foret: '#4f5560', campagne: '#626770', littoral: '#565d68', ville: '#4f5662' }[theme];
    for (const b of BR) {
      const d = b.dense, sg = b.side, hw = b.hw, lines = theme !== 'canyon' && theme !== 'campagne';
      const edge = (p, q, k) => { // point du bord (k = -1 / +1), dans le repère de la route principale, posé sur le terrain dessiné
        const ds = q.s - p.s, dof = q.off - p.off, L = Math.hypot(ds, dof) || 1, s2 = p.s - dof / L * hw * k, o2 = p.off + ds / L * hw * k, f = frameAt(w, s2);
        const ge = groundDrawn(theme, w, s2, o2), top = Math.max(p.y, groundDrawn(theme, w, p.s, p.off) + 0.06, ge + 0.06);
        // pied du talus : écarté du bord de 1,6 fois la hauteur du remblai (0,8 à 12 m), posé un peu sous le sol naturel
        const sp = Math.max(0.8, Math.min(12, (top - ge) * 1.6)), s3 = p.s - dof / L * (hw + sp) * k, o3 = p.off + ds / L * (hw + sp) * k, f3 = frameAt(w, s3);
        const foot = [f3.x - Math.sin(f3.h) * o3, groundDrawn(theme, w, s3, o3) - 0.3, f3.z + Math.cos(f3.h) * o3];
        return [f.x - Math.sin(f.h) * o2, top, f.z + Math.cos(f.h) * o2, ge, foot]; // jamais sous le sol ; ge = sol sous le bord
      };
      for (let j = 0; j < d.length - 1; j++) {
        const p = d[j], q = d[j + 1]; if (!(p.s >= c0s && p.s < c1s)) continue;
        const r = d[Math.min(d.length - 1, j + 2)];
        const aL = edge(p, q, -1), aR = edge(p, q, 1), bL = edge(q, r, -1), bR = edge(q, r, 1);
        g.quad(aL, aR, bR, bL, BRC);
        if (theme === 'montagne') { // lacets : mur de soutènement en pierre, qui descend toujours jusqu'au sol
          for (const [e1, e2] of [[aL, bL], [aR, bR]]) g.quad(e1, e2, [e2[0], Math.min(e2[1] - 7, e2[3] - 0.6), e2[2]], [e1[0], Math.min(e1[1] - 7, e1[3] - 0.6), e1[2]], '#8d8a80');
        } else { // ailleurs : talus en pente douce couvert d'herbe (ou de sable), du bord de la chaussée jusqu'au terrain naturel
          const TC = { canyon: '#c99a6c', littoral: '#7aa352', foret: '#46753f', ville: '#7db34c', campagne: '#8fae55' }[theme] || '#7aa352';
          for (const [e1, e2] of [[aL, bL], [aR, bR]]) { g.quad(e1, e2, e2[4], e1[4], TC); g.quad(e1, e2, [e2[0], e2[3] - 0.5, e2[2]], [e1[0], e1[3] - 0.5, e1[2]], shade(TC, 0.9)); }
        }
        if (lines) {
          const mix = (u, v, t) => [u[0] + (v[0] - u[0]) * t, u[1] + (v[1] - u[1]) * t + 0.012, u[2] + (v[2] - u[2]) * t];
          for (const t of [0.07, 0.93]) g.quad(mix(aL, aR, t - 0.025), mix(aL, aR, t + 0.025), mix(bL, bR, t + 0.025), mix(bL, bR, t - 0.025), '#e5e7eb'); // lignes de rive
          if (j % 4 < 2 && hw >= 2.5) g.quad(mix(aL, aR, 0.485), mix(aL, aR, 0.515), mix(bL, bR, 0.515), mix(bL, bR, 0.485), '#f8fafc'); // axe en tirets
        }
        // îlot de verdure entre la route principale et la route secondaire, aux deux embranchements
        const gapA = Math.abs(p.off) - hw - 4.6, gapB = Math.abs(q.off) - hw - 4.6;
        if ((j < 80 || j > d.length - 80) && gapA > 0.25 && gapB > 0.25 && gapA < 10 && gapB < 10) {
          const ia = (pp) => { const f = frameAt(w, pp.s), e = at(w, pp.s).y + 0.1, o1 = sg * 4.6, o2 = pp.off - sg * hw; return [[f.x - Math.sin(f.h) * o1, e, f.z + Math.cos(f.h) * o1], [f.x - Math.sin(f.h) * o2, Math.min(e, pp.y + 0.04), f.z + Math.cos(f.h) * o2]]; }; // l'îlot suit la route secondaire si elle descend
          const [m1, n1] = ia(p), [m2, n2] = ia(q); g.quad(m1, n1, n2, m2, '#7cb24c');
        }
      }
      // panneau de direction et flèches au sol avant l'embranchement
      if (b.sA - 30 >= c0s && b.sA - 30 < c1s) {
        const ip = Math.round((b.sA - 28) / STEP), sp = crossPoint(w, ip, sg * 5.8, w.E[ip]), m = M.chain(M.t(sp[0], sp[1], sp[2]), M.ry(-w.Hd[ip]));
        g.tube(sp, [sp[0], sp[1] + 2.6, sp[2]], 0.06, '#9ca3af', 4);
        g.box(M.chain(m, M.t(0, 2.35, 0)), 1.9, 0.55, 0.06, '#0e7490'); g.box(M.chain(m, M.t(0, 2.35, 0.035)), 1.7, 0.4, 0.02, '#f8fafc');
        const tipA = M.apply(m, [1.15, 2.35, 0.05]), tb = M.apply(m, [0.82, 2.62, 0.05]), tc = M.apply(m, [0.82, 2.08, 0.05]); g.tri(tb, tipA, tc, '#0e7490');
        for (const [ds, ang] of [[-60, 0], [-45, 0]]) { // flèches peintes sur la voie du côté de l'embranchement
          const ii = Math.round((b.sA + ds) / STEP), f = { x: w.X[ii], z: w.Z[ii], h: w.Hd[ii] }, y = w.E[ii] + 0.065, nx = -Math.sin(f.h), nz = Math.cos(f.h), hx = Math.cos(f.h), hz = Math.sin(f.h);
          const P2 = (a, o) => [f.x + hx * a + nx * (sg * 1.8 + o), y, f.z + hz * a + nz * (sg * 1.8 + o)];
          g.quad(P2(-1.6, -0.12), P2(-1.6, 0.12), P2(0.4, 0.12), P2(0.4, -0.12), '#f8fafc'); g.quad(P2(0.4, -0.12), P2(0.4, 0.12), P2(1.4, sg * 0.75 + 0.12), P2(1.4, sg * 0.75 - 0.12), '#f8fafc');
          g.tri(P2(1.2, sg * 0.35), P2(2.1, sg * 1.2), P2(1.35, sg * 1.25), '#f8fafc'); void ang;
        }
      }
      // décor le long de la route secondaire, selon le parcours
      for (let j = 6; j < d.length - 6; j += 6) {
        const p = d[j]; if (!(p.s >= c0s && p.s < c1s) || j < 40 || j > d.length - 40) continue;
        const q = d[j + 1], ds = q.s - p.s, dof = q.off - p.off, L = Math.hypot(ds, dof) || 1;
        for (const k of [-1, 1]) {
          const dist = hw + 3 + rand() * (theme === 'foret' ? 9 : 6), s2 = p.s - dof / L * dist * k, o2 = p.off + ds / L * dist * k, f = frameAt(w, s2);
          const x = f.x - Math.sin(f.h) * o2, z = f.z + Math.cos(f.h) * o2; if (BR.hit(x, z, 2) || Math.abs(o2) < 9 || Math.abs(o2) > lim(w, f.i, o2) - 10) continue;
          const y = groundDrawn(theme, w, s2, o2), r0 = rand();
          if (theme === 'foret' && r0 < 0.75) P.pine(g, x, y, z, 0.9 + rand() * 0.8, rand() < 0.5 ? '#2f5d3a' : '#24503a');
          else if (theme === 'montagne' && r0 < 0.22) P.pine(g, x, y, z, 0.9 + rand() * 0.7);
          else if (theme === 'campagne' && r0 < 0.18) P.roundTree(g, x, y, z, 0.9 + rand() * 0.5, '#5fae3a');
          else if (theme === 'campagne' && r0 < 0.35) P.bush(g, x, y, z, 0.9 + rand() * 0.7, '#5f8d45');
          else if (theme === 'ville' && r0 < 0.2) P.roundTree(g, x, y, z, 0.9 + rand() * 0.4, '#67b23f');
          else if (theme === 'canyon' && r0 < 0.12) P.cactus(g, x, y, z, 0.6 + rand() * 0.7);
          else if (theme === 'littoral' && r0 < 0.15 && o2 > 0) P.roundTree(g, x, y, z, 0.9 + rand() * 0.4, '#6cb843');
          else if (r0 > 0.85 && theme !== 'canyon') P.grass(gd, x, y, z, 1 + rand(), '#7fa646', rand);
        }
      }
    }
    // objets
    const place = (fn, off, extra = 0) => { const i = i0 + Math.floor(rand() * (i1 - i0)); if (Math.abs(off) > lim(w, i, off) - 8) return; const y = groundY(theme, w, i, off) + extra; const p = crossPoint(w, i, off, y); if (BR.hit(p[0], p[2], 3)) return; fn(p, i); }; // jamais sur une route secondaire
    const rot = i => -w.Hd[i];
    const farmSpots = []; // fermes (sons de la ferme)
    if (theme === 'littoral') {
      for (let k = 0; k < 14; k++) place(p => P.blobTree(g, p[0], p[1], p[2], 0.8 + rand() * 0.6, rand() < 0.5 ? '#5a9e3f' : '#6fb04a'), 9 + rand() * 30);
      if (promenade) {
        const cols = ['#ef4444', '#f97316', '#facc15', '#22c55e', '#0ea5e9', '#a855f7', '#ec4899'];
        for (let k = 0; k < 26; k++) place(p => P.parasol(g, p[0], p[1] - 0.15, p[2], cols[Math.floor(rand() * cols.length)]), -(31 + rand() * 13)); // sur le sable plat de la plage (au pied du talus, avant l'eau)
        for (let k = 0; k < 4; k++) place((p, i) => P.cabin(g, p[0], p[1], p[2], rot(i), ['#0e7490', '#2563eb', '#16a34a'][k % 3]), 8);
      } else for (let k = 0; k < 5; k++) place(p => P.rock(g, p[0], p[1], p[2], 1 + rand() * 2), -(9 + rand() * 12));
      for (let i = i0; i < i1; i += 3) { const p = crossPoint(w, i, 5.4, w.E[i]); if (!BR.hit(p[0], p[2], 0.5)) P.lamp(g, p[0], p[1], p[2]); }
    } else if (theme === 'montagne') {
      for (let k = 0; k < 30; k++) place(p => P.pine(g, p[0], p[1], p[2], 0.9 + rand() * 0.8), (rand() < 0.5 ? -1 : 1) * (8 + rand() * 60));
      for (let k = 0; k < 6; k++) place(p => P.rock(g, p[0], p[1], p[2], 0.6 + rand() * 1.6), (rand() < 0.5 ? -1 : 1) * (6 + rand() * 20));
      // les grandes montagnes sont dans la couche lointaine (buildFar), chargée bien avant d'être visible
    } else if (theme === 'canyon') {
      for (let k = 0; k < 10; k++) place(p => P.rock(g, p[0], p[1], p[2], 0.8 + rand() * 2.5, '#b8693f'), (rand() < 0.5 ? -1 : 1) * (8 + rand() * 14));
      if (c % 2 === 0 && desertOpen(i0 * STEP) < 0.4) for (const s of [-1, 1]) { const R = 30 + rand() * 50, H = 50 + rand() * 60; place(p => { if (!BR.hit(p[0], p[2], R + 6)) P.mesa(g, p[0], p[1] - 5, p[2], R, H); }, s * (110 + rand() * 120)); }
      for (let k = 0; k < 6; k++) place(p => P.blobTree(g, p[0], p[1], p[2], 0.5 + rand() * 0.3, '#7a8b3a'), (rand() < 0.5 ? -1 : 1) * (7 + rand() * 12));
    } else if (theme === 'foret') {
      for (let k = 0; k < 46; k++) place(p => P.pine(g, p[0], p[1], p[2], 0.9 + rand() * 0.9, rand() < 0.5 ? '#2f5d3a' : '#24503a'), 7 + rand() * 80);
      for (let k = 0; k < 8; k++) place(p => P.pine(g, p[0], p[1], p[2], 0.8 + rand() * 0.6), -(7 + rand() * 7));
      for (let k = 0; k < 6; k++) place(p => P.blobTree(g, p[0], p[1], p[2], 0.7 + rand() * 0.4, '#4f8f3a'), 7 + rand() * 25);
      // montagne au-delà du lac : couche lointaine (buildFar)
    } else if (theme === 'ville') { /* décor du vieux bourg : plus bas, après la végétation */
    } else {
      for (let k = 0; k < 9; k++) place(p => P.blobTree(g, p[0], p[1], p[2], 0.8 + rand() * 0.6), (rand() < 0.5 ? -1 : 1) * (12 + rand() * 70));
      for (let k = 0; k < 10; k++) place(p => P.hay(g, p[0], p[1], p[2], rand() * 3), (rand() < 0.5 ? -1 : 1) * (16 + rand() * 50));
      for (let i = i0; i < i1; i += 1) for (const s of [-1, 1]) { const p = crossPoint(w, i, s * 6.5, groundY(theme, w, i, s * 6.5)); if (BR.hit(p[0], p[2], 0.4)) continue; g.box(M.t(p[0], p[1] + 0.5, p[2]), 0.12, 1, 0.12, '#8b6b4a'); }
      if (rand() < 0.5) place((p, i) => { P.farm(g, p[0], p[1], p[2], rot(i)); farmSpots.push(p); }, (rand() < 0.5 ? -1 : 1) * (30 + rand() * 30));
    }
    /* --- végétation, fleurs, papillons et maisons (tous les parcours) --- */
    const FLOW = { littoral: ['#f43f5e', '#facc15', '#ffffff', '#a855f7'], montagne: ['#60a5fa', '#ffffff', '#facc15', '#c084fc'], canyon: ['#fb923c', '#facc15', '#f43f5e'], foret: ['#ffffff', '#c084fc', '#facc15'], ville: ['#f43f5e', '#facc15', '#ffffff', '#fb923c', '#a855f7'], campagne: ['#ef4444', '#facc15', '#ffffff', '#a855f7', '#60a5fa', '#fb923c'] }[theme];
    const GRASS = { littoral: '#9cb85c', montagne: '#6c9a45', canyon: '#a89a55', foret: '#4f8a3c', ville: '#6f9a45', campagne: '#7fa646' }[theme];
    const sideOK = off => !(theme === 'littoral' && off < -7) && !(theme === 'foret' && off < -14) && !(theme === 'ville' && off < -25); // ni dans la mer, ni dans le lac, ni dans le port // pas d'herbe dans la mer ni dans le lac
    const roadsideOff = () => { const sgn = rand() < 0.5 ? -1 : 1; return sgn * (5.2 + rand() * (theme === 'ville' ? 26 : 30)); };
    const nGrass = theme === 'ville' ? 150 : theme === 'canyon' ? 70 : 170;
    for (let k = 0; k < nGrass; k++) { const off = roadsideOff(); if (sideOK(off)) place(p => P.grass(gd, p[0], p[1], p[2], 0.8 + rand() * 0.8, GRASS, rand), off); }
    const nFlow = theme === 'canyon' ? 5 : theme === 'ville' ? 12 : 26;
    const flowerSpots = [];
    for (let k = 0; k < nFlow; k++) { const off = k % 2 ? roadsideOff() : (rand() < 0.5 ? -1 : 1) * (5.4 + rand() * 9); if (sideOK(off)) place(p => { P.flowers(gd, p[0], p[1], p[2], FLOW, rand, 7 + Math.floor(rand() * 8)); flowerSpots.push(p); }, off); }
    for (let k = 0; k < 10; k++) { const off = (rand() < 0.5 ? -1 : 1) * (7 + rand() * 40); if (sideOK(off)) place(p => P.bush(g, p[0], p[1], p[2], 0.6 + rand() * 0.8, theme === 'canyon' ? '#8a8f4a' : shade(GRASS, 0.8)), off); }
    if (theme === 'canyon') {
      for (let k = 0; k < 16; k++) place(p => P.cactus(g, p[0], p[1], p[2], 0.6 + rand() * 0.9), (rand() < 0.5 ? -1 : 1) * (7 + rand() * 40));
      for (let k = 0; k < 10; k++) place(p => P.barrel(g, p[0], p[1], p[2], 0.7 + rand() * 0.8), (rand() < 0.5 ? -1 : 1) * (6 + rand() * 25));
      for (let k = 0; k < 8; k++) place(p => P.pear(g, p[0], p[1], p[2], 0.8 + rand() * 0.6, rand), (rand() < 0.5 ? -1 : 1) * (6 + rand() * 30));
      // pyramides par trois (la plus grande devant), au-dessus des falaises
      if (c % 3 === 0 && desertOpen(i0 * STEP + 100) > 0.75 && lim(w, i0 + 10, (c % 6 === 0) ? 1 : -1) > 340) { const sgn = (c % 6 === 0) ? 1 : -1, ii = i0 + 10, base = crossPoint(w, ii, sgn * 170, groundY(theme, w, ii, sgn * 170) - 8), h = w.Hd[ii], fx = Math.cos(h), fz = Math.sin(h);
        [[0, 0, 70], [130, sgn * 45, 62], [235, sgn * 80, 42]].forEach(([along, out, R]) => { const nx = -Math.sin(h) * out, nz = Math.cos(h) * out; if (BR.hit(base[0] + fx * along + nx, base[2] + fz * along + nz, R + 6)) return; P.pyramid(g, base[0] + fx * along + nx, base[1], base[2] + fz * along + nz, R, -h); }); }
    }
    // papillons au-dessus des fleurs (animés au moment du dessin)
    const BCOL = ['#f97316', '#facc15', '#ffffff', '#60a5fa', '#e879f9'];
    g.birds = []; g.sounds = []; g.camels = [];
    const snd = (type, p, dy = 0) => g.sounds.push({ type, x: p[0], y: p[1] + dy, z: p[2] });
    g.butterflies = flowerSpots.filter(() => rand() < (theme === 'ville' ? 0.3 : 0.55)).map(p => ({ x: p[0], y: p[1], z: p[2], ph: rand() * 6.28, c: Math.floor(rand() * BCOL.length) }));
    // maisons
    const WALLS = ['#b5452f', '#f1efe8', '#e8d9a8', '#d6d3cc', '#c96b4b', '#f3e6d0'], ROOFS = ['#3b3f46', '#4b5058', '#8a2f22'];
    const village = (n, near, far, side) => { const sgn = side || (rand() < 0.5 ? -1 : 1); const iBase = i0 + Math.floor(rand() * Math.max(1, i1 - i0 - 8));
      for (let k = 0; k < n; k++) { const i = Math.min(i1 - 1, iBase + k * 2), off = sgn * (near + rand() * (far - near)), y = groundY(theme, w, i, off), p = crossPoint(w, i, off, y);
        const fl = rand() < 0.45 ? 2 : 1; if (BR.hit(p[0], p[2], 7)) continue; P.house(g, p[0], p[1] - 0.2, p[2], rot(i) + (sgn > 0 ? Math.PI : 0), 7 + rand() * 4, 6 + rand() * 2, fl, WALLS[Math.floor(rand() * WALLS.length)], ROOFS[Math.floor(rand() * ROOFS.length)], rand);
        if (rand() < 0.7) { const q = crossPoint(w, i, off - sgn * 5, groundY(theme, w, i, off - sgn * 5)); P.flowers(gd, q[0], q[1], q[2], FLOW, rand, 6); } } };
    if (theme === 'campagne') {
      if (rand() < 0.55) village(3 + Math.floor(rand() * 4), 13, 45);
      // poteaux électriques reliés par des câbles, comme au bord des routes de village
      let prev = null;
      for (let i = i0; i <= i1; i += 4) { const y = groundY(theme, w, i, 9.5), p = crossPoint(w, i, 9.5, y); if (BR.hit(p[0], p[2], 0.6)) { prev = null; continue; } P.pole(g, p[0], p[1], p[2]);
        const top = [[p[0], p[1] + 7.15, p[2]]]; if (prev) for (const t of top) g.tube(prev, t, 0.018, '#2b2b2b', 3, 0.018, false); prev = top[0]; }
    } else if (theme === 'littoral') { if (rand() < 0.45) village(2 + Math.floor(rand() * 3), 16, 60, 1); }
    else if (theme === 'montagne') { if (rand() < 0.3) { const off = (rand() < 0.5 ? -1 : 1) * (14 + rand() * 30); place((p, i) => P.chalet(g, p[0], p[1] - 0.3, p[2], rot(i) + (off > 0 ? Math.PI : 0), rand), off); } }
    else if (theme === 'foret') { if (rand() < 0.25) place((p, i) => P.chalet(g, p[0], p[1] - 0.3, p[2], rot(i) + Math.PI, rand), 16 + rand() * 20);
      for (let k = 0; k < 14; k++) place(p => P.pine(g, p[0], p[1], p[2], 1 + rand() * 0.8), -(250 + rand() * 140)); } // rive d'en face du lac
    else if (theme === 'canyon') { if (rand() < 0.2) { const off = (rand() < 0.5 ? -1 : 1) * (12 + rand() * 6); /* avant le pied des falaises : la maison est posée à plat */ place((p, i) => P.house(g, p[0], p[1] - 0.2, p[2], rot(i) + (off > 0 ? Math.PI : 0), 7, 6, 1, '#d9a679', '#a5573a', rand), off); } }
    else if (theme === 'ville') {
      const foot = [];
      const roadDist = (x, z, i) => { let m = Infinity; for (let j = Math.max(0, i - 90); j <= Math.min(w.n - 1, i + 90); j++) { const dx = w.X[j] - x, dz = w.Z[j] - z; m = Math.min(m, dx * dx + dz * dz); } return Math.sqrt(m); };
      const free = (x, z, r, i, minRoad) => roadDist(x, z, i) - r >= minRoad && !BR.hit(x, z, r) && foot.every(f => Math.hypot(f.x - x, f.z - z) >= f.r + r);
      const wet = (i, off) => (off < -26 && portOpen(i * STEP)) || Math.abs(off) > lim(w, i, off) - 15; // dans le bassin du port, ou trop loin à l'intérieur d'un virage
      const pick = a => a[Math.floor(rand() * a.length)];
      const WALLS = ['#f2efe6', '#ece2c9', '#d9d5c8', '#cbb68c', '#b9c3c9', '#e3c77c', '#f3ddd0', '#9c7a5e', '#c2d1b5', '#ffffff'];
      const ROOFS = ['#2f3338', '#3b3f46', '#4a4f57', '#8a2f22', '#a33b28', '#5a3d2e', '#6b2a22'];
      const FRAMES = ['#ffffff', '#ffffff', '#f4f1e8', '#2f3338', '#7a5c3e'];
      const SHUT = [null, null, null, '#2f5d8a', '#3d6b3a', '#7f1d1d', '#e5e7eb', '#5b6b7d'];
      const DOORS = ['#1f2937', '#7c2d12', '#14532d', '#1e3a8a', '#f8fafc', '#a16207', '#6b7280'];
      const TREE = ['#5fae3a', '#6cb843', '#58a238', '#67b23f', '#4f9a34'];
      const house = (i, off, sgn) => {
        const kind = pick(['gable', 'gable', 'hip', 'front', 'front', 'gable']), fl = rand() < 0.5 ? 2 : 1;
        const wd = kind === 'front' ? 6 + rand() * 3 : 8 + rand() * 6, dp = kind === 'front' ? 8 + rand() * 4 : 6.5 + rand() * 3;
        const p = crossPoint(w, i, off, 0), r = Math.hypot(wd, dp) / 2 + 1.5;
        if (wet(i, off) || !free(p[0], p[2], r, i, 9.5)) return false;
        p[1] = groundY(theme, w, i, off) - 0.15;
        const rt = rot(i) + (sgn > 0 ? Math.PI : 0) + (Math.abs(off) > 35 ? (rand() - 0.5) * 0.5 : 0);
        P.villa(g, p[0], p[1], p[2], rt, { w: wd, d: dp, fl, kind, wall: pick(WALLS), roof: pick(ROOFS), frame: pick(FRAMES), shutter: pick(SHUT), door: pick(DOORS),
          pitch: 0.32 + rand() * 0.22, wide: rand() < 0.25, porch: rand() < 0.3, dormers: kind === 'gable' && fl === 1 && rand() < 0.5 ? 1 + Math.floor(rand() * 2) : 0, chimney: rand() < 0.8 ? pick(['#7b3a2c', '#6b7280', '#8a6a55']) : null }, rand);
        foot.push({ x: p[0], z: p[2], r });
        // jardin devant : haie ou clôture blanche, boîte aux lettres, fleurs, un arbre
        const fo = off - sgn * (dp / 2 + 3.5);
        const fp = crossPoint(w, i, fo, 0);
        if (Math.abs(off) < 40 && Math.abs(fo) > 9.5 && !BR.hit(fp[0], fp[2], 4)) {
          const a = crossPoint(w, Math.max(0, i - 1), fo, 0), b = crossPoint(w, Math.min(w.n - 1, i + 1), fo, 0), yy = groundY(theme, w, i, fo);
          const k = rand(); if (k < 0.4) P.hedge(g, a, b, yy); else if (k < 0.7) P.picket(g, a, b, yy);
          if (rand() < 0.5) { const q = crossPoint(w, i, sgn * 9.4, groundY(theme, w, i, sgn * 9.4)); P.mailbox(g, q[0] + 0.0, q[1], q[2], rot(i)); }
          if (rand() < 0.7) { const q = crossPoint(w, i, off - sgn * (dp / 2 + 1.5), yy); P.flowers(gd, q[0], q[1], q[2], FLOW, rand, 8); flowerSpots.push(q); }
        }
        const to = off + sgn * (dp / 2 + 4 + rand() * 4), ti = Math.min(w.n - 1, i + (rand() < 0.5 ? 1 : -1));
        if (!wet(ti, to)) { const q = crossPoint(w, ti, to, 0); if (free(q[0], q[2], 2.2, ti, 9)) { P.roundTree(g, q[0], groundY(theme, w, ti, to), q[2], 0.9 + rand() * 0.5, pick(TREE)); foot.push({ x: q[0], z: q[2], r: 2.2 }); } }
        return true;
      };
      const row = (i, off, sgn) => {
        const len = 18 + rand() * 16, dp = 8 + rand() * 2, p = crossPoint(w, i, off, 0), r = Math.hypot(len, dp) / 2 + 0.5;
        if (Math.abs(off) > lim(w, i, off) - 20 || !free(p[0], p[2], r, i, 9.5)) return false;
        P.brickRow(g, p[0], groundY(theme, w, i, off) - 0.15, p[2], rot(i) + (sgn > 0 ? Math.PI : 0), len, dp, rand() < 0.6 ? 3 : 2, pick(['#b04a32', '#a3442f', '#bb5838', '#9a3d2b']), pick(['#2f3338', '#3b3f46', '#4a4f57']), rand);
        foot.push({ x: p[0], z: p[2], r }); return true;
      };
      // l'église, repère du bourg (un tronçon sur sept)
      if (c % 7 === 3) { const i = i0 + 10, off = 55 + rand() * 20, p = crossPoint(w, i, off, 0); if (!wet(i, off) && free(p[0], p[2], 13, i, 12)) { P.church(g, p[0], groundY(theme, w, i, off) - 0.2, p[2], rot(i) + Math.PI / 2); foot.push({ x: p[0], z: p[2], r: 13 }); snd('churchbell', [p[0], groundY(theme, w, i, off), p[2]], 16); } } // cloches dans le clocher
      for (const sgn of [-1, 1]) {
        let i = i0 + 1 + Math.floor(rand() * 3);
        while (i < i1 - 1) {
          const port = sgn < 0 && portOpen(i * STEP), r = rand();
          if (port) { if (r < 0.55) row(i, -(14 + rand() * 3), sgn); i += 4 + Math.floor(rand() * 3); continue; } // entrepôts et maisons de quai
          if (r < 0.14) row(i, sgn * (14 + rand() * 4), sgn);
          else if (r < 0.8) house(i, sgn * (rand() < 0.65 ? 14 + rand() * 16 : 40 + rand() * 150), sgn);
          i += 2 + Math.floor(rand() * 5);
        }
      }
      // arbres le long de la route (à droite, derrière la ligne électrique) et dans les pelouses ; bosquets au loin
      for (const sgn of [-1, 1]) for (let i = i0 + Math.floor(rand() * 3); i < i1; i += 2 + Math.floor(rand() * 3)) {
        if (rand() < 0.35) continue;
        const off = sgn * (sgn < 0 ? 10.5 + rand() * 2.5 : 13.5 + rand() * 3); if (wet(i, off)) continue;
        const q = crossPoint(w, i, off, 0); if (!free(q[0], q[2], 2.4, i, 9)) continue;
        P.roundTree(g, q[0], groundY(theme, w, i, off), q[2], 0.95 + rand() * 0.55, pick(TREE)); foot.push({ x: q[0], z: q[2], r: 2.4 });
      }
      for (let k = 0; k < 22; k++) { const sgn = rand() < 0.5 ? -1 : 1, off = sgn * (18 + Math.pow(rand(), 1.4) * 380), i = i0 + Math.floor(rand() * (i1 - i0)); if (wet(i, off) || (sgn < 0 && portOpen(i * STEP) && -off < 420)) continue;
        const q = crossPoint(w, i, off, 0); if (!free(q[0], q[2], 2.6, i, 10)) continue; P.roundTree(g, q[0], groundY(theme, w, i, off), q[2], 1 + rand() * 0.7, pick(TREE)); foot.push({ x: q[0], z: q[2], r: 2.6 }); }
      for (let k = 0; k < 6; k++) { const sgn = rand() < 0.5 ? -1 : 1, off = sgn * (200 + rand() * 470), i = i0 + Math.floor(rand() * (i1 - i0)); if (sgn < 0 && portOpen(i * STEP) && -off < 420) continue;
        if (wet(i, off)) continue; const c0 = crossPoint(w, i, off, 0); if (roadDist(c0[0], c0[2], i) < 150) continue; for (let j = 0; j < 4 + Math.floor(rand() * 5); j++) { const x = c0[0] + (rand() - 0.5) * 30, z = c0[2] + (rand() - 0.5) * 30; P.roundTree(g, x, groundY(theme, w, i, off) - 0.2, z, 1.2 + rand() * 0.6, pick(TREE)); } }
      // ligne électrique côté droit, comme sur la photo : un poteau tous les 40 m, trois câbles
      for (let i = Math.ceil(i0 / 4) * 4; i <= i1; i += 4) {
        const q = crossPoint(w, i, 10.5, groundY(theme, w, i, 10.5)); if (BR.hit(q[0], q[2], 0.6)) continue; const pts = P.pole2(g, q[0], q[1], q[2], rot(i)), q0c = crossPoint(w, Math.max(0, i - 4), 10.5, 0);
        if (i - 4 >= 0 && !BR.hit(q0c[0], q0c[2], 0.6)) { const q0 = crossPoint(w, i - 4, 10.5, groundY(theme, w, i - 4, 10.5)), m0 = M.chain(M.t(q0[0], q0[1] + 8.1, q0[2]), M.ry(rot(i - 4)));
          const prev = [M.apply(m0, [0, 0.15, -0.9]), M.apply(m0, [0, 0.15, 0.9]), [q0[0], q0[1] + 8.6, q0[2]]]; for (let k = 0; k < 3; k++) P.wire(g, prev[k], pts[k]); }
      }
      // port : bateaux au mouillage, mouettes, bruit de l'eau, bornes d'amarrage sur le quai
      if (portOpen(((i0 + i1) / 2) * STEP)) {
        const COL = ['#f8fafc', '#1e3a8a', '#b91c1c', '#0f766e', '#f59e0b', '#1f2937'];
        for (let k = 0; k < 4 + Math.floor(rand() * 4); k++) { const i = i0 + Math.floor(rand() * (i1 - i0)); if (!portOpen(i * STEP)) continue; const off = -(36 + rand() * 180); if (-off > Math.min(240, lim(w, i, -1) - 20)) continue; const q = crossPoint(w, i, off, w.E[i] - 2.4 + 0.05); P.boat(g, q[0], q[1], q[2], rot(i) + rand() * 6.28, pick(COL), rand() < 0.5); }
        for (let i = i0; i < i1; i += 2) if (portOpen(i * STEP)) { const q = crossPoint(w, i, -27.3, w.E[i] + 0.12); g.cyl(M.t(q[0], q[1], q[2]), 0.22, 0.18, 0.6, 6, '#2b2f36'); }
        for (const ii of [i0 + 5, i0 + 15]) if (ii < i1 && portOpen(ii * STEP)) snd('harbor', crossPoint(w, ii, -30, w.E[ii] - 2.2)); // eau calme du bassin : clapotis contre le quai
        for (let k = 0; k < 3 + Math.floor(rand() * 3); k++) { const i = i0 + Math.floor(rand() * (i1 - i0)), q = crossPoint(w, i, -(30 + rand() * 120), w.E[i]); g.birds.push({ x: q[0], y: q[1] + 6 + rand() * 12, z: q[2], r: 6 + rand() * 14, sp: (rand() < 0.5 ? -1 : 1) * (0.25 + rand() * 0.25), ph: rand() * 6.28 }); }
      }
    }
    const fs0 = flowerSpots.length;
    // Cap Horizon : champs du côté terre plus fournis (herbes hautes, fleurs sauvages, clôtures, moutons, bancs, phare)
    if (theme === 'littoral') {
      for (let k = 0; k < 420; k++) place(p => P.grass(gd, p[0], p[1], p[2], 1.1 + rand() * 1.3, rand() < 0.5 ? '#86ad5c' : rand() < 0.5 ? '#a3b85e' : '#6f9a45', rand), 6 + Math.pow(rand(), 1.5) * 150);
      // touffes d'herbes hautes regroupées (comme des prés non fauchés)
      for (let k = 0; k < 18; k++) place(p => { for (let j = 0; j < 9; j++) P.grass(gd, p[0] + (rand() - 0.5) * 3, p[1], p[2] + (rand() - 0.5) * 3, 1.8 + rand() * 1.2, rand() < 0.5 ? '#7fa648' : '#9bb75a', rand); }, 8 + rand() * 90);
      for (let k = 0; k < 14; k++) place(p => { P.flowers(gd, p[0], p[1], p[2], ['#f43f5e', '#facc15', '#ffffff', '#a855f7', '#60a5fa'], rand, 10 + Math.floor(rand() * 10)); flowerSpots.push(p); }, 10 + rand() * 110);
      for (let k = 0; k < 8; k++) place(p => P.bush(g, p[0], p[1], p[2], 0.7 + rand() * 0.9, '#5f8d45'), 12 + rand() * 120);
      // clôture le long des champs
      const fOff = 13 + (c % 3) * 2; let prevF = null;
      for (let i = i0; i <= i1; i += 1) { const y = groundY(theme, w, i, fOff), q = crossPoint(w, i, fOff, y); if (BR.hit(q[0], q[2], 0.5)) { prevF = null; continue; } if (prevF) P.fence(g, prevF, q); prevF = q; }
      if (rand() < 0.6) { const n = 3 + Math.floor(rand() * 6), base = 25 + rand() * 60; let first = true; for (let k = 0; k < n; k++) { const off = base + rand() * 25; place((p, i) => { P.sheep(g, p[0], p[1], p[2], rot(i) + rand() * 6.28); if (first) { snd('sheep', p, 0.8); first = false; } }, off); } }
      if (rand() < 0.35) place((p, i) => P.bench(g, p[0], p[1], p[2], rot(i) + Math.PI), 6.2);
      for (let k = 0; k < 3; k++) place(p => P.hay(g, p[0], p[1], p[2], rand() * 3), 30 + rand() * 90);
      if (c % 6 === 2) place(p => { P.lighthouse(g, p[0], p[1], p[2]); snd('horn', p, 18); }, -(18 + rand() * 6));
      for (const ii of [i0 + 5, i0 + 15]) if (ii < i1) { const q = crossPoint(w, ii, -34, w.seaLevel + 0.5); snd('water', q); } // ressac sur le rivage
      // oiseaux : mouettes au-dessus des champs et de la mer
      const nb = 3 + Math.floor(rand() * 4);
      for (let k = 0; k < nb; k++) { const off = rand() < 0.55 ? 12 + rand() * 80 : -(20 + rand() * 90); place(p => g.birds.push({ x: p[0], y: Math.max(p[1], w.seaLevel) + 7 + rand() * 13, z: p[2], r: 6 + rand() * 16, sp: (rand() < 0.5 ? -1 : 1) * (0.25 + rand() * 0.25), ph: rand() * 6.28 }), off); }
    }
    g.butterflies = g.butterflies.concat(flowerSpots.slice(fs0).filter(() => rand() < 0.4).map(p => ({ x: p[0], y: p[1], z: p[2], ph: rand() * 6.28, c: Math.floor(rand() * BCOL.length) })));

    /* --- sources sonores placées dans le décor (son spatial) --- */
    flowerSpots.filter(() => rand() < 0.12).slice(0, 2).forEach(p => snd('bees', p, 0.4)); // abeilles sur les fleurs
    const birdTree = n => { for (let k = 0; k < n; k++) place(p => snd('songbird', p, 4 + rand() * 3), (rand() < 0.5 ? -1 : 1) * (8 + rand() * 50)); };
    if (theme === 'foret') { for (const ii of [i0 + 4, i0 + 14]) if (ii < i1) snd('lake', crossPoint(w, ii, -18, w.E[ii] - 2)); birdTree(3); } // lac : clapotis (et non ressac de mer)
    else if (theme === 'campagne') { birdTree(3); for (let k = 0; k < 2; k++) place(p => snd('crickets', p, 0.2), (rand() < 0.5 ? -1 : 1) * (18 + rand() * 50)); }
    else if (theme === 'montagne') { birdTree(2); if (rand() < 0.45) place(p => snd('bell', p, 1), (rand() < 0.5 ? -1 : 1) * (25 + rand() * 60)); if (rand() < 0.3) place(() => {}, (rand() < 0.5 ? -1 : 1) * (9 + rand() * 6)); /* ancien ruisseau sans eau visible : remplacé par les cascades plus bas */ }
    else if (theme === 'canyon') {
      if (rand() < 0.4) place(p => snd('hawk', p, 35), (rand() < 0.5 ? -1 : 1) * (40 + rand() * 80));
      // caravane de chameaux qui marche le long de la route (animée au dessin), avec son grognement
      if (rand() < 0.6) { const off = (rand() < 0.5 ? -1 : 1) * (12 + rand() * 14), i = i0 + 4 + Math.floor(rand() * Math.max(1, i1 - i0 - 8)), n = 2 + Math.floor(rand() * 3), ph = rand() * 6.28;
        for (let k = 0; k < n; k++) g.camels.push({ s0: i * STEP - k * 4.2, off: off + (rand() - 0.5) * 1.2, ph, amp: 25, sz: 0.9 + rand() * 0.2 });
        const q = crossPoint(w, i, off, groundY(theme, w, i, off)); g.sounds.push({ type: 'camel', x: q[0], y: q[1] + 2, z: q[2] }); }
      if (rand() < 0.35) { const off = (rand() < 0.5 ? -1 : 1) * (20 + rand() * 30), i = i0 + Math.floor(rand() * (i1 - i0)); g.camels.push({ s0: i * STEP, off, ph: 0, amp: 0, sz: 1, still: true, rot: rand() * 6.28 }); }
    }
    else if (theme === 'ville') birdTree(3);
    else if (theme === 'littoral') birdTree(1);

    // arbres plus loin, pour que le paysage s'étende jusqu'à l'horizon
    if (theme === 'campagne' || theme === 'littoral') for (let k = 0; k < 10; k++) { const off = theme === 'littoral' ? 80 + rand() * 300 : (rand() < 0.5 ? -1 : 1) * (90 + rand() * 300); place(p => P.blobTree(g, p[0], p[1], p[2], 1 + rand() * 0.7, rand() < 0.5 ? '#5a9e3f' : '#4f8f3a'), off); }
    if (theme === 'montagne') for (let k = 0; k < 12; k++) place(p => P.pine(g, p[0], p[1], p[2], 1.2 + rand()), (rand() < 0.5 ? -1 : 1) * (80 + rand() * 280));
    // profondeur : bosquets au milieu du paysage et jusqu'au bord du terrain (comme sur la photo de référence)
    const clump = (n, off, mk) => place((p, i) => { for (let j = 0; j < n; j++) { const x = p[0] + (rand() - 0.5) * 26, z = p[2] + (rand() - 0.5) * 26, q = terrainAt(w, x, z, i); if (Math.abs(q.off) < 9 || Math.abs(q.off) > lim(w, q.i, q.off) - 8 || BR.hit(x, z, 2.5)) continue; mk(x, q.y - 0.2, z); } }, off); // chaque arbre posé sur le sol réel
    const LEAF = ['#5fae3a', '#6cb843', '#58a238', '#4f9a34'];
    if (theme === 'campagne') {
      for (let k = 0; k < 4; k++) clump(3 + Math.floor(rand() * 5), (rand() < 0.5 ? -1 : 1) * (45 + rand() * 600), (x, y, z) => P.roundTree(g, x, y, z, 0.9 + rand() * 0.6, LEAF[Math.floor(rand() * 4)]));
      for (let k = 0; k < 6; k++) place(p => P.roundTree(g, p[0], p[1] - 0.2, p[2], 0.9 + rand() * 0.5, LEAF[Math.floor(rand() * 4)]), (rand() < 0.5 ? -1 : 1) * (20 + rand() * 200));
      for (let k = 0; k < 6; k++) place(p => P.bush(g, p[0], p[1], p[2], 0.9 + rand() * 1.2, '#5f8d45'), (rand() < 0.5 ? -1 : 1) * (12 + rand() * 120));
      if (rand() < 0.3) place((p, i) => { farmSpots.push(p); P.farm(g, p[0], p[1], p[2], rot(i) + rand() * 0.6); P.roundTree(g, p[0] + 9, p[1] - 0.2, p[2] + 6, 1.2, LEAF[0]); }, (rand() < 0.5 ? -1 : 1) * (150 + rand() * 350)); // fermes éloignées
    }
    if (theme === 'littoral') {
      for (let k = 0; k < 3; k++) clump(3 + Math.floor(rand() * 4), 60 + rand() * 580, (x, y, z) => P.roundTree(g, x, y, z, 0.9 + rand() * 0.6, LEAF[Math.floor(rand() * 4)]));
      if (rand() < 0.25) place((p, i) => P.house(g, p[0], p[1] - 0.2, p[2], rot(i) + Math.PI + rand() * 0.5, 7 + rand() * 3, 6 + rand() * 2, rand() < 0.5 ? 2 : 1, ['#f1efe8', '#e8d9a8', '#d6d3cc'][Math.floor(rand() * 3)], ['#3b3f46', '#8a2f22'][Math.floor(rand() * 2)], rand), 120 + rand() * 400);
    }
    if (theme === 'montagne') for (let k = 0; k < 3; k++) clump(5 + Math.floor(rand() * 6), (rand() < 0.5 ? -1 : 1) * (60 + rand() * 450), (x, y, z) => P.pine(g, x, y, z, 1 + rand() * 0.9, rand() < 0.5 ? '#2f5d3a' : '#24503a'));
    if (theme === 'foret') for (let k = 0; k < 3; k++) clump(6 + Math.floor(rand() * 6), 100 + rand() * 560, (x, y, z) => P.pine(g, x, y, z, 1 + rand() * 0.8, rand() < 0.5 ? '#2f5d3a' : '#24503a'));
    if (theme === 'canyon') for (let k = 0; k < 4; k++) clump(2 + Math.floor(rand() * 4), (rand() < 0.5 ? -1 : 1) * (40 + rand() * 500), (x, y, z) => P.rock(g, x, y, z, 1.5 + rand() * 4, rand() < 0.5 ? '#b8693f' : '#c47a4a'));

    /* --- Ambiance sonore des décors (tous les parcours sauf Cap Horizon, laissé tel quel) ---
       Les sons ne sont placés que là où le décor les justifie : cascades visibles en montagne, oasis visibles dans le désert,
       marmottes dans les alpages, pics dans la forêt, vaches et coqs près des fermes. Tirages avec un générateur à part :
       le reste du décor de chaque parcours ne change pas. */
    if (theme !== 'littoral') {
      const rs = rng(route.seed * 4243 + c * 29), pk = () => i0 + 3 + Math.floor(rs() * Math.max(1, i1 - i0 - 6));
      const wp = (s, off, y) => { const f = frameAt(w, s); return [f.x - Math.sin(f.h) * off, y, f.z + Math.cos(f.h) * off]; };
      const gy = (s, off) => groundDrawn(theme, w, s, off);
      const okAt = (i, off, r) => { if (Math.abs(off) + r > lim(w, i, off) - 8) return false; const q = crossPoint(w, i, off, 0); return !BR.hit(q[0], q[2], r); };
      if (theme === 'montagne') {
        const hRel = i => { if (!w._eR) { let a = Infinity, b = -Infinity; for (const e of w.E) { a = Math.min(a, e); b = Math.max(b, e); } w._eR = [a, b - a || 1]; } return (w.E[i] - w._eR[0]) / w._eR[1]; }; // 0 = fond de vallée, 1 = col
        // cascade : une falaise de rocher côté montagne, une chute d'eau, l'écume, puis un petit torrent qui descend jusqu'à la route
        if (rs() < 0.14) { const i = pk(), sm = i * STEP, o = 20 + rs() * 14, H = 7 + rs() * 4;
          if (hRel(i) < 0.85 && okAt(i, o + 8, 9) && okAt(i, o + 22, 9) && okAt(i, (o + 7) / 2, 3)) {
            // avancée rocheuse qui sort de la pente : face verticale vers la route, dessus qui rejoint le versant derrière
            const fr = o + 4.5, sa = sm - 5, sb = sm + 5, yb = gy(sm, fr), rise = gy(sm, fr + 14) - yb, RC = '#7f8183', MOSS = '#6f7d5e';
            if (rise >= 3.5) { // une chute d'eau n'a de sens que là où le versant monte franchement
            const top = yb + Math.min(H, rise + 2.5);
            let bk = fr + 4; while (bk < fr + 40 && gy(sm, bk) < top - 0.5) bk += 2; // là où le versant rejoint le haut du rocher
            const bot = Math.min(gy(sa, fr), gy(sb, fr), yb) - 2, P4 = (a, b, cc, d, k) => g.quad(a, b, cc, d, k);
            const xs = [sa, sm - 1.6, sm + 1.6, sb], fo = [fr + 0.9, fr, fr, fr + 0.7], tp = [top - 1.2, top, top, top - 0.9]; // face avant en trois pans, bords plus bas
            for (let k = 0; k < 3; k++) P4(wp(xs[k], fo[k], bot), wp(xs[k + 1], fo[k + 1], bot), wp(xs[k + 1], fo[k + 1], tp[k + 1]), wp(xs[k], fo[k], tp[k]), k === 1 ? RC : shade(RC, 0.9));
            for (let k = 0; k < 3; k++) P4(wp(xs[k], fo[k], tp[k]), wp(xs[k + 1], fo[k + 1], tp[k + 1]), wp(xs[k + 1], bk, gy(xs[k + 1], bk) - 0.4), wp(xs[k], bk, gy(xs[k], bk) - 0.4), MOSS); // dessus moussu, vers le versant
            for (const [x, f0, t0] of [[sa, fo[0], tp[0]], [sb, fo[3], tp[3]]]) { P4(wp(x, f0, bot), wp(x, f0, t0), wp(x, bk, gy(x, bk) - 0.4), wp(x, bk, bot), shade(RC, 0.8)); } // flancs
            // chute d'eau (deux nappes), écume, rochers au pied
            P4(wp(sm - 1.2, fr - 0.15, yb + 0.1), wp(sm + 1.2, fr - 0.15, yb + 0.1), wp(sm + 1.0, fr - 0.15, top - 0.05), wp(sm - 1.0, fr - 0.15, top - 0.05), '#d8eef7');
            P4(wp(sm - 0.5, fr - 0.25, yb + 0.1), wp(sm + 0.5, fr - 0.25, yb + 0.1), wp(sm + 0.4, fr - 0.25, top - 0.3), wp(sm - 0.4, fr - 0.25, top - 0.3), '#a9d8ec');
            for (let k = 0; k < 4; k++) { const q = wp(sm + (rs() - 0.5) * 2.6, fr - 0.9 - rs() * 0.8, yb); g.sphere(M.t(q[0], q[1] + 0.2, q[2]), 0.55 + rs() * 0.45, '#f4fbff', 3, 6); }
            for (const x of [sa - 1, sb + 1]) { const q = wp(x, fr - 0.5, 0); P.rock(g, q[0], gy(x, fr - 0.5) - 0.6, q[2], 1.8 + rs() * 1.2); }
            for (let k = 0; k < 2; k++) { const q = wp(sm + (rs() < 0.5 ? -1 : 1) * (2 + rs() * 1.5), fr - 1.6 - rs(), 0); P.rock(g, q[0], gy(sm, fr - 2) - 0.3, q[2], 0.7 + rs() * 0.6); }
            for (let k = 0; k < 3; k++) { const x = sm + (rs() - 0.5) * 9, a = bk + 2 + rs() * 8, q = wp(x, a, 0); P.pine(g, q[0], gy(x, a) - 0.2, q[2], 0.9 + rs() * 0.5); }
            // torrent : ruban continu posé sur la pente, du pied de la chute jusqu'au fossé de la route
            const rib = []; for (let a = fr - 1; a > 7; a -= 2) rib.push(a); rib.push(7);
            for (let k = 0; k < rib.length - 1; k++) { const a = rib[k], b2 = rib[k + 1], wa = Math.sin(a * 0.45) * 0.8, wb = Math.sin(b2 * 0.45) * 0.8;
              P4(wp(sm - 0.6 + wa, a, gy(sm + wa, a) + 0.08), wp(sm + 0.6 + wa, a, gy(sm + wa, a) + 0.08), wp(sm + 0.6 + wb, b2, gy(sm + wb, b2) + 0.08), wp(sm - 0.6 + wb, b2, gy(sm + wb, b2) + 0.08), '#7fc3e0'); }
            snd('cascade', wp(sm, fr - 1, yb), 1.5);
          } } }
        // marmottes dans les alpages, sous les névés
        if (rs() < 0.35) { const i = pk(), o = (rs() < 0.5 ? -1 : 1) * (25 + rs() * 45); if (hRel(i) > 0.5 && okAt(i, o, 2)) snd('marmot', crossPoint(w, i, o, gy(i * STEP, o)), 0.3); }
        // rapace qui tourne au-dessus des crêtes
        if (rs() < 0.22) { const i = pk(), o = (rs() < 0.5 ? -1 : 1) * (40 + rs() * 80); if (hRel(i) > 0.35) snd('hawk', crossPoint(w, i, o, gy(i * STEP, o)), 45); }
      } else if (theme === 'canyon') {
        // oasis : bassin d'eau entouré de palmiers, seulement là où le désert s'ouvre et où le sol est plat
        if (desertOpen((i0 + i1) / 2 * STEP) > 0.7 && rs() < 0.4) {
          // l'oasis se niche dans le creux le plus plat parmi six emplacements ; le sable plus haut autour forme sa berge
          let best = null;
          for (let t = 0; t < 6; t++) { const sg = rs() < 0.5 ? -1 : 1, i = i0 + 6 + Math.floor(rs() * 8), sm = i * STEP, o = sg * (58 + rs() * 35);
            if (i >= i1 || !okAt(i, o, 18)) continue;
            const pts = []; for (const ds of [-11, 0, 11]) for (const dof of [-11, 0, 11]) pts.push(gy(sm + ds, o + dof));
            const lo = Math.min(...pts), d = Math.max(...pts) - lo; if (!best || d < best.d) best = { i, sm, o, lo, d }; }
          if (best && best.d < 2.8) { const { sm, o, lo } = best;
            // niveau de l'eau : au ras du point le plus haut du bassin ; une berge de sable en pente douce l'entoure (rayon 9,5 → 17 m)
            let wl = -Infinity; for (const ds of [-6, 0, 6]) for (const dof of [-6, 0, 6]) wl = Math.max(wl, gy(sm + ds, o + dof)); wl += 0.15;
            const C = wp(sm, o, wl), base = lo - 1.5, bermAt = r => r <= 9.5 ? wl : wl - (r - 9.5) / 7.5 * (wl - base);
            g.cyl(M.t(C[0], base, C[2]), 17, 9.5, wl - 0.04 - base, 18, '#d9a874');   // berge de sable
            g.cyl(M.t(C[0], wl - 0.6, C[2]), 9.4, 8.6, 0.57, 18, '#b88d5a');           // sable mouillé au bord de l'eau
            g.cyl(M.t(C[0], wl - 0.5, C[2]), 7.6, 7.6, 0.5, 18, '#3aa0b8');           // eau
            for (let k = 0; k < 6; k++) { const a = k / 6 * 6.28 + rs() * 0.6, r = 10 + rs() * 3, s2 = sm + Math.cos(a) * r, o2 = o + Math.sin(a) * r, q = wp(s2, o2, 0); P.palm(g, q[0], Math.max(gy(s2, o2), bermAt(r)), q[2], 0.85 + rs() * 0.35, rs() * 6.28); }
            for (let k = 0; k < 5; k++) { const a = rs() * 6.28, r = 9 + rs() * 2, s2 = sm + Math.cos(a) * r, o2 = o + Math.sin(a) * r, q = wp(s2, o2, 0); P.bush(g, q[0], Math.max(gy(s2, o2), bermAt(r)) - 0.1, q[2], 0.8 + rs() * 0.6, '#5f8d45'); }
            snd('oasis', C, 0.4); snd('songbird', wp(sm + 10, o + 3, wl), 7); // grenouilles dans l'eau, oiseaux dans les palmes
          }
        }
      } else if (theme === 'foret') {
        if (rs() < 0.35) { const i = pk(), o = 15 + rs() * 50; if (okAt(i, o, 2)) snd('woodpecker', crossPoint(w, i, o, gy(i * STEP, o)), 5); } // pic sur un tronc
      } else if (theme === 'campagne') {
        farmSpots.forEach(p => { snd('cow', [p[0] + 9, p[1], p[2] + 5], 1); if (rs() < 0.35) snd('rooster', p, 2); }); // pré des vaches et basse-cour
      }
    }
    /* --- parcours de sprint : bocage (haies, allées de peupliers), panneaux de virage, barrières au départ et à l'arrivée --- */
    if (route.sprint) {
      const nearTurn = s0 => w.plan.some(p => p.kind === 'virage' && s0 > p.s0 - 70 && s0 < p.s1 + 70);
      for (const p of w.plan) if (p.kind === 'virage') { // chevrons à l'extérieur du virage, face au cycliste
        const dir = Math.sign(p.h1 - p.h0), outSide = -dir;
        for (const sAt of [p.s0 + 4, (p.s0 + p.s1) / 2]) { const i = Math.round(sAt / STEP); if (i < i0 || i >= i1) continue; const o = outSide * 7.4, q = crossPoint(w, i, o, groundY(theme, w, i, o)); if (!BR.hit(q[0], q[2], 1)) P.chevron(g, q[0], q[1], q[2], -w.Hd[i], dir); }
      }
      for (const [sa, sb] of [[0, 240], [w.length - 260, w.length]]) for (const sd of [-1, 1]) { // barrières de course
        for (let sx = Math.max(sa, i0 * STEP); sx < Math.min(sb, i1 * STEP); sx += 2.5) { const i = Math.floor(sx / STEP), t = sx / STEP - i, a = crossPoint(w, i, sd * 5.1, 0), b = crossPoint(w, Math.min(w.n - 1, i + 1), sd * 5.1, 0);
          const A = [a[0] + (b[0] - a[0]) * t, 0, a[2] + (b[2] - a[2]) * t], f2 = Math.min(1, t + 0.25), B2 = [a[0] + (b[0] - a[0]) * f2, 0, a[2] + (b[2] - a[2]) * f2]; P.barrier(g, A, B2, w.E[i] + 0.05); }
      }
      if (theme === 'campagne') {
        const leg = w.plan.findIndex(p => p.kind === 'droite' && i0 * STEP < p.s1 && i1 * STEP > p.s0), alley = leg >= 0 && leg % 3 === 2;
        for (const sd of [-1, 1]) { // haies le long des prés, interrompues aux entrées de champ
          const ho = sd * (14.5 + (c % 2) * 2);
          for (let i = i0; i < i1; i++) { if (nearTurn(i * STEP) || (i + c * 3) % 9 === 0) continue; if (Math.abs(ho) > lim(w, i, ho) - 4) continue; const a = crossPoint(w, i, ho, 0), b = crossPoint(w, i + 1, ho, 0); if (BR.hit(a[0], a[2], 2) || BR.hit(b[0], b[2], 2)) continue; P.hedge(g, a, b, Math.min(groundY(theme, w, i, ho), groundY(theme, w, i + 1, ho)) - 0.05, (i % 4) ? '#4f8a36' : '#5a9640'); }
        }
        if (alley) for (const sd of [-1, 1]) for (let i = i0; i < i1; i += 2) { if (nearTurn(i * STEP)) continue; const o = sd * 9.2, q = crossPoint(w, i, o, groundY(theme, w, i, o)); if (!BR.hit(q[0], q[2], 2)) P.poplar(g, q[0], q[1], q[2], 0.95 + ((i * 7) % 5) * 0.06); }
      }
    }
    // panneaux kilométriques, départ et arrivée
    for (let i = i0; i < i1; i++) if (i > 0 && (i * STEP) % 1000 === 0) { const p = crossPoint(w, i, 5.2, w.E[i]); if (!BR.hit(p[0], p[2], 0.5)) P.sign(g, p[0], p[1], p[2], -w.Hd[i], i * STEP / 1000); }
    if (i0 === 0) P.arch(g, w, 3, 'depart');
    if (i1 >= w.n - 1) P.arch(g, w, w.n - 3, 'fin');
    return g;
  }

  // Chameau de Bactriane (deux bosses) : corps, bosses et toison sombres, long cou, tête ; une patte à part (animée).
  function camelMeshes(r) {
    const g = new Geo(), B = '#a08a6e', Fur = '#5e4630', Dk = '#4a3626';
    g.sphere(M.chain(M.t(0, 1.75, 0), M.s(1.55, 0.72, 0.62)), 0.75, B, 4, 9, (i, j) => (i + j) % 3 ? B : shade(B, 0.94));
    for (const hx of [-0.42, 0.42]) g.sphere(M.chain(M.t(hx, 2.38, 0), M.s(0.95, 1.35, 0.85)), 0.36, Fur, 3, 7, (i, j) => (i + j) % 2 ? Fur : shade(Fur, 1.1));
    g.sphere(M.chain(M.t(0.85, 1.5, 0), M.s(0.8, 1.15, 0.95)), 0.36, Dk, 3, 7);   // toison du poitrail
    g.tube([0.95, 1.95, 0], [1.5, 1.55, 0], 0.21, Fur, 7, 0.17);                   // cou (part basse, laineuse)
    g.tube([1.5, 1.55, 0], [1.78, 2.45, 0], 0.15, B, 7, 0.12);                     // cou (part haute)
    g.box(M.chain(M.t(1.98, 2.48, 0), M.rz(-0.25)), 0.52, 0.27, 0.25, B, shade(B, 1.05)); // tête
    g.box(M.chain(M.t(2.22, 2.4, 0), M.rz(-0.25)), 0.12, 0.17, 0.2, shade(B, 0.85)); // museau
    for (const ez of [-0.11, 0.11]) { g.box(M.t(1.86, 2.66, ez), 0.06, 0.12, 0.05, B); g.box(M.t(2.05, 2.55, ez * 1.15), 0.05, 0.05, 0.02, '#1f1a15'); }
    g.tube([-1.08, 1.85, 0], [-1.18, 1.15, 0], 0.04, Dk, 4, 0.03); g.sphere(M.t(-1.18, 1.1, 0), 0.07, Dk, 2, 4); // queue
    const leg = new Geo();
    leg.tube([0, 0, 0], [0, -0.8, 0], 0.12, B, 6, 0.09); leg.tube([0, -0.8, 0], [0.02, -1.52, 0], 0.075, shade(B, 0.85), 6, 0.065); leg.box(M.t(0.05, -1.57, 0), 0.22, 0.08, 0.16, Dk);
    return { body: r.mesh(g), leg: r.mesh(leg) };
  }
  /* ---------- Vautours (Valley Loop) ----------
     Modèle low-poly : corps brun sombre, collerette et tête claires, queue en éventail, grandes ailes larges
     aux rémiges écartées (« doigts »). Une aile par côté, articulée à l'épaule pour battre ou planer. */
  function vultureMeshes(r) {
    const body = new Geo(), Br = '#3b2f26', Pale = '#e7dccb';
    body.sphere(M.chain(M.t(0, 0, 0), M.s(0.55, 0.19, 0.21)), 1, Br, 3, 8, (i, j) => (i + j) % 2 ? Br : shade(Br, 1.12));
    body.sphere(M.chain(M.t(0.36, 0.03, 0), M.s(1, 0.8, 1)), 0.11, Pale, 2, 6);            // collerette
    body.tube([0.4, 0.03, 0], [0.6, 0.01, 0], 0.045, '#d9c7ad', 5, 0.035);               // cou
    body.sphere(M.t(0.63, 0.01, 0), 0.06, '#cbb59a', 2, 6);                                // tête
    body.box(M.chain(M.t(0.7, -0.005, 0), M.rz(-0.3)), 0.07, 0.03, 0.03, '#e2c9a0');     // bec
    body.quad([-0.4, 0, -0.1], [-0.4, 0, 0.1], [-0.78, 0, 0.17], [-0.78, 0, -0.17], '#2a211b'); // queue
    const wing = side => { const g = new Geo(), T = (a, b, c, k) => side > 0 ? g.tri(a, b, c, k) : g.tri([a[0], a[1], -a[2]], [c[0], c[1], -c[2]], [b[0], b[1], -b[2]], k);
      const cov = '#5a4637', fl = '#231c17';
      T([0.14, 0, 0.1], [-0.24, 0, 0.1], [0.1, 0, 0.62], cov); T([-0.24, 0, 0.1], [-0.3, 0, 0.6], [0.1, 0, 0.62], cov);       // couvertures
      T([0.1, 0, 0.62], [-0.3, 0, 0.6], [0.08, 0, 1.08], fl); T([-0.3, 0, 0.6], [-0.3, 0, 1.0], [0.08, 0, 1.08], fl);          // rémiges
      for (let k = 0; k < 5; k++) { const x0 = 0.06 - k * 0.085, x1 = x0 - 0.07; T([x0, 0, 1.0 + (k === 0 ? 0.06 : 0)], [x1, 0, 1.0], [x0 - 0.05 + k * 0.012, 0, 1.36 - Math.abs(k - 1.5) * 0.04], fl); } // « doigts »
      return r.mesh(g); };
    return { body: r.mesh(body), right: wing(1), left: wing(-1) };
  }
  // Hauteur du terrain sous un point du monde (recherche de la portion de route la plus proche, puis décalage latéral).
  function terrainAt(w, x, z, iHint) {
    let best = iHint, d = Infinity;
    for (let i = Math.max(0, iHint - 60); i <= Math.min(w.n - 1, iHint + 60); i += 2) { const dx = w.X[i] - x, dz = w.Z[i] - z, q = dx * dx + dz * dz; if (q < d) { d = q; best = i; } }
    const h = w.Hd[best], off = (x - w.X[best]) * -Math.sin(h) + (z - w.Z[best]) * Math.cos(h);
    return { i: best, off, y: groundY(w.route.theme, w, best, Math.max(-700, Math.min(700, off))) };
  }
  // Marge au-dessus du sol pour les grands reliefs posés sur le décor : mesas (sommet ≤ 105 m au-dessus de leur sol, posées
  // seulement là où le désert est fermé) et pyramides (≤ 63 m, au cœur du désert). Fenêtre de ±350 m pour couvrir
  // le rayon des mesas et leur position dans leur tronçon ; en cas de doute on garde la marge la plus prudente.
  const obstacleAllowance = (s, off) => {
    if (Math.abs(off) < 25) return 0;
    for (let d = -350; d <= 350; d += 25) if (desertOpen(s + d) < 0.4) return 125;
    return 80;
  };
  const VULTURES = 16, V_FAR = 1950; // nombre de vautours ; distance (m) au-delà de laquelle ils sont entièrement dans le brouillard

  // Position d'un oiseau qui tourne en cercle (partagée par l'affichage et le son).
  function birdPos(b, t) { const a = t * b.sp + b.ph; return { a, x: b.x + Math.cos(a) * b.r, z: b.z + Math.sin(a) * b.r, y: b.y + Math.sin(t * 0.4 + b.ph) * 2 }; }

  // Couche lointaine : les grandes montagnes (Col des Lumières, Lac des Sapins), par blocs de 2 km.
  // Même placement et mêmes dimensions qu'avant (une par côté tous les 400 m en montagne, une tous les 600 m en forêt),
  // mais chargées très loin devant et gardées longtemps derrière : elles ne surgissent plus et ne disparaissent plus à vue.
  const FAR = 2000;
  // Cap Horizon : la terre ferme continue, côté terre, jusqu'à 3 km de la côte (et 3 km avant le départ / après l'arrivée).
  // Les autres parcours ont une plaine de fond sous le terrain ; ici, sous la terre, il n'y a que la mer : partout où la bande
  // de terrain s'arrête (à 700 m, ou plus tôt à l'intérieur d'un virage), on voyait la mer « à travers » la terre.
  // La route avance toujours vers +x avec la terre du côté +z : une grille posée en (x, z) ne se replie donc jamais.
  // Sa hauteur suit le vrai relief (terrainAt) : 4 m sous le terrain détaillé là où il existe (invisible), puis elle prend le
  // relais à son bord sans marche et monte doucement en collines vers l'intérieur des terres.
  function landApronY(w, x, z, ii, BR, hz = 30) {
    const q = terrainAt(w, x, z, ii);
    if (q.off < 12) return null; // route, plage et mer : rien
    const L = Math.min(700, lim(w, q.i, 1)), out = Math.max(0, q.off - L);
    // sous le terrain détaillé : le point le plus bas des alentours (la grille est plus grossière que le relief qu'elle double)
    let base = q.y;
    if (q.off < L + 60) for (const [dx, dz] of [[-24, 0], [24, 0], [0, -hz], [0, hz], [-24, -hz], [24, hz], [-24, hz], [24, -hz]]) { const p = terrainAt(w, x + dx, z + dz, ii); if (p.off >= 5) base = Math.min(base, p.y); }
    const sink = BR.hit(x, z, 45) ? 20 : q.off < L ? 2.5 : Math.max(0.4, 2.5 - out * 0.01), k = Math.min(1, out / 400); // les collines naissent en douceur après le bord
    return base - sink + out * 0.05 * k + noise(x * 0.5, z * 0.5) * 18 * k * k;
  }
  function landApron(w, f, g) {
    const BR = branchesOf(w), n = w.n, s0 = f * FAR, s1 = Math.min(w.length, s0 + FAR);
    const iOfX = x => { let lo = 0, hi = n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (w.X[m] < x) lo = m; else hi = m; } return lo; };
    const zRoute = x => { if (x <= w.X[0]) return w.Z[0] + (x - w.X[0]) * Math.tan(w.Hd[0]); if (x >= w.X[n - 1]) return w.Z[n - 1] + (x - w.X[n - 1]) * Math.tan(w.Hd[n - 1]);
      const i = iOfX(x), t = (x - w.X[i]) / Math.max(1e-6, w.X[i + 1] - w.X[i]); return w.Z[i] + (w.Z[i + 1] - w.Z[i]) * t; };
    const i0 = Math.min(n - 1, Math.round(s0 / STEP)), i1 = Math.min(n - 1, Math.round(s1 / STEP));
    const xa = f === 0 ? w.X[0] - 3000 : w.X[i0], xb = s1 >= w.length ? w.X[n - 1] + 3000 : w.X[i1];
    const DZ = [10, 30, 60, 100, 150, 220, 300, 400, 520, 650, 800, 980, 1200, 1500, 1900, 2400, 3000];
    const nx = Math.max(1, Math.ceil((xb - xa) / 40)), V = [];
    for (let c = 0; c <= nx; c++) { const x = xa + (xb - xa) * c / nx, ii = Math.max(0, Math.min(n - 1, iOfX(x))), zr = zRoute(x);
      const row = DZ.map((dz, r) => { const z = zr + dz, y = landApronY(w, x, z, ii, BR, 0.6 * Math.max(dz - (DZ[r - 1] ?? dz - 20), (DZ[r + 1] ?? dz + 20) - dz)); return y === null ? null : [x, y, z]; });
      // côté mer : la terre plonge sous l'eau (au-delà du départ et de l'arrivée, la côte continue sans arête suspendue)
      row.unshift([x, w.seaLevel - 3, zr - 40]);
      V.push(row); }
    for (let c = 0; c < nx; c++) for (let r = 0; r < DZ.length; r++) {
      const first = col => col.find((v, k) => k > 0 && v); // premier point de terre de la colonne
      const a = V[c][r], b = V[c + 1][r], cc = r === 0 ? first(V[c + 1]) : V[c + 1][r + 1], d = r === 0 ? first(V[c]) : V[c][r + 1];
      if (!(a && b && cc && d)) continue;
      g.quad(a, d, cc, b, r === 0 ? '#d9c79a' : '#6f9a52');
    }
  }
  function buildFar(w, f) {
    const theme = w.route.theme, g = new Geo(), rand = rng(w.route.seed * 7777 + f * 31);
    const s0 = f * FAR, s1 = Math.min(w.length, s0 + FAR);
    const at = (s, off, dy) => { const i = Math.min(w.n - 1, Math.max(0, Math.round(s / STEP))); return crossPoint(w, i, off, groundY(theme, w, i, off) + dy); };
    const brPts = branchesOf(w).flatMap(b => b.dense.filter((_, j) => j % 10 === 0));
    const nearRoute = (x, z) => { let m = Infinity; for (let j = 0; j < w.n; j += 3) m = Math.min(m, Math.hypot(w.X[j] - x, w.Z[j] - z)); for (const p of brPts) m = Math.min(m, Math.hypot(p.x - x, p.z - z)); return m; }; // route principale et routes secondaires
    // Collines enfoncées dans le sol au-delà du bord du terrain (700 m) : elles ferment l'horizon, seul leur sommet dépasse
    // (on ne voit jamais leur dessous), et elles ne s'approchent jamais de la route, même à l'intérieur d'un virage.
    const ring = ({ sides = [-1, 1], step = 300, cols, trees, treeN = 7, minR = 260, maxR = 500, minH = 55, maxH = 125 }) => {
      for (let s = s0; s < s1; s += step) for (const sd of sides) {
        const off = sd * (760 + rand() * 420), i = Math.min(w.n - 1, Math.max(0, Math.round((s + rand() * 150) / STEP))), base = groundY(theme, w, i, sd * Math.min(700, lim(w, i, sd))), p = crossPoint(w, i, off, base - 30);
        const r = minR + rand() * (maxR - minR), hh = minH + rand() * (maxH - minH), c = cols[Math.floor(rand() * cols.length)];
        if (nearRoute(p[0], p[2]) < r + 420) continue;
        const vr = hh * 2.2, cy = p[1] + 30 - hh * 1.2;
        g.sphere(M.chain(M.t(p[0], cy, p[2]), M.s(1, vr / r, 1)), r, c, 6, 10, (a, b) => (a + b) % 3 ? c : shade(c, 1.07));
        if (trees) for (let k = 0; k < treeN; k++) { const a = rand() * 6.28, rr = r * (0.15 + rand() * 0.55), x = p[0] + Math.cos(a) * rr, z = p[2] + Math.sin(a) * rr, yy = cy + vr * Math.sqrt(Math.max(0, 1 - (rr / r) ** 2)) - 3; trees(x, yy, z); }
      }
    };
    const leafy = (x, y, z) => P.roundTree(g, x, y, z, 3 + rand() * 2, rand() < 0.5 ? '#4f9a34' : '#5fae3a');
    const firs = (x, y, z) => P.pine(g, x, y, z, 4 + rand() * 2.5, rand() < 0.5 ? '#2f5d3a' : '#24503a');
    if (theme === 'montagne') {
      for (let s = s0; s < s1; s += 400) for (const sd of [-1, 1]) for (let tr = 0; tr < 3; tr++) { // une montagne ne touche jamais la route
        const off = sd * (300 + rand() * 250), r = 160 + rand() * 160, p = at(s + rand() * 200, off, -40);
        if (nearRoute(p[0], p[2]) < r * 1.4 + 25) continue; P.mountain(g, p[0], p[1], p[2], r, 380 + rand() * 300, true); break; }
      // second rang de grands sommets, plus loin, pour un horizon de montagnes
      for (let s = s0; s < s1; s += 700) for (const sd of [-1, 1]) { const off = sd * (950 + rand() * 600), i = Math.min(w.n - 1, Math.max(0, Math.round((s + rand() * 300) / STEP))), base = Math.max(groundY(theme, w, i, sd * 700), w.E[i]) - 60, q = crossPoint(w, i, off, base), r = 320 + rand() * 260;
        if (nearRoute(q[0], q[2]) < r * 1.4 + 200) continue; P.mountain(g, q[0], q[1], q[2], r, 800 + rand() * 600, true); }
    }
    if (theme === 'ville') ring({ cols: ['#78a64e', '#6c9a47'], trees: leafy });
    if (theme === 'campagne') ring({ cols: ['#9fbf5e', '#8db556', '#b4b86a', '#86b04f'], trees: leafy, treeN: 9, minH: 40, maxH: 100 });
    if (theme === 'littoral') { landApron(w, f, g); ring({ sides: [1], cols: ['#86ad5c', '#7aa352', '#93b763'], trees: leafy, treeN: 6, minH: 45, maxH: 110 }); }
    if (theme === 'foret') {
      ring({ cols: ['#3f6b3a', '#355f34', '#46753f'], trees: firs, treeN: 12, minH: 60, maxH: 140 });
      for (let s = s0; s < s1; s += 600) for (let tr = 0; tr < 3; tr++) { const p = at(s + rand() * 200, -(420 + rand() * 200), -30); if (nearRoute(p[0], p[2]) < 310) continue; P.mountain(g, p[0], p[1], p[2], 200, 330, true); break; }
    }
    if (theme === 'canyon') { // plateaux de grès et grandes buttes rouges à l'horizon
      ring({ cols: ['#d39d5e', '#c98f5a', '#dba86a'], minH: 35, maxH: 90 });
      for (let s = s0; s < s1; s += 450) for (const sd of [-1, 1]) { const off = sd * (850 + rand() * 650), i = Math.min(w.n - 1, Math.max(0, Math.round((s + rand() * 200) / STEP))), q = crossPoint(w, i, off, groundY(theme, w, i, sd * 700) - 15), r = 70 + rand() * 120;
        if (nearRoute(q[0], q[2]) < r + 600) continue; P.mesa(g, q[0], q[1], q[2], r, 110 + rand() * 140); }
    }
    return g;
  }

  // Gère le décor autour d'une position : construit les tronçons proches, libère les autres.

  /* ---------- Arches gonflables au départ des segments chronométrés ----------
     Une arche gonflable (gros boudins arrondis) enjambe la route à la ligne de départ de chaque segment, avec le mot
     « SPRINT », « MONTÉE » ou « SEGMENT » (route secondaire) en lettres blanches en relief, lisible en arrivant. */
  const FONT = { // police 5 × 7 (lignes de haut en bas)
    S: ['01111', '10000', '10000', '01110', '00001', '00001', '11110'], P: ['11110', '10001', '10001', '11110', '10000', '10000', '10000'],
    R: ['11110', '10001', '10001', '11110', '10100', '10010', '10001'], I: ['11111', '00100', '00100', '00100', '00100', '00100', '11111'],
    N: ['10001', '11001', '10101', '10011', '10001', '10001', '10001'], T: ['11111', '00100', '00100', '00100', '00100', '00100', '00100'],
    M: ['10001', '11011', '10101', '10101', '10001', '10001', '10001'], O: ['01110', '10001', '10001', '10001', '10001', '10001', '01110'],
    E: ['11111', '10000', '10000', '11110', '10000', '10000', '11111'], G: ['01110', '10001', '10000', '10111', '10001', '10001', '01110'],
    'É': ['00010', '00100', '11111', '10000', '11110', '10000', '11111'],
    A: ['01110', '10001', '10001', '11111', '10001', '10001', '10001'], V: ['10001', '10001', '10001', '10001', '10001', '01010', '00100'],
  };
  const ARCH_STYLE = { fast: ['SPRINT', '#16a34a', '#15803d'], climb: ['MONTÉE', '#dc2626', '#b91c1c'], branch: ['SEGMENT', '#0891b2', '#0e7490'] };
  // couleurs des segments dans les profils d'altitude (mêmes teintes que les arches, plus lumineuses sur fond sombre)
  const SEG_STYLE = { fast: { label: 'Sprint', color: '#22c55e' }, climb: { label: 'Montée', color: '#ef4444' }, branch: { label: 'Route secondaire', color: '#38bdf8' } };
  function segmentArch(g, road, s, half, kind, finish) {
    const f = Math.max(0, Math.min(road.n - 1.001, s / STEP)), i = Math.min(road.n - 1, Math.round(f)), h = road.Hd[i];
    const F = [Math.cos(h), 0, Math.sin(h)], L = [-Math.sin(h), 0, Math.cos(h)], y0 = road.E[i];
    const C = [road.X[i], y0, road.Z[i]], at = (lat, up, fw = 0) => [C[0] + L[0] * lat + F[0] * fw, C[1] + up, C[2] + L[2] * lat + F[2] * fw];
    const [word0, col, dark] = ARCH_STYLE[kind] || ARCH_STYLE.branch, word = finish ? 'ARRIVÉE' : word0, top = 5.6, rr = 0.62;
    // boudins gonflables : deux pieds (avec un pied élargi au sol) et la traverse, raccordés par des sphères
    for (const sd of [-1, 1]) {
      const x = sd * half;
      g.tube(at(x, -1), at(x, top), rr, col, 10); g.sphere(M.t(...at(x, top)), rr * 1.02, col, 6, 10);
      g.sphere(M.chain(M.t(...at(x, 0.15)), M.s(1.35, 0.35, 1.35)), rr * 1.3, dark, 5, 10); // lest au sol
    }
    g.tube(at(-half, top), at(half, top), rr, col, 10);
    // bandeau sous la traverse, face au cycliste qui arrive, avec le mot en relief (pixels blancs)
    const bw = Math.min(half * 2 - 1.6, 8.4), bh = 1.35, by = top - 1.05, m = [L[0], 0, L[2], 0, 0, 1, 0, 0, F[0], 0, F[2], 0, ...at(0, by, -0.05), 1];
    g.box(m, bw, bh, 0.12, dark);
    const n = word.length, px = Math.min(0.17, (bw - 0.5) / (n * 6 - 1)), tw = (n * 6 - 1) * px, ox = -tw / 2 + px / 2, oy = 3 * px;
    [...word].forEach((ch, k) => (FONT[ch] || []).forEach((row, ry) => [...row].forEach((b, rx) => {
      if (b !== '1') return;
      // côté du bandeau tourné vers le cycliste qui arrive (−F) ; le texte se lit de gauche à droite pour lui
      const lx = ox + (k * 6 + rx) * px, ly = oy - ry * px;
      g.box(M.chain(m, M.t(lx, ly, -0.1)), px * 0.92, px * 0.92, 0.06, '#ffffff');
    })));
  }
  function segmentArches(w, branches) {
    const g = new Geo();
    for (const sg of segmentsOf(w)) {
      if (sg.road < 0) { segmentArch(g, w, sg.sA, 5.6, sg.kind); segmentArch(g, w, sg.sB, 5.6, sg.kind, true); }
      else { const b = branches.find(x => x.id === sg.road); if (b) { segmentArch(g, b.road, Math.max(STEP * 2, sg.sA), (b.hw || 3) + 0.9, sg.kind); segmentArch(g, b.road, Math.min(b.road.length - STEP * 2, sg.sB), (b.hw || 3) + 0.9, sg.kind, true); } }
    }
    return g;
  }
  class Scenery {
    constructor(renderer, route) {
      this.r = renderer; this.w = build(route); this.chunks = new Map(); this.far = new Map();
      this.branches = branchesOf(this.w); // routes secondaires (et terrain ajusté sous elles) avant tout le reste
      this.segArches = renderer.mesh(segmentArches(this.w, this.branches)); // arches gonflables au départ des segments
      this.hasFar = true; // tous les parcours ont un horizon (collines, montagnes ou buttes lointaines)
      const T = THEMES[route.theme];
      renderer.env({ sky: T.sky, fog: T.fog, ground: T.ground, near: Math.round(T.far * 0.18), far: T.far });
      this.fogFar = T.far;
      renderer.wind = route.theme === 'littoral' ? 1 : 0; // l'herbe et les fleurs ondulent au vent du large
      if (route.theme === 'littoral') { const g = new Geo(); g.quad([-4000, 0, -4000], [4000, 0, -4000], [4000, 0, 4000], [-4000, 0, 4000], '#2b8fc4'); this.sea = renderer.mesh(g); }
      else {
        // Sol lointain : une grande plaine sous le terrain, qui suit la caméra et se fond dans la brume. Au-delà des 700 m de
        // terrain (ou à l'intérieur d'un virage serré), on ne voit donc jamais de vide, de bord de carte ni de dessous du décor.
        // Elle reste toujours sous le terrain réel : plus bas que la route la plus basse des 3 km voisins, moins une marge par décor.
        const GP = { montagne: ['#55794a', 190], canyon: ['#cf9c62', 18], foret: ['#3f6b3a', 12], ville: ['#7aab4a', 14], campagne: ['#93b65a', 25] }[route.theme] || ['#7a8a6a', 15];
        const g = new Geo(); g.quad([-6000, 0, -6000], [6000, 0, -6000], [6000, 0, 6000], [-6000, 0, 6000], GP[0]); this.plain = renderer.mesh(g);
        const w = this.w, n = w.n, m = new Float64Array(n);
        for (let i = 0; i < n; i++) { let lo = Infinity; for (let j = Math.max(0, i - 300); j <= Math.min(n - 1, i + 300); j += 3) lo = Math.min(lo, w.E[j]); m[i] = lo - GP[1]; }
        this.plainY = m;
      }
      // une aile de papillon par couleur (l'autre aile est son reflet)
      const wing = (c, sz) => { const g = new Geo(), T = (a, b, d, k) => sz > 0 ? g.tri(a, b, d, k) : g.tri([a[0], a[1], -a[2]], [d[0], d[1], -d[2]], [b[0], b[1], -b[2]], k);
        T([0, 0, 0], [0.12, 0, 0.16], [-0.04, 0, 0.2], c); T([0, 0, 0], [-0.04, 0, 0.2], [-0.12, 0, 0.1], shade(c, 0.85)); T([0, 0, 0], [0.02, 0, 0.004], [-0.16, 0, 0.004], '#1f2937'); return renderer.mesh(g); };
      this.wings = ['#f97316', '#facc15', '#ffffff', '#60a5fa', '#e879f9'].map(c => [wing(c, 1), wing(c, -1)]);
      // oiseau (mouette) : corps + deux ailes articulées
      const bw = sz => { const g = new Geo(), T = (a, b, d, k) => sz > 0 ? g.tri(a, b, d, k) : g.tri([a[0], a[1], -a[2]], [d[0], d[1], -d[2]], [b[0], b[1], -b[2]], k);
        T([0.18, 0, 0], [-0.12, 0, 0.75], [-0.22, 0, 0], '#f8fafc'); T([-0.12, 0, 0.75], [0.0, 0, 0.6], [0.18, 0, 0], '#e5e7eb'); T([-0.12, 0, 0.75], [-0.2, 0, 0.9], [-0.02, 0, 0.72], '#374151'); return renderer.mesh(g); };
      const body = new Geo(); body.sphere(M.s(1, 0.55, 0.5), 0.26, '#f8fafc', 3, 6); body.box(M.t(0.27, 0.01, 0), 0.1, 0.05, 0.05, '#f59e0b'); body.tri([-0.2, 0, 0], [-0.42, 0, 0.12], [-0.42, 0, -0.12], '#e5e7eb');
      this.bird = { body: renderer.mesh(body), r: bw(1), l: bw(-1) };
      if (route.theme === 'canyon') { this.camel = camelMeshes(renderer); this.vul = vultureMeshes(renderer); this.vultures = []; this.focus = 0; }
    }
    update(s, ahead = 1600, behind = 300) {
      this.focus = s;
      ahead = Math.max(ahead, this.fogFar + 200); // le décor est prêt avant de sortir du brouillard : aucun arbre n'apparaît d'un coup
      if (this.vul && !this.vultures.length) for (let k = 0; k < VULTURES; k++) this.vultures.push(this.spawnVulture(Math.max(0, Math.min(this.w.length, s - 300 + (k + Math.random() * 0.8) * (2300 / VULTURES)))));
      const want = new Set();
      const a = Math.max(0, Math.floor((s - behind) / (CHUNK * STEP))), b = Math.floor((s + ahead) / (CHUNK * STEP));
      for (let c = a; c <= b; c++) if (c * CHUNK < this.w.n - 1) want.add(c);
      if (this.w.layout) { // une portion voisine du réseau (plus loin le long du parcours) peut être en vue : on la charge aussi
        const W = this.w, fi = Math.max(0, Math.min(W.n - 1, Math.round(s / STEP))), fx = W.X[fi], fz = W.Z[fi], RV = Math.min(1500, this.fogFar);
        for (let c = 0; c * CHUNK < W.n - 1; c++) { const k = Math.min(W.n - 1, c * CHUNK + CHUNK / 2); if (Math.hypot(W.X[k] - fx, W.Z[k] - fz) < RV) want.add(c); }
        this.near = want; }
      let built = 0;
      // couche lointaine : chargée de 3 km derrière à 5 km devant, libérée seulement au-delà de 4 km / 6 km (pas de va-et-vient)
      // une seule construction lourde par image (deux tronçons proches, ou une portion d'horizon) : pas d'à-coup
      const missing = [...want].filter(c => !this.chunks.has(c)).length, cap = missing > 3 ? 2 : 1; // en roulant : un seul tronçon par image
      for (const c of [...want].sort((x, y) => x - y)) if (!this.chunks.has(c) && built < cap) { const g = buildChunk(this.w, c); this.chunks.set(c, { mesh: this.r.mesh(g), dmesh: g.detail && g.detail.count ? this.r.mesh(g.detail) : null, bf: g.butterflies || [], birds: g.birds || [], sounds: g.sounds || [], camels: g.camels || [] }); built++; }
      if (this.hasFar) {
        const fa = Math.max(0, Math.floor((s - 3000) / FAR)), fb = Math.floor((s + 5000) / FAR);
        for (let f = fa; f <= fb; f++) if (f * FAR < this.w.length && !this.far.has(f) && built === 0) { this.far.set(f, this.r.mesh(buildFar(this.w, f))); built++; }
        for (const [f, m] of this.far) if ((f + 1) * FAR < s - 4000 || f * FAR > s + 6000) { this.r.free(m); this.far.delete(f); }
      }
      // un tronçon n'est libéré qu'une fois sorti de la zone d'un tronçon de plus : pas de destruction / recréation en boucle à une limite
      for (const [c, k] of this.chunks) if ((c < a - 1 || c > b + 1) && !(this.near && this.near.has(c))) { this.r.free(k.mesh); if (k.dmesh) this.r.free(k.dmesh); this.chunks.delete(c); }
      return built;
    }
    draw(cam) {
      // du plus proche au plus lointain : les pixels déjà couverts par le décor proche ne sont pas recalculés
      // pour l'horizon, la plaine lointaine ou la mer (moins de travail pour la carte graphique)
      const fc = this.focus / (CHUNK * STEP);
      const fogC = this.fogFar / (CHUNK * STEP);
      if (this.w.layout) { // réseau : tri et tri du brouillard selon la distance réelle à la caméra (portions voisines comprises)
        const W = this.w, dist = c => { const k = Math.min(W.n - 1, c * CHUNK + CHUNK / 2); return Math.hypot(W.X[k] - cam[0], W.Z[k] - cam[2]); };
        for (const [c, k, d] of [...this.chunks].map(e => [e[0], e[1], dist(e[0])]).sort((a, b) => a[2] - b[2])) {
          if (d > this.fogFar + CHUNK * STEP) continue;
          this.r.draw(k.mesh);
          if (k.dmesh && d < 750) this.r.draw(k.dmesh);
        }
      } else
      for (const [c, k] of [...this.chunks].sort((a, b) => Math.abs(a[0] + 0.5 - fc) - Math.abs(b[0] + 0.5 - fc))) {
        if (c - fc > fogC + 0.2) continue; // déjà construit mais encore entièrement dans le brouillard
        this.r.draw(k.mesh);
        if (k.dmesh && Math.abs(c + 0.5 - fc) < 3.6) this.r.draw(k.dmesh); // herbe et fleurs : jusqu'à ~700 m, invisibles au-delà
      }
      this.r.draw(this.segArches);
      for (const m of this.far.values()) this.r.draw(m);
      if (this.plain) this.r.draw(this.plain, M.t(cam[0], this.plainY[Math.max(0, Math.min(this.w.n - 1, Math.round(this.focus / STEP)))], cam[2]));
      if (this.sea) this.r.draw(this.sea, M.t(cam[0], this.w.seaLevel, cam[2]));
      // papillons : vol en boucle autour des fleurs, battement d'ailes ; seulement ceux qui sont proches
      const t = performance.now() / 1000;
      this.drawBirds(cam, t); this.drawCamels(cam, t); this.drawVultures(cam, t);
      for (const k of this.chunks.values()) for (const b of k.bf) {
        const dx = b.x - cam[0], dz = b.z - cam[2]; if (dx * dx + dz * dz > 90 * 90) continue;
        const u = t * 0.6 + b.ph, x = b.x + Math.sin(u) * 1.6, z = b.z + Math.sin(u * 1.7) * 1.2, y = b.y + 0.7 + Math.sin(t * 2.3 + b.ph) * 0.3 + Math.max(0, Math.sin(u * 0.5)) * 0.6;
        const yaw = Math.atan2(Math.cos(u * 1.7) * 1.2 * 1.7, Math.cos(u) * 1.6), flap = 0.25 + Math.abs(Math.sin(t * 16 + b.ph)) * 1.1;
        const base = M.chain(M.t(x, y, z), M.ry(-yaw)), [right, left] = this.wings[b.c];
        this.r.draw(right, M.chain(base, M.rx(-flap))); this.r.draw(left, M.chain(base, M.rx(flap)));
      }
    }
    // Sources sonores des tronçons chargés ; les mouettes sont suivies là où elles volent (clé stable par oiseau).
    soundSources(t = performance.now() / 1000) {
      const out = [];
      for (const k of this.chunks.values()) {
        for (const s of k.sounds) out.push(s);
        for (const b of k.birds) { const q = birdPos(b, t); b.snd = b.snd || { key: b, type: 'gulls' }; b.snd.x = q.x; b.snd.y = q.y; b.snd.z = q.z; out.push(b.snd); }
      }
      return out;
    }
    // Chameaux : marche lente d'avant en arrière le long de la route, pattes animées (amble : les deux pattes d'un même côté ensemble).
    drawCamels(cam, t) {
      const C = this.camel; if (!C) return; const w = this.w;
      for (const k of this.chunks.values()) for (const b of k.camels) {
        const u = b.still ? 0 : t * 0.045 + b.ph, s = Math.max(0, Math.min(w.length - 1, b.s0 + Math.sin(u) * b.amp)), vel = b.still ? 0 : Math.cos(u) * b.amp * 0.045;
        const f = s / STEP, i = Math.min(w.n - 2, Math.floor(f)), tt = f - i, h = w.Hd[i] + (w.Hd[i + 1] - w.Hd[i]) * tt;
        const y = groundY('canyon', w, i, b.off) * (1 - tt) + groundY('canyon', w, i + 1, b.off) * tt;
        const x = w.X[i] + (w.X[i + 1] - w.X[i]) * tt - Math.sin(h) * b.off, z = w.Z[i] + (w.Z[i + 1] - w.Z[i]) * tt + Math.cos(h) * b.off;
        const dx = x - cam[0], dz = z - cam[2]; if (dx * dx + dz * dz > 450 * 450) continue;
        const head = b.still ? b.rot : h + (vel < 0 ? Math.PI : 0), base = M.chain(M.t(x, y, z), M.ry(-head), M.s(b.sz, b.sz, b.sz));
        this.r.draw(C.body, base);
        const sw = Math.min(1, Math.abs(vel) / 0.8) * 0.42, ph = t * 3.2 + b.ph * 3;
        for (const [hx, hz, side] of [[0.62, 0.26, 0], [0.62, -0.26, 1], [-0.62, 0.26, 0], [-0.62, -0.26, 1]]) {
          const a = Math.sin(ph + side * Math.PI) * sw;
          this.r.draw(C.leg, M.chain(base, M.t(hx, 1.6, hz), M.rz(a)));
        }
      }
    }
    // Un vautour : cercle de 60 à 150 m de rayon autour d'un point fixe, à une altitude sûre calculée sur tout le cercle.
    spawnVulture(sc) {
      const w = this.w, i = Math.max(0, Math.min(w.n - 1, Math.round(sc / STEP))), off = (Math.random() < 0.5 ? -1 : 1) * Math.random() * 230;
      const c = crossPoint(w, i, off, 0), r = 60 + Math.random() * 90;
      let top = -Infinity;
      for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2, q = terrainAt(w, c[0] + Math.cos(a) * r, c[2] + Math.sin(a) * r, i); top = Math.max(top, q.y + obstacleAllowance(q.i * STEP, q.off)); }
      const q0 = terrainAt(w, c[0], c[2], i); top = Math.max(top, q0.y + obstacleAllowance(q0.i * STEP, q0.off));
      const v = 9 + Math.random() * 6; // vitesse (m/s)
      return { s: i * STEP, x: c[0], z: c[2], r, y: top + 20 + Math.random() * 50, w: (Math.random() < 0.5 ? -1 : 1) * v / r, ph: Math.random() * 6.28,
        size: 2 + Math.random() * 1.2, period: 9 + Math.random() * 8, flapOff: Math.random() * 20, bob: Math.random() * 6.28 };
    }
    // Vol plané en cercle, quelques battements de temps en temps ; renouvellement uniquement hors de vue (dans le brouillard).
    drawVultures(cam, t) {
      const V = this.vul; if (!V) return;
      for (let k = 0; k < this.vultures.length; k++) {
        let b = this.vultures[k];
        const dc = Math.hypot(b.x - cam[0], b.z - cam[2]);
        if (b.s < this.focus - 300 && dc > V_FAR) { // resté loin derrière et invisible : il réapparaît loin devant, encore invisible
          // placé à la suite du vautour le plus en avant : espacement régulier, pas de « trou » dans le ciel
          const far = Math.max(...this.vultures.map(o => o.s));
          let ahead = Math.max(V_FAR + 50, far - this.focus + 110 + Math.random() * 90), nb = null;
          for (let tries = 0; tries < 6 && this.focus + ahead < this.w.length; tries++) { const c = this.spawnVulture(this.focus + ahead); if (Math.hypot(c.x - cam[0], c.z - cam[2]) - c.r > V_FAR) { nb = c; break; } ahead += 300; }
          if (nb) b = this.vultures[k] = nb; // sinon (fin du parcours) il continue de tourner là où il est, toujours hors de vue
        }
        const a = t * b.w + b.ph, x = b.x + Math.cos(a) * b.r, z = b.z + Math.sin(a) * b.r, y = b.y + Math.sin(t * 0.12 + b.bob) * 6;
        const head = b.w > 0 ? a + Math.PI / 2 : a - Math.PI / 2, bank = Math.sign(b.w) * 0.26;
        // ailes : longues phases planées (léger dièdre en V) et quelques battements lents
        const u = (t + b.flapOff) % b.period, fd = 1.9;
        const flap = u < fd ? Math.sin(Math.PI * u / fd) * Math.sin(u * Math.PI * 2 * 1.5) * 0.55 : 0;
        const dihedral = 0.13 + Math.sin(t * 1.3 + b.bob) * 0.03;
        const base = M.chain(M.t(x, y, z), M.ry(-head), M.rx(bank), M.s(b.size, b.size, b.size));
        this.r.draw(V.body, base);
        this.r.draw(V.right, M.chain(base, M.t(0.02, 0.02, 0.08), M.rx(-(dihedral + flap))));
        this.r.draw(V.left, M.chain(base, M.t(0.02, 0.02, -0.08), M.rx(dihedral + flap)));
      }
    }
    drawBirds(cam, t) {
      const B = this.bird;
      for (const k of this.chunks.values()) for (const b of k.birds) {
        const dx = b.x - cam[0], dz = b.z - cam[2]; if (dx * dx + dz * dz > 600 * 600) continue;
        const { a, x, y, z } = birdPos(b, t);
        const head = Math.atan2(Math.cos(a) * b.sp, -Math.sin(a) * b.sp), bank = b.sp > 0 ? -0.25 : 0.25; // cap = direction du vol
        const glide = Math.sin(t * 0.7 + b.ph) > 0.2, flap = glide ? 0.12 : Math.sin(t * 9 + b.ph) * 0.55;
        const base = M.chain(M.t(x, y, z), M.ry(-head), M.rx(bank), M.s(2.4, 2.4, 2.4));
        this.r.draw(B.body, base); this.r.draw(B.r, M.chain(base, M.rx(-flap))); this.r.draw(B.l, M.chain(base, M.rx(flap)));
      }
    }
    dispose() { this.near = null; if (this.segArches) this.r.free(this.segArches); if (this.vul) for (const m of Object.values(this.vul)) this.r.free(m); for (const m of this.far.values()) this.r.free(m); this.far.clear(); if (this.camel) for (const m of Object.values(this.camel)) this.r.free(m); if (this.bird) for (const m of Object.values(this.bird)) this.r.free(m); for (const k of this.chunks.values()) { this.r.free(k.mesh); if (k.dmesh) this.r.free(k.dmesh); } this.chunks.clear(); if (this.sea) this.r.free(this.sea); if (this.plain) this.r.free(this.plain); for (const pair of this.wings || []) for (const m of pair) this.r.free(m); }
  }

  // Matrice de placement d'un vélo sur la route (distance s, décalage latéral off).
  function placeOn(w, s, off = 0) {
    const p = at(w, s), nx = -Math.sin(p.heading), nz = Math.cos(p.heading);
    return { p, m: M.chain(M.t(p.x + nx * off, p.y + 0.05, p.z + nz * off), M.ry(-p.heading), M.rz(Math.atan(p.grade))) };
  }

  // Arche d'arrivée placée à une distance donnée (course plus courte que le parcours) : même modèle que l'arche d'arrivée.
  function finishArch(R, w, s) { const g = new Geo(); P.arch(g, w, Math.max(1, Math.min(w.n - 2, Math.round(s / STEP))), 'fin'); return R.mesh(g); }
  window.VVWorld = { segmentsOf, SEG_STYLE, finishArch, debug: { terrainAt, lim, groundY, landApronY, obstacleAllowance, desertOpen, groundDrawn, BR_WHY, branchDesign, smoothPath, frameAt }, ROUTES, THEMES, byId, build, at, speedFor, estimate, Scenery, placeOn, atSmooth, placeOnSmooth, STEP, branchesOf, branchMainS };
})();
